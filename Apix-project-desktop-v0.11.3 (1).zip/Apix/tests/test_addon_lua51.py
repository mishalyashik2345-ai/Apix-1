"""Lua 5.1 mock tests; these do not emulate the actual WoW secure UI."""
import json
from pathlib import Path
from lupa.lua51 import LuaRuntime
root = Path(__file__).resolve().parents[1] / 'Addon' / 'Apix'
lua = LuaRuntime(unpack_returned_tuples=True)
lua.execute(r'''
DEFAULT_CHAT_FRAME={AddMessage=function(_,m) end}; SlashCmdList={}
spells={ [17364]={'Stormstrike','storm.png'},[115356]={'Windstrike','wind.png'},[193786]={'Rockbiter','rock.png'},[77226]={'Passive','passive.png'},[188443]={'Chain','chain.png'},[60103]={'Lava Lash','lava.png'} }
function GetSpellInfo(id)
  if type(id)=='string' then for k,v in pairs(spells) do if v[1]==id then id=k; break end end end
  if spells[id] then return spells[id][1],nil,spells[id][2],nil,nil,nil,id end
end
function GetSpellTexture(id) if spells[id] then return spells[id][2] end end
function IsPassiveSpell(id) return id==77226 end
function UnitName() return 'Test',nil end; function GetRealmName() return 'Realm' end
function UnitClass() return 'Shaman','SHAMAN' end
function GetSpecialization() return 2 end; function GetSpecializationInfo() return 263,'Enhancement' end
function mkframe() local f={shown=true,alpha=1}
 function f:SetScript(k,v) self[k]=v end; function f:UnregisterEvent() end; function f:RegisterEvent() end
 function f:IsVisible() return self.shown end; function f:GetEffectiveAlpha() return self.alpha end
 function f:SetFrameStrata() end; function f:SetFrameLevel() end; function f:EnableMouse() end
 function f:SetBackdrop() end; function f:SetMovable() end; function f:RegisterForDrag() end
 function f:StartMoving() end; function f:StopMovingOrSizing() end
 function f:CreateFontString() return mkframe() end
 function f:SetMultiLine() end; function f:SetAutoFocus() end; function f:SetMaxLetters() end; function f:SetFontObject() end
 function f:SetWidth() end; function f:SetScrollChild() end; function f:SetFocus() end
 function f:HighlightText() end; function f:SetText(t) self.text=t end; function f:Hide() self.shown=false end
 function f:ClearAllPoints() end; function f:SetPoint() end; function f:SetSize() end; function f:Show() self.shown=true end
 function f:CreateTexture() return {SetAllPoints=function() end,SetColorTexture=function(self,r,g,b,a) self.r=r;self.g=g;self.b=b;self.a=a end} end
 return f end
UIParent=mkframe(); frames={}
function CreateFrame(k,n,p,t) local f=mkframe(); frames[#frames+1]=f; if n then _G[n]=f end; return f end
slots={}; bindings={}; macro={}
function GetActionInfo(i) local v=slots[i]; if v then return v[1],v[2] end end
function GetBindingKey(cmd) local v=bindings[cmd]; if v then return v[1],v[2] end end
overrides={}
function GetBindingAction(key,checkOverride)
 if checkOverride and overrides[key] then return overrides[key] end
 for cmd,v in pairs(bindings) do for _,k in ipairs(v) do if k==key then return cmd end end end
 return ''
end
function GetNumBindings() local n=0; for _ in pairs(bindings) do n=n+1 end; return n end
function GetBinding(index)
 local n=0
 for cmd,v in pairs(bindings) do n=n+1; if n==index then return cmd,'BINDING_HEADER_ACTIONBAR',v[1],v[2] end end
end
function GetMacroInfo(id) if macro[id] then return macro[id][1],nil,macro[id][2] end end
function GetMacroSpell(id) if macro[id] then return nil,nil,macro[id][3] end end
function button(name,slot) local f=mkframe(); f.action=slot; _G[name]=f; return f end
button('ActionButton1',1); button('ActionButton2',2); button('ActionButton3',3); button('ActionButton4',4); button('ActionButton5',5); button('ActionButton6',6)
keyboardFocus=nil
function GetCurrentKeyBoardFocus() return keyboardFocus end
ChatFrame1EditBox=mkframe()
function ChatFrame1EditBox:HasFocus() return keyboardFocus==self end
function ChatFrame1EditBox:HookScript(name,callback) self['hook_'..name]=callback end
NUM_CHAT_WINDOWS=1

slots[1]={'spell',17364}; bindings.ACTIONBUTTON1={'F','CTRL-F'}
slots[2]={'macro',1}; bindings.ACTIONBUTTON2={'E'}; macro[1]={'Storm macro','#showtooltip\n/cast Stormstrike',17364}
slots[3]={'spell',193786}; bindings.ACTIONBUTTON3={'SHIFT-2'}
slots[4]={'spell',77226}; bindings.ACTIONBUTTON4={'P'}
slots[5]={'macro',2}; bindings.ACTIONBUTTON5={'Q'}; macro[2]={'Conditional','/cast [mod:shift] Rockbiter; Stormstrike',193786}
slots[6]={'spell',188443}; bindings.ACTIONBUTTON6={'H'}; ActionButton6.shown=false
''')
A = lua.table()
load = lua.eval('function(code, name, A) return assert(loadstring(code))(name,A) end')
for name in ['Utils.lua','Config.lua','ColorManager.lua','Identity.lua','HekiliReader.lua','Bindings.lua','Diagnostics.lua','PixelRenderer.lua','Commands.lua','Core.lua']:
    load((root/name).read_text(), 'Apix', A)
lua.execute("frames[#frames].OnEvent(frames[#frames], 'ADDON_LOADED','Apix')")
assert A.ResolveSpellAlias(115356) == 17364
n,err,count,macros,warnings=A.ScanButtons(); assert (n,count,macros,warnings)==(2,2,2,1)
def export():
    text,err,count,mc,warn = A.BuildExport(); assert err is None,err
    return json.loads(text.removeprefix('APIX_EXPORT:'))
ob=export(); triggers={x['spellID']:x for x in ob['triggers']}
assert set(triggers)=={17364,193786}
assert triggers[17364]['key']=='F' and triggers[17364]['keys']==['F','CTRL-F']
assert triggers[193786]['key']=='SHIFT-2'
mm={m['name']:m for m in ob['macros']}
assert mm['Storm macro']['key']=='E' and mm['Storm macro']['spellID']==17364 and not mm['Storm macro']['selectedForTrigger']
assert mm['Conditional']['spellID'] is None and not mm['Conditional']['selectedForTrigger']
macrodiag=A.BuildMacroDiagnostics(); assert '/cast Stormstrike' in macrodiag and 'Conditional' in macrodiag and 'END BODY' in macrodiag
# Two visible direct buttons for the same ID preserve both bindings and sources.
lua.execute("button('ActionButton8',8); slots[8]={'spell',17364}; bindings.ACTIONBUTTON8={'X'}")
t={x['spellID']:x for x in export()['triggers']}[17364]
assert t['key']=='F' and t['keys']==['F','CTRL-F','X'] and len(t['bindings'])==2
lua.execute("ActionButton8.shown=false")
# When direct button disappears, a simple, verified macro is selected.
lua.execute('ActionButton1.shown=false')
assert {x['spellID']:x for x in export()['triggers']}[17364]['key']=='E'
lua.execute('ActionButton1.shown=true')
# Existing profile colours aren't rewritten on load/export, and close colours block export.
A.db.colors[17364]=lua.table_from([0,255,95]); A.db.colors[193786]=lua.table_from([0,255,82])
text,err=A.BuildExport(); assert text is None and 'tolerance 10' in err
assert A.Hex(A.db.colors[17364])=='#00FF5F'
ok,n=A.RebuildColors(); assert ok and n>=2
ob=export(); cs=[tuple(int(x['color'][i:i+2],16) for i in (1,3,5)) for x in ob['triggers']]
assert max(abs(cs[0][i]-cs[1][i]) for i in range(3))>20
assert all(max(c)>20 for c in cs)
old=[A.Hex(A.db.colors[x]) for x in (17364,193786)]; export(); assert old==[A.Hex(A.db.colors[x]) for x in (17364,193786)]
# No colour edits that overlap another registered colour or black.
assert A.SetColor(193786,old[0])[0] is False
assert A.SetColor(193786,'#101010')[0] is False
# Add visible Bartender-style click binding and verify inactive default frame does not contaminate it.
lua.execute("button('BT4Button14',14); slots[14]={'spell',188443}; bindings['CLICK BT4Button14:LeftButton']={'ALT-3'}")
assert {x['spellID']:x for x in export()['triggers']}[188443]['key']=='ALT-3'
# Unbound spells and unknown button names are not exported.
lua.execute("button('OtherButton1',17); slots[17]={'spell',115356}; button('ActionButton7',7); slots[7]={'spell',77226}")
assert len(export()['triggers'])==3
# Spell alias can export canonical Stormstrike when only its replacement is on a bound button.
lua.execute("slots[1]={'spell',115356}")
assert {x['spellID']:x for x in export()['triggers']}[17364]['rawSpellID']==115356
assert json.loads(A.Quote('quote " slash \\ control\x01'))=='quote " slash \\ control\x01'
diag=A.BuildBindingDiagnostics(); assert 'APIX PANEL DIAGNOSTICS' in diag and 'slot=1' in diag and 'triggers=3' in diag
# ElvUI-style secure override of a Blizzard binding, with field=0, current action in GetAction.
lua.execute("button('ElvUI_Bar9Button99',0); ElvUI_Bar9Button99.GetAction=function() return 'action',31 end; slots[31]={'spell',60103}; bindings.MULTIACTIONBAR1BUTTON5={'Y'}; overrides.Y='CLICK ElvUI_Bar9Button99:LeftButton'")
t={x['spellID']:x for x in export()['triggers']}; assert t[60103]['key']=='Y' and t[60103]['button']=='ElvUI_Bar9Button99'
# Reproduce user's ElvUI E/F report: action slots, not guessed bar indexes.
lua.execute("button('ElvUI_Bar3Button2',0); ElvUI_Bar3Button2.GetAction=function() return 'action',62 end; slots[62]={'spell',193786}; bindings.MULTIACTIONBAR1BUTTON2={'E'}; overrides.E='CLICK ElvUI_Bar3Button2:LeftButton'; button('ElvUI_Bar3Button5',0); ElvUI_Bar3Button5.GetAction=function() return 'action',65 end; slots[65]={'macro',124}; bindings.MULTIACTIONBAR1BUTTON5={'F'}; overrides.F='CLICK ElvUI_Bar3Button5:LeftButton'; macro[124]={'F macro','/cast [mod:shift] Rockbiter; Stormstrike',193786}")
o=export(); assert any(x['button']=='ElvUI_Bar3Button5' and x['key']=='F' and x['spellID'] is None for x in o['macros'])
assert any(x['button']=='ElvUI_Bar3Button2' and x['key']=='E' for x in o['triggers']) is False # another direct button for the same spell wins by name
lua.execute("overrides.F=nil; overrides.E=nil; bindings.MULTIACTIONBAR1BUTTON2=nil; bindings.MULTIACTIONBAR1BUTTON5={'Y'}")
# A click override to a different hidden button must not be attributed to the old action.
lua.execute("ElvUI_Bar9Button99.shown=false")
assert 60103 not in {x['spellID'] for x in export()['triggers']}
# An override-only key is found by safe probing and verified against GetBindingAction.
lua.execute("ElvUI_Bar9Button99.shown=true; bindings.MULTIACTIONBAR1BUTTON5=nil; overrides.Y=nil; overrides.Z='CLICK ElvUI_Bar9Button99:LeftButton'")
assert {x['spellID']:x for x in export()['triggers']}[60103]['key']=='Z'
# No mistaken action slot when an unrelated secure macro has a calc fallback.
lua.execute("button('OtherButton1',0); OtherButton1.GetAttribute=function(self,k) if k=='type' then return 'macro' end end; overrides.K='CLICK OtherButton1:LeftButton'; ActionButton_CalculateAction=function() return 31 end")
assert all(x['button']!='OtherButton1' for x in export()['triggers'])
# Exact user-reported Legion ElvUI macros, with Russian localized spell names.
lua.execute(r"""
bindings={}; overrides={}
ActionButton1.shown=false; ActionButton3.shown=false
spells[187837]={'Молния','l'}; spells[193786]={'Камнедробитель','r'}
spells[17364]={'Удар бури','s'}; spells[188089]={'Земляной шип','e'}; spells[193796]={'Язык пламени','f'}
local ids={187837,193786,17364,188089,193796}
local names={'Молния','Камнедробитель','Удар бури','Земляной шип','Язык пламени'}
local keys={'1','2','3','R','F'}
for i=1,5 do
 local buttonName='ElvUI_TestButton'..i
 local frame=button(buttonName,0)
 local slot=200+i
 frame.GetAction=function() return 'action',slot end
 slots[slot]={'macro',300+i}
 macro[300+i]={'test'..i,'#showtooltip\n/run CombatLogClearEntries()\n/cast '..names[i],ids[i]}
 bindings['BIND'..i]={keys[i]}; overrides[keys[i]]='CLICK '..buttonName..':LeftButton'
end
""")
o=export(); tt={x['spellID']:x for x in o['triggers']}
for sid,key in [(187837,'1'),(193786,'2'),(17364,'3'),(188089,'R'),(193796,'F')]:
    assert tt[sid]['key']==key and tt[sid]['kind']=='macro'
assert all(m['spellID'] is not None and m['selectedForTrigger'] for m in o['macros'])
# Arbitrary /run code and conditional casts remain unresolved, never whitelisted.
lua.execute("macro[301][2]='#showtooltip\\n/run CombatLogClearEntries(); Dangerous()\\n/cast Молния'; macro[302][2]='#showtooltip\\n/run CombatLogClearEntries()\\n/cast [mod:shift] Камнедробитель'")
o=export(); mm={x['macroID']:x for x in o['macros']}
assert mm[301]['spellID'] is None and mm[302]['spellID'] is None
# Direct spell outranks a valid macro for the same ID.
lua.execute("button('ActionButton9',209); slots[209]={'spell',193796}; bindings.ACTIONBUTTON9={'G'}")
o=export(); tt={x['spellID']:x for x in o['triggers']}; assert tt[193796]['key']=='G' and tt[193796]['kind']=='spell'
assert not {x['macroID']:x for x in o['macros']}[305]['selectedForTrigger']
# Chat safety: an active text box paints black immediately on default chat focus,
# and on the next frame for general / custom edit boxes. No keyboard APIs fails closed.
saved_rec=A.GetHekiliRecommendation
A.GetHekiliRecommendation=lua.eval("function() return 17364, 'mock' end")
A.db.enabled=True
A.frame.OnUpdate(A.frame,0.03)
assert A.currentID==17364 and A.diag.spellPaint!='#000000'
lua.execute("keyboardFocus=ChatFrame1EditBox; ChatFrame1EditBox.hook_OnEditFocusGained(ChatFrame1EditBox)")
assert A.diag.spellPaint=='#000000' and A.inputGuardBlocked is True
A.frame.OnUpdate(A.frame,0.03)
assert A.currentID is None and A.diag.spellPaint=='#000000'
lua.execute("keyboardFocus=nil")
A.frame.OnUpdate(A.frame,0.03)
assert A.currentID==17364 and A.inputGuardBlocked is False
# Any edit box (including custom chat) is also blocked by the global focus API.
lua.execute("keyboardFocus=mkframe()")
A.frame.OnUpdate(A.frame,0.03)
assert A.inputGuardBlocked is True and A.diag.spellPaint=='#000000'
# Even test mode cannot replace the black stop signal while typing.
A.SetTestMode(True)
assert A.diag.spellPaint=='#000000'
lua.execute("keyboardFocus=nil")
A.frame.OnUpdate(A.frame,0.03)
assert A.diag.spellPaint=='#FF0000'
A.SetTestMode(False)
# Older client: fallback to ChatEdit_GetActiveWindow, then named chat HasFocus.
lua.execute("GetCurrentKeyBoardFocus=nil; ChatEdit_GetActiveWindow=function() return keyboardFocus end; keyboardFocus=ChatFrame1EditBox")
A.frame.OnUpdate(A.frame,0.03); assert A.inputGuardBlocked is True and A.diag.spellPaint=='#000000'
lua.execute("ChatEdit_GetActiveWindow=nil")
A.frame.OnUpdate(A.frame,0.03); assert A.inputGuardBlocked is True
lua.execute("keyboardFocus=nil")
A.frame.OnUpdate(A.frame,0.03); assert A.inputGuardBlocked is False
# When no detector is available, or one throws, black is mandatory.
lua.execute("ChatFrame1EditBox.HasFocus=nil")
A.frame.OnUpdate(A.frame,0.03)
assert A.inputGuardBlocked is True and 'unavailable' in A.inputGuardReason and A.diag.spellPaint=='#000000'
lua.execute("GetCurrentKeyBoardFocus=function() error('unsupported') end")
A.frame.OnUpdate(A.frame,0.03)
assert A.inputGuardBlocked is True and 'error' in A.inputGuardReason and A.diag.spellPaint=='#000000'
A.GetHekiliRecommendation=saved_rec
# Legion Hekili: numeric display IDs differ by specialization, like user's report.
lua.execute("""
currentSpec=102
function GetSpecializationInfo() return currentSpec,'Mock spec' end
Hekili={DB={profile={Enabled=true,displays={
 {Name='Feral Primary',Specialization=103,Enabled=true},
 {Name='Feral AOE',Specialization=103,Enabled=true},
 {Name='Guardian Primary',Specialization=104,Enabled=true},
 {Name='Guardian Defensives',Specialization=104,Enabled=true},
 {Name='Balance Primary',Specialization=102,Enabled=true}}}}}
function Hekili:IsDisplayActive(i) local f=_G['HekiliDisplay'..i]; return f and f.Active==true end
for i=1,5 do local f=mkframe(); _G['HekiliDisplay'..i]=f; f.shown=false; f.Active=false; f.Recommendations={{actionID=17364}} end
HekiliDisplay5.shown=true; HekiliDisplay5.Active=true
""")
A.db.display='auto'
id,source=A.GetHekiliRecommendation(); assert id==17364 and 'HekiliDisplay5' in source and 'auto' in source
assert 'display_5=name=Balance Primary' in A.BuildDiagnostics()
# Actual Legion queue stores actionName, resolved via the public GetAbilityInfo.
lua.execute("HekiliDisplay5.Recommendations={{actionName='test_action'}}; Hekili.GetAbilityInfo=function(self,action) if action=='test_action' then return 17364,'Stormstrike',action,false end end")
id,source=A.GetHekiliRecommendation(); assert id==17364 and 'HekiliDisplay5' in source and 'GetAbilityInfo' in source
lua.execute("Hekili.GetAbilityInfo=function() return 17364,'item','test_action',true end")
id,err=A.GetHekiliRecommendation(); assert id is None and 'предмет' in err
lua.execute("HekiliDisplay5.Recommendations={{actionID=17364}}")
# Switching spec must select its Primary without rewriting user settings.
lua.execute("currentSpec=103; HekiliDisplay5.shown=false; HekiliDisplay5.Active=false; HekiliDisplay1.shown=true; HekiliDisplay1.Active=true; HekiliDisplay2.shown=true; HekiliDisplay2.Active=true")
id,source=A.GetHekiliRecommendation(); assert id==17364 and 'HekiliDisplay1' in source and A.db.display=='auto'
# Never use a hidden, transparent, inactive or wrong-spec primary.
lua.execute("HekiliDisplay1.shown=false")
id,err=A.GetHekiliRecommendation(); assert id is None and 'нет видимого Primary' in err
lua.execute("HekiliDisplay1.shown=true; HekiliDisplay1.alpha=0")
id,err=A.GetHekiliRecommendation(); assert id is None
lua.execute("HekiliDisplay1.alpha=1; HekiliDisplay1.Active=false")
id,err=A.GetHekiliRecommendation(); assert id is None
# Multiple eligible primaries are ambiguous; choosing AOE by accident is forbidden.
lua.execute("HekiliDisplay1.Active=true; Hekili.DB.profile.displays[6]={Name='Other Primary', Specialization=103,Enabled=true}; HekiliDisplay6=mkframe(); HekiliDisplay6.Active=true; HekiliDisplay6.Recommendations={{actionID=193786}}")
id,err=A.GetHekiliRecommendation(); assert id is None and 'несколько' in err
# Explicit override remains possible and never reads hidden/inactive frame.
A.Command('display 6'); id,src=A.GetHekiliRecommendation(); assert id==193786 and 'HekiliDisplay6' in src
lua.execute('HekiliDisplay6.shown=false')
id,err=A.GetHekiliRecommendation(); assert id is None and 'скрыт' in err
A.Command('display auto'); assert A.db.display=='auto'
lua.execute("Hekili.DB.profile.Enabled=false")
id,err=A.GetHekiliRecommendation(); assert id is None and 'выключен' in err
lua.execute("Hekili.DB.profile.Enabled=true; GetSpecialization=function() return nil end")
id,err=A.GetHekiliRecommendation(); assert id is None and 'специализация' in err
# Migrate legacy default once, preserve non-default selection, and preserve later explicit 1.
lua.execute("savedDB=ApixDB; ApixDB={display='1'}")
A.InitConfig(); assert A.db.display=='auto'
A.db.display='1'; A.InitConfig(); assert A.db.display=='1'
lua.execute("ApixDB={display='5'}")
A.InitConfig(); assert A.db.display=='5'
lua.execute('ApixDB=savedDB'); A.InitConfig()
print('OK: Lua 5.1 mocks: bindings/macros/alias/colour/JSON/chat guard and Hekili auto display')
