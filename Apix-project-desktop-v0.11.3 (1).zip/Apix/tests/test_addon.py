"""Compatibility entry point for the Lua 5.1 smoke tests."""
from test_addon_lua51 import *
