local _, A = ...
local iconMap={}
local function normalize(t)
    if type(t)=='number' then return tostring(t) end
    if type(t)=='string' and t~='' then return string.lower(t):gsub('/','\\') end
end
function A.RebuildIconMap()
    iconMap={}
    for id in pairs(A.db.colors) do
        if A.ValidID(tonumber(id)) then
            local idn=tonumber(id)
            local tex=normalize(GetSpellTexture(idn))
            if tex then
                if iconMap[tex] and iconMap[tex]~=idn then iconMap[tex]=false
                elseif iconMap[tex]~=false then iconMap[tex]=idn end
            end
        end
    end
end
function A.ScanSpellbookLegacy()
    if type(GetNumSpellTabs)~='function' or type(GetSpellBookItemInfo)~='function' then return nil,'Spellbook API недоступен.' end
    local n=0
    for tab=1,GetNumSpellTabs() do
        local _,_,offset,count=GetSpellTabInfo(tab)
        if type(offset)=='number' and type(count)=='number' then
            for slot=offset+1,offset+count do
                local kind,id=GetSpellBookItemInfo(slot,BOOKTYPE_SPELL or 'spell')
                if kind=='SPELL' and A.ValidID(id) then
                    local had=A.db.colors[id]~=nil
                    if A.GetColor(id) and not had then n=n+1 end
                end
            end
        end
    end
    A.RebuildIconMap()
    return n
end
-- Override spell -> canonical action whose binding/color is shared. Never
-- guess unknown replacement relationships from localized names or icons.
function A.GetConfiguredAlias(id)
    local custom=A.db.spellAliases[id]
    if custom~=nil then return custom end
    return A.DefaultSpellAliases[id]
end
function A.ConfiguredAliasIDs()
    local found,ids={},{}
    for id in pairs(A.DefaultSpellAliases) do found[id]=true end
    for id in pairs(A.db.spellAliases) do found[id]=true end
    for id in pairs(found) do
        if A.ValidID(id) and A.GetConfiguredAlias(id)~=false and A.GetConfiguredAlias(id)~=nil then ids[#ids+1]=id end
    end
    table.sort(ids)
    return ids
end
function A.ResolveSpellAlias(id)
    if not A.ValidID(id) then return nil,'неверный spellID' end
    local seen={}; local current=id
    for _=1,32 do
        if seen[current] then return nil,'цикл aliases' end
        seen[current]=true
        local nextID=A.GetConfiguredAlias(current)
        if nextID==nil or nextID==false then return current end
        if not A.ValidID(nextID) then return nil,'неверный target spellID для alias '..current end
        current=nextID
    end
    return nil,'слишком длинная цепочка aliases'
end
function A.SetSpellAlias(from,to)
    if not A.ValidID(from) or (to~=false and not GetSpellInfo(from)) then return false,'неверный исходный spellID' end
    if to~=false and (not A.ValidID(to) or not GetSpellInfo(to) or from==to) then return false,'неверный целевой spellID' end
    local old=A.db.spellAliases[from]
    A.db.spellAliases[from]=to
    local id,err=A.ResolveSpellAlias(from)
    if not id then A.db.spellAliases[from]=old; return false,err end
    return true
end
local function resolved(id,source)
    local canonical,err=A.ResolveSpellAlias(id)
    if not canonical then return nil,'alias '..id..': '..err end
    if canonical~=id then source=source..'; alias '..id..' -> '..canonical end
    return canonical,source
end
local function displayByKey(h,key)
    if h and type(h.DisplayPool)=='table' then
        local d=h.DisplayPool[key] or h.DisplayPool[tonumber(key) or key]
        if d then return d,'Hekili.DisplayPool['..tostring(key)..']' end
    end
    return _G['HekiliDisplay'..tostring(key)], 'HekiliDisplay'..tostring(key)
end
local function visible(d)
    if not d then return false end
    if d.Active==false then return false end
    if type(d.IsVisible)~='function' or not d:IsVisible() then return false end
    if type(d.GetEffectiveAlpha)~='function' or d:GetEffectiveAlpha()<=0 then return false end
    return true
end
local function specID()
    if type(GetSpecialization)~='function' or type(GetSpecializationInfo)~='function' then return nil end
    local ok,index=pcall(GetSpecialization)
    if not ok or not index then return nil end
    local ok2,id=pcall(GetSpecializationInfo,index)
    return ok2 and tonumber(id) or nil
end
-- In this Legion Hekili the numeric frames correspond to profile.displays.
-- Choose only one visible, active Primary belonging to the current spec.
-- Never silently use AOE, defensive, or a hidden/stale queue.
function A.FindHekiliDisplay()
    local h=_G.Hekili
    local key=A.db.display
    if key~='auto' then return displayByKey(h,key) end
    local profile=h and h.DB and h.DB.profile
    local configs=profile and profile.displays
    if type(configs)~='table' then
        -- Legacy compatibility for forks that don't expose the Legion profile.
        return displayByKey(h,'1')
    end
    if profile.Enabled==false then return nil,'авто: Hekili выключен' end
    local current=specID()
    if not current then return nil,'авто: специализация недоступна' end
    local chosen,source,count=nil,nil,0
    for i,conf in ipairs(configs) do
        if type(conf)=='table' and conf.Enabled and
           (tonumber(conf.Specialization)==current or tonumber(conf.Specialization)==0) then
            local name=type(conf.Name)=='string' and conf.Name or ''
            if name:lower():find('primary',1,true) then
                local d,src=displayByKey(h,i)
                local active=true
                if type(h.IsDisplayActive)=='function' then
                    local ok,result=pcall(h.IsDisplayActive,h,i)
                    active=ok and result==true
                end
                if active and visible(d) then
                    count=count+1; chosen=d; source=src
                end
            end
        end
    end
    if count==1 then return chosen,source..' (auto Primary spec '..current..')' end
    if count>1 then return nil,'авто: несколько видимых Primary; выберите /apix display N' end
    return nil,'авто: нет видимого Primary для spec '..current..'; проверьте Hekili или /apix display N'
end
function A.GetHekiliRecommendation()
    if not _G.Hekili then return nil,'Hekili не загружен' end
    local d,source=A.FindHekiliDisplay()
    if not d then
        if A.db.display=='auto' then return nil,source end
        return nil,'фрейм дисплея не найден: '..tostring(source)
    end
    if d.Active==false then return nil,'дисплей неактивен: '..source end
    if d.IsVisible and not d:IsVisible() then return nil,'дисплей скрыт: '..source end
    if d.GetEffectiveAlpha and d:GetEffectiveAlpha()<=0 then return nil,'дисплей полностью прозрачный: '..source end
    local r=type(d.Recommendations)=='table' and d.Recommendations[1]
    if type(r)~='table' then return nil,'нет первой рекомендации: '..source end
    -- An item or other non-spell recommendation must not be converted into a spell.
    if r.item then return nil,'рекомендован предмет, не заклинание' end
    for _,field in ipairs({'actionID','spellID','spellId'}) do
        local id=tonumber(r[field])
        if A.ValidID(id) and GetSpellInfo(id) then return resolved(id,source..'.Recommendations[1].'..field) end
    end
    local action=r.actionName
    if type(action)=='string' and action~='' then
        local mapped=tonumber(A.db.actionMap[action])
        if A.ValidID(mapped) and GetSpellInfo(mapped) then return resolved(mapped,source..'.actionName='..action..' (ручное сопоставление)') end
        -- Confirmed in Hekili 7.3.5.24-39-g8207722 Classes.lua:
        -- GetAbilityInfo(actionName) -> id, name, key, item.
        local h=_G.Hekili
        if type(h.GetAbilityInfo)=='function' then
            local ok,id,abilityName,abilityKey,item=pcall(h.GetAbilityInfo,h,action)
            if ok and item then return nil,'actionName='..action..'; Hekili рекомендует предмет, не spell' end
            id=ok and tonumber(id) or nil
            if A.ValidID(id) and GetSpellInfo(id) then
                return resolved(id,source..'.Hekili:GetAbilityInfo('..action..')')
            end
        end
        if not A.db.iconFallback then return nil,'actionName='..action..'; задайте /apix map '..action..' spellID или явно включите iconfallback' end
        -- Legion stores actionName in its queue; class.abilities is private.
        -- Icon fallback accepts ONLY a unique spellbook texture match.
        local b=d.Buttons and d.Buttons[1]
        if b and (not b.IsVisible or b:IsVisible()) and b.Texture and b.Texture.GetTexture then
            local tex=normalize(b.Texture:GetTexture())
            local id=tex and iconMap[tex]
            if id then return resolved(id,source..'.Buttons[1].Texture (уникальная иконка)') end
            return nil,'actionName='..action..'; иконка неизвестна или неоднозначна'
        end
        return nil,'actionName='..action..'; кнопка/текстура недоступна'
    end
    return nil,'нет распознанной рекомендации: '..source
end
