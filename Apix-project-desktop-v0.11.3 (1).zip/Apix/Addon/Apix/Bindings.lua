local _, A = ...
-- Resolve actual effective bindings, including action-bar addons' override bindings.
-- Keys are never inferred from a bar number: each is checked with GetBindingAction.
local function call(fn,...)
    if type(fn)~='function' then return nil end
    local ok,a,b,c=pcall(fn,...); if ok then return a,b,c end
end
local function slotOf(button)
    local typ=call(button.GetAttribute,button,'type')
    if typ and typ~='action' then return nil end
    if type(button.GetAction)=='function' then
        local kind,slot=call(button.GetAction,button)
        if kind=='action' and type(slot)=='number' and slot>0 then return slot end
        if type(kind)=='number' and kind>0 then return kind end
        if kind and kind~='action' then return nil end
    end
    local n=call(button.GetAttribute,button,'action')
    if type(n)=='number' and n>0 then return n end
    if type(button.action)=='number' and button.action>0 then return button.action end
    if typ=='action' then
        n=call(_G.ActionButton_CalculateAction,button)
        if type(n)=='number' and n>0 then return n end
    end
end
local standard={ACTIONBUTTON='ActionButton', MULTIACTIONBAR1BUTTON='MultiBarBottomLeftButton',
    MULTIACTIONBAR2BUTTON='MultiBarBottomRightButton', MULTIACTIONBAR3BUTTON='MultiBarRightButton',
    MULTIACTIONBAR4BUTTON='MultiBarLeftButton'}
local function buttonName(command)
    if type(command)~='string' then return nil end
    local name=command:match('^CLICK ([%w_]+):LeftButton$')
    if name then return name end
    local prefix,index=command:match('^(%u+%d?BUTTON)(%d+)$')
    local frame=prefix and standard[prefix]
    if frame and tonumber(index)<=12 and tonumber(index)>0 then return frame..index end
end
local function discoverBindings()
    if type(GetBindingAction)~='function' or type(GetBinding)~='function' or type(GetNumBindings)~='function' then
        return nil,'Недоступны GetBindingAction/GetBinding/GetNumBindings — нельзя безопасно определить бинды.'
    end
    local byButton,seen={},{}
    local function examine(key)
        if type(key)~='string' or key=='' or seen[key] then return end
        seen[key]=true
        local effective=call(GetBindingAction,key,true)
        local name=buttonName(effective)
        if not name then return end
        local button=_G[name]
        if not button or type(button.IsVisible)~='function' or not call(button.IsVisible,button) then return end
        local slot=slotOf(button)
        if not slot then return end
        local item=byButton[name]
        if not item then item={button=name,slot=slot,keys={}}; byButton[name]=item end
        item.keys[#item.keys+1]=key
    end
    local n=call(GetNumBindings)
    if type(n)~='number' then return nil,'GetNumBindings не вернул число.' end
    for i=1,math.min(n,5000) do
        -- Some Legion clients return command, header, key1, key2; others omit header.
        local ok,command,b,c,d,e,f,g,h=pcall(GetBinding,i)
        if ok and type(command)=='string' then
            examine(b); examine(c); examine(d); examine(e); examine(f); examine(g); examine(h)
            -- Use GetBindingKey for clients whose GetBinding return layout differs.
            local k1,k2,k3=call(GetBindingKey,command); examine(k1); examine(k2); examine(k3)
        end
    end
    -- Override-only keys may not be present in GetBinding's normal list.
    -- Probe a bounded set of common physical keys and modifier combinations;
    -- ONLY a nonempty effective CLICK/action command can add an entry.
    local bases={}
    for i=65,90 do bases[#bases+1]=string.char(i) end
    for i=0,9 do bases[#bases+1]=tostring(i); bases[#bases+1]='NUMPAD'..i end
    for i=1,24 do bases[#bases+1]='F'..i end
    for i=1,5 do bases[#bases+1]='BUTTON'..i end
    for _,key in ipairs({'MOUSEWHEELUP','MOUSEWHEELDOWN','SPACE','TAB','ENTER','BACKSPACE','DELETE','INSERT','HOME','END','PAGEUP','PAGEDOWN','UP','DOWN','LEFT','RIGHT','MINUS','EQUALS','COMMA','PERIOD','SLASH','SEMICOLON','APOSTROPHE','LEFTBRACKET','RIGHTBRACKET','BACKSLASH','GRAVE','NUMPADPLUS','NUMPADMINUS','NUMPADMULTIPLY','NUMPADDIVIDE','NUMPADDECIMAL','NUMPADENTER'}) do bases[#bases+1]=key end
    local prefixes={'','SHIFT-','CTRL-','ALT-','CTRL-SHIFT-','ALT-SHIFT-','ALT-CTRL-','ALT-CTRL-SHIFT-'}
    for _,base in ipairs(bases) do for _,prefix in ipairs(prefixes) do examine(prefix..base) end end
    return byButton
end
local function simpleMacro(id)
    local name,_,body=call(_G.GetMacroInfo,id)
    if type(name)~='string' then name='Macro '..tostring(id) end
    local _,_,reported=call(_G.GetMacroSpell,id)
    if type(body)~='string' then return name,nil,'текст макроса недоступен' end
    local cast
    for line in (body..'\n'):gmatch('(.-)\n') do
        line=A.Trim(line)
        if line~='' then
            local lower=string.lower(line)
            if lower:match('^#showtooltip') or lower:match('^#show') then
                -- A display directive is not an executable spell instruction.
            elseif lower=='/startattack' or lower=='/stopattack' then
            elseif line:match('^/run%s+CombatLogClearEntries%s*%(%s*%)%s*$') or line:match('^/script%s+CombatLogClearEntries%s*%(%s*%)%s*$') then
                -- Exact allowlist: this clears the combat log. It is a side effect,
                -- but cannot change which spell the one /cast line selects.
                -- All other /run and /script programs remain unsupported.
            else
                local arg=line:match('^/[cC][aA][sS][tT]%s+(.+)$')
                if not arg or cast or arg:find('[%[%];]') then
                    return name,nil,'условия, последовательность или неподдерживаемые команды макроса'
                end
                cast=A.Trim(arg)
            end
        end
    end
    if not cast or not A.ValidID(tonumber(reported)) then return name,nil,'GetMacroSpell не определил однозначный spellID' end
    local reportedID=tonumber(reported)
    local n,_,_,_,_,_,castID=GetSpellInfo(cast)
    if not n or not A.ValidID(castID) or castID~=reportedID then
        return name,nil,'текст /cast и GetMacroSpell не подтверждают один spellID'
    end
    return name,reportedID,nil
end
function A.CollectActions()
    if type(GetActionInfo)~='function' or type(GetBindingKey)~='function' then return nil,'API панелей/биндов недоступен.' end
    local buttons,why=discoverBindings(); if not buttons then return nil,why end
    local grouped,macros,warnings={}, {}, {}
    local names={}; for name in pairs(buttons) do names[#names+1]=name end; table.sort(names)
    for _,name in ipairs(names) do
        local b=buttons[name]
        table.sort(b.keys,function(a,b)
            local _,ca=a:gsub('%-',''); local _,cb=b:gsub('%-','')
            if ca~=cb then return ca<cb end
            return a<b
        end)
        local kind,id=call(GetActionInfo,b.slot)
        if (kind=='spell' or kind=='macro') and type(id)=='number' then
            local sid,macroName,reason
            if kind=='spell' then
                sid=id
                if type(IsPassiveSpell)=='function' and call(IsPassiveSpell,id) then sid=nil end
            else
                macroName,sid,reason=simpleMacro(id)
            end
            local target,err
            if A.ValidID(sid) then target,err=A.ResolveSpellAlias(sid) end
            local record={kind=kind,spellID=target,rawSpellID=sid,key=b.keys[1],keys=b.keys,button=name,slot=b.slot,macroID=kind=='macro' and id or nil,macroName=macroName,reason=reason or err}
            if kind=='macro' then macros[#macros+1]=record end
            if target and GetSpellInfo(target) then
                local old=grouped[target]
                if not old or (old.kind=='macro' and kind=='spell') then
                    if kind=='spell' then record.sources={record} end
                    grouped[target]=record
                elseif old.kind=='spell' and kind=='spell' and old.rawSpellID==record.rawSpellID then
                    -- Same physical spell on multiple buttons: preserve every real
                    -- binding without merging distinct alias forms or macro behavior.
                    old.sources=old.sources or {old}; old.sources[#old.sources+1]=record
                end
            elseif kind=='macro' then warnings[#warnings+1]=name..': '..(record.reason or 'spellID недоступен') end
        end
    end
    return grouped,macros,warnings
end

function A.ScanButtons()
    local actions,macros,warnings=A.CollectActions()
    if not actions then return nil,macros end
    local n=0
    for id in pairs(actions) do
        local had=A.db.colors[id]~=nil
        local c,why=A.GetColor(id); if not c then return nil,why end
        if not had then n=n+1 end
    end
    A.RebuildIconMap()
    local count=0; for _ in pairs(actions) do count=count+1 end
    return n,nil,count,#macros,#warnings
end
