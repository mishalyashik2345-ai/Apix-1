local addon, A = ...
local f=CreateFrame('Frame')
f:RegisterEvent('ADDON_LOADED')
f:RegisterEvent('PLAYER_ENTERING_WORLD')
f:RegisterEvent('PLAYER_SPECIALIZATION_CHANGED')
f:RegisterEvent('UPDATE_CHAT_WINDOWS')
f:SetScript('OnEvent',function(self,event,name)
    if event=='ADDON_LOADED' and name==addon then
        self:UnregisterEvent('ADDON_LOADED')
        A.InitConfig(); A.RebuildIconMap(); A.InitPixel()
        A.Print('Загружен. /apix scan, /apix hekili, /apix identity. Координаты UI требуют калибровки.')
    elseif event=='UPDATE_CHAT_WINDOWS' and A.InstallChatFocusHooks then
        A.InstallChatFocusHooks()
    elseif A.identityTexture and (event=='PLAYER_ENTERING_WORLD' or (event=='PLAYER_SPECIALIZATION_CHANGED' and (not name or name=='player'))) then
        -- Clear immediately; wait for the next frame for stable specialization data.
        A.currentIdentity=nil; A.identityError='обновление персонажа/специализации'; A.DiagLog('event '..event)
        A.identityTexture:SetColorTexture(0,0,0,1); A.identityElapsed=0.25
    end
end)
