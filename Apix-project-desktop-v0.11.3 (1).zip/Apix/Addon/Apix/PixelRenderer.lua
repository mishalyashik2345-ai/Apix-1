local _, A = ...
function A.IdentityPosition()
    if A.db.identityAuto then return A.db.x+A.db.size+3,A.db.y end
    return A.db.identityX,A.db.identityY
end
function A.GeometryValid()
    local x,y=A.IdentityPosition()
    return not (A.db.x < x+A.db.identitySize and x < A.db.x+A.db.size and A.db.y < y+A.db.identitySize and y < A.db.y+A.db.size)
end
local function makePixel(name)
    local f=CreateFrame('Frame',name,UIParent)
    f:SetFrameStrata('TOOLTIP'); f:SetFrameLevel(1000); f:EnableMouse(false)
    local t=f:CreateTexture(nil,'OVERLAY'); t:SetAllPoints(f); t:SetColorTexture(0,0,0,1)
    return f,t
end
local function paint(t,c,which)
    c=c or {0,0,0}
    local d=A.diag
    d.paints=d.paints+1; d[which..'Paint']=A.Hex(c)
    local ok,err=pcall(t.SetColorTexture,t,c[1]/255,c[2]/255,c[3]/255,1)
    d[which..'PaintResult']=ok and 'ok' or tostring(err)
    if not ok then A.DiagError('paint.'..which,err) end
end
-- Read-only focus checks. ChatEdit_GetActiveWindow and named edit boxes are
-- fallbacks for Legion clients/addons without GetCurrentKeyBoardFocus.
-- Unknown or failed detection must never leave a spell signal enabled.
function A.IsTextInputBlocked()
    local reliable=false
    if type(_G.GetCurrentKeyBoardFocus)=='function' then
        local ok,box=pcall(_G.GetCurrentKeyBoardFocus)
        if not ok then return true,'GetCurrentKeyBoardFocus error' end
        reliable=true
        if box then return true,'keyboard focus: edit box' end
    end
    if type(_G.ChatEdit_GetActiveWindow)=='function' then
        local ok,box=pcall(_G.ChatEdit_GetActiveWindow)
        if not ok then return true,'ChatEdit_GetActiveWindow error' end
        reliable=true
        if box then return true,'active chat edit box' end
    end
    if _G.ACTIVE_CHAT_EDIT_BOX then return true,'ACTIVE_CHAT_EDIT_BOX' end
    local n=type(_G.NUM_CHAT_WINDOWS)=='number' and math.min(math.max(_G.NUM_CHAT_WINDOWS,1),50) or 10
    for i=1,n do
        local box=_G['ChatFrame'..i..'EditBox']
        if box and type(box.HasFocus)=='function' then
            local ok,focused=pcall(box.HasFocus,box)
            if not ok then return true,'chat HasFocus error' end
            reliable=true
            if focused then return true,'chat HasFocus' end
        end
    end
    if not reliable then return true,'input-focus API unavailable' end
    return false,'no active input'
end
local function blockSpellSignal(reason)
    A.inputGuardBlocked=true; A.inputGuardReason=reason
    A.currentID=nil; A.currentColor=nil; A.currentSource='пауза: '..tostring(reason)
    if A.texture then paint(A.texture,nil,'spell') end
end
local hookedChatBoxes={}
function A.InstallChatFocusHooks()
    local n=type(_G.NUM_CHAT_WINDOWS)=='number' and math.min(math.max(_G.NUM_CHAT_WINDOWS,1),50) or 10
    for i=1,n do
        local box=_G['ChatFrame'..i..'EditBox']
        if box and not hookedChatBoxes[box] and type(box.HookScript)=='function' then
            local ok=pcall(box.HookScript,box,'OnEditFocusGained',function() blockSpellSignal('chat focus event') end)
            if ok then hookedChatBoxes[box]=true end
        end
    end
end
function A.RefreshIdentity()
    if A.testMode then paint(A.identityTexture,{0,255,255},'identity'); return end
    local d,why
    if A.db.identityEnabled then d,why=A.GetIdentity() else why='выключен' end
    A.currentIdentity=d; A.identityError=why
    paint(A.identityTexture,d and d.color,'identity')
end
local function update(elapsed)
    A.identityElapsed=(A.identityElapsed or 0)+elapsed
    if A.identityElapsed>=0.25 then A.identityElapsed=0; A.RefreshIdentity() end
    -- Test mode must not override the safety signal.
    local blocked,reason=A.IsTextInputBlocked()
    A.inputGuardBlocked=blocked; A.inputGuardReason=reason
    if blocked then A.elapsed=0; blockSpellSignal(reason); return end
    if A.testMode then
        paint(A.texture,{255,0,0},'spell'); paint(A.identityTexture,{0,255,255},'identity'); return
    end
    A.elapsed=(A.elapsed or 0)+elapsed
    if A.elapsed<1/60 then return end
    A.elapsed=0
    local id,source
    if A.db.enabled then id,source=A.GetHekiliRecommendation() else source='пиксель отключён' end
    local c,err
    if id then c,err=A.GetColor(id) end
    if id and not c then source=err end
    A.currentID=id; A.currentSource=source; A.currentColor=c
    paint(A.texture,c,'spell')
end
function A.SetTestMode(enabled)
    A.testMode=enabled
    if enabled then A.currentID=nil; A.currentColor=nil; A.currentSource='test mode'; A.currentIdentity=nil end
    A.DiagLog('testMode='..tostring(enabled))
    local ok,err=pcall(function() A.RefreshIdentity(); update(1) end)
    if not ok then A.DiagError('testMode',err) end
end
function A.InitPixel()
    A.frame,A.texture=makePixel('ApixPixel')
    A.identityFrame,A.identityTexture=makePixel('ApixIdentityPixel')
    if not A.GeometryValid() then A.db.identityAuto=true; A.Print('Пиксели перекрывались; включена автоматическая позиция identity.') end
    A.UpdatePixelGeometry()
    A.InstallChatFocusHooks()
    A.DiagLog('InitPixel')
    local ok,err=pcall(A.RefreshIdentity)
    if not ok then A.DiagError('initial identity',err) end
    A.frame:SetScript('OnUpdate',function(_,elapsed)
        local diag=A.diag
        diag.updates=diag.updates+1; diag.lastElapsed=elapsed
        if type(GetTime)=='function' then diag.lastUpdateTime=GetTime() end
        local success,why=pcall(update,elapsed)
        if not success then
            A.DiagError('OnUpdate',why)
            -- Fail closed: never leave an old command visible after an error.
            paint(A.texture,nil,'spell'); paint(A.identityTexture,nil,'identity')
        end
    end)
end
function A.UpdatePixelGeometry()
    local f=A.frame
    f:ClearAllPoints(); f:SetPoint('TOPLEFT',UIParent,'TOPLEFT',A.db.x,-A.db.y)
    f:SetSize(A.db.size,A.db.size); f:Show()
    local x,y=A.IdentityPosition(); local g=A.identityFrame
    g:ClearAllPoints(); g:SetPoint('TOPLEFT',UIParent,'TOPLEFT',x,-y)
    g:SetSize(A.db.identitySize,A.db.identitySize); g:Show()
    A.DiagLog('geometry: spell='..A.db.x..','..A.db.y..' size='..A.db.size..'; identity='..x..','..y..' size='..A.db.identitySize)
end
