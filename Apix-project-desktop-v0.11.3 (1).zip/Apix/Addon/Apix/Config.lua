local _, A = ...
-- Legion 7.3.5 replacement -> base. User-supplied overrides in SavedVariables
-- always take precedence; false disables even a built-in entry.
A.DefaultSpellAliases={
    [115356]=17364,   -- Shaman: Windstrike -> Stormstrike
    [114074]=188443,  -- Shaman: Lava Beam -> Chain Lightning
    [201427]=162794,  -- Demon Hunter: Annihilation -> Chaos Strike
    [210152]=188499,  -- Demon Hunter: Death Sweep -> Blade Dance
    [235964]=203782,  -- Demon Hunter: Sever -> Shear
    [198034]=184575,  -- Paladin: Divine Hammer -> Blade of Justice
    [204019]=53595,   -- Paladin: Blessed Hammer -> Hammer of the Righteous
    [213652]=184092,  -- Paladin: Hand of the Protector -> Light of the Protector
    [200758]=53,      -- Rogue: Gloomblade -> Backstab
    [207311]=55090,   -- Death Knight: Clawing Shadows -> Scourge Strike
    [152280]=43265,   -- Death Knight: Defile -> Death and Decay
    [102543]=106951,  -- Druid (Feral): Incarnation -> Berserk
    [212653]=1953,    -- Mage: Shimmer -> Blink
    [123040]=34433,   -- Priest: Mindbender -> Shadowfiend
    [200174]=34433,   -- Shadow Priest: Mindbender -> Shadowfiend
    [115008]=109132,  -- Monk: Chi Torpedo -> Roll
    [217200]=120679,  -- Hunter: Dire Frenzy -> Dire Beast
    [198590]=234153,  -- Warlock: Drain Soul -> Drain Life (Legion)
    [202168]=34428,   -- Warrior: Impending Victory -> Victory Rush
}
function A.InitConfig()
    if type(ApixDB) ~= 'table' then ApixDB = {} end
    local d = ApixDB
    if type(d.colors)~='table' then d.colors={} end
    if type(d.keys)~='table' then d.keys={} end
    if type(d.actionMap)~='table' then d.actionMap={} end
    if type(d.spellAliases)~='table' then d.spellAliases={} end
    if type(d.identities)~='table' then d.identities={} end
    if type(d.identityEnabled)~='boolean' then d.identityEnabled=true end
    if type(d.identityAuto)~='boolean' then d.identityAuto=true end
    if type(d.identitySize)~='number' then d.identitySize=25 end
    if type(d.identityX)~='number' then d.identityX=32 end
    if type(d.identityY)~='number' then d.identityY=2 end
    if type(d.enabled)~='boolean' then d.enabled=true end
    if type(d.x)~='number' then d.x=2 end
    if type(d.y)~='number' then d.y=2 end
    if type(d.size)~='number' then d.size=25 end
    -- Old installs defaulted to display 1. Migrate that default once; explicit
    -- non-default selections survive. A new explicit /apix display 1 remains manual.
    if d.displayAutoMigration~=true then
        if type(d.display)~='string' or d.display=='1' then d.display='auto' end
        d.displayAutoMigration=true
    end
    if type(d.display)~='string' then d.display='auto' end
    if type(d.sequence)~='number' then d.sequence=0 end
    A.db=d
end
