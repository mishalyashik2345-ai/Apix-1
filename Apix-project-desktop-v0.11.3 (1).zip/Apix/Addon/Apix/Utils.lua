local _, A = ...
function A.Print(msg) DEFAULT_CHAT_FRAME:AddMessage('|cff33ccffApix:|r '..tostring(msg)) end
function A.Trim(s) return (s or ''):match('^%s*(.-)%s*$') end
function A.Quote(s)
    s = tostring(s or '')
    return '"' .. s:gsub('[%z\1-\31\\"]', function(c)
        local map = { ['"']='\\"', ['\\']='\\\\', ['\b']='\\b', ['\f']='\\f', ['\n']='\\n', ['\r']='\\r', ['\t']='\\t' }
        return map[c] or string.format('\\u%04x', string.byte(c))
    end) .. '"'
end
function A.Hex(c) return string.format('#%02X%02X%02X', c[1], c[2], c[3]) end
function A.ValidID(id) return type(id)=='number' and id>0 and id<2147483648 and id==math.floor(id) end
function A.SpellName(id) return GetSpellInfo(id) or ('Spell '..id) end
