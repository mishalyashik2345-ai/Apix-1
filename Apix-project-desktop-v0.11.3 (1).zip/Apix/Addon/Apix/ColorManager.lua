local _, A = ...
-- RGB lattice spacing is 23: independent per-channel tolerance 10 cannot
-- match two distinct lattice colours, provided capture error is <= 10.
local function hsv(h, s, v)
    local p = h * 6; local i = math.floor(p); local f = p-i
    local x, y, z = v*(1-s), v*(1-s*f), v*(1-s*(1-f))
    local r,g,b
    i=i%6
    if i==0 then r,g,b=v,z,x elseif i==1 then r,g,b=y,v,x
    elseif i==2 then r,g,b=x,v,z elseif i==3 then r,g,b=x,y,v
    elseif i==4 then r,g,b=z,x,v else r,g,b=v,x,y end
    return {math.floor(r*255+0.5),math.floor(g*255+0.5),math.floor(b*255+0.5)}
end

local N=1728 -- 12^3, including reserved black.
local function palette(index)
    local x=index%N
    return {math.floor(x/144)*23,math.floor(x/12)%12*23,(x%12)*23}
end
function A.IsColor(c)
    if type(c)~='table' then return false end
    for i=1,3 do if type(c[i])~='number' or c[i]<0 or c[i]>255 or c[i]~=math.floor(c[i]) then return false end end
    return c[1]~=0 or c[2]~=0 or c[3]~=0
end
function A.ColorsConflict(a,b,tolerance)
    local t=tolerance or 10
    return math.abs(a[1]-b[1])<=2*t and math.abs(a[2]-b[2])<=2*t and math.abs(a[3]-b[3])<=2*t
end
function A.UsedColor(c, except)
    for id, v in pairs(A.db.colors) do
        if tonumber(id)~=except and A.IsColor(v) and A.Hex(v)==A.Hex(c) then return true end
    end
    return false
end
function A.NearColor(c,except)
    for id,v in pairs(A.db.colors) do
        if tonumber(id)~=except and A.IsColor(v) and A.ColorsConflict(c,v,10) then return tonumber(id) or tostring(id) end
    end
end
function A.GetColor(id)
    if not A.ValidID(id) then return nil,'invalid spell ID' end
    local c=A.db.colors[id]
    if c then
        if not A.IsColor(c) or A.UsedColor(c,id) then return nil,'invalid/duplicate stored color; fix with /apix color' end
        return c
    end
    -- HSV is the primary generator; saved colours from earlier versions are
    -- considered too. A bounded search avoids a long freeze on a dense palette.
    for i=1,1024 do
        A.db.sequence=A.db.sequence+1
        local n=A.db.sequence
        local layer=math.floor((n-1)/64)
        c=hsv((n*0.618033988749895)%1,({1,.82,.65,.48})[(layer%4)+1],({1,.82,.65,.48})[(math.floor(layer/4)%4)+1])
        if A.IsColor(c) and not A.ColorsConflict(c,{0,0,0},10) and not A.NearColor(c,id) then A.db.colors[id]=c; return c end
    end
    -- If the bounded HSV search is exhausted, try a permuted RGB lattice.
    for i=1,N-1 do
        local index=(i*577)%N
        c=palette(index)
        if A.IsColor(c) and not A.NearColor(c,id) then A.db.colors[id]=c; return c end
    end
    return nil,'нет безопасного цвета; /apix colors rebuild CONFIRM'
end
function A.SetColor(id,hex)
    if not A.ValidID(id) or type(hex)~='string' or not hex:match('^#%x%x%x%x%x%x$') then return false,'Ожидаются spellID и #RRGGBB.' end
    local c={tonumber(hex:sub(2,3),16),tonumber(hex:sub(4,5),16),tonumber(hex:sub(6,7),16)}
    if not A.IsColor(c) or A.ColorsConflict(c,{0,0,0},10) then return false,'Чёрный и близкие к нему цвета зарезервированы.' end
    local other=A.NearColor(c,id)
    if other then return false,'Цвет слишком близок к spellID '..tostring(other)..' (tolerance 10).' end
    A.db.colors[id]=c; return true
end
function A.RebuildColors()
    local ids,seen={},{}
    for raw in pairs(A.db.colors) do
        local id=tonumber(raw)
        if not A.ValidID(id) or seen[id] then return false,'Некорректный или повторный spellID в сохранённых цветах.' end
        seen[id]=true; ids[#ids+1]=id
    end
    table.sort(ids)
    if #ids>N-1 then return false,'Больше 1727 цветов; перестройка отменена.' end
    local new={}
    for i,id in ipairs(ids) do new[id]=palette((i*577)%N) end
    A.db.colors=new; A.db.paletteVersion=2
    A.RebuildIconMap()
    return true,#ids
end
