local _, A = ...
local function component(s) return #s..':'..s end
local function keyFor(d)
    return component(d.name)..component(d.realm)..component(d.class)..':'..d.specID
end
local function hash(key)
    -- Byte-based, deterministic 24-bit value; not a reversible identity.
    local n=5381
    for i=1,#key do n=(n*33+string.byte(key,i))%16777216 end
    if n==0 then n=65793 end
    return { math.floor(n/65536)%256,math.floor(n/256)%256,n%256 }
end
local function collision(key,c)
    for other,hex in pairs(A.db.identities) do
        if other~=key and type(hex)=='string' and hex:upper()==A.Hex(c) then return true end
    end
    return false
end
function A.GetIdentity()
    if type(UnitName)~='function' or type(GetRealmName)~='function' or type(UnitClass)~='function' or type(GetSpecialization)~='function' or type(GetSpecializationInfo)~='function' then
        return nil,'API персонажа или специализации недоступно'
    end
    local name,realm=UnitName('player')
    realm=(type(realm)=='string' and realm~='' and realm) or GetRealmName()
    local className,class=UnitClass('player')
    local idx=GetSpecialization()
    local specID,specName
    if idx then specID,specName=GetSpecializationInfo(idx) end
    if type(name)~='string' or name=='' or type(realm)~='string' or realm=='' or type(class)~='string' or class=='' or not A.ValidID(specID) then
        return nil,'персонаж/мир/класс/специализация ещё недоступны'
    end
    local d={name=name,realm=realm,class=class,className=className or class,specID=specID,specName=specName or tostring(specID)}
    local key=keyFor(d)
    local saved=A.db.identities[key]
    local c
    if saved~=nil then
        if type(saved)~='string' or not saved:match('^#%x%x%x%x%x%x$') then return nil,'некорректный сохранённый цвет identity' end
        c={tonumber(saved:sub(2,3),16),tonumber(saved:sub(4,5),16),tonumber(saved:sub(6,7),16)}
    else c=hash(key) end
    if not A.IsColor(c) then return nil,'чёрный identity-цвет запрещён' end
    if collision(key,c) then return nil,'коллизия identity-цвета; задайте /apix identity color #RRGGBB' end
    A.db.identities[key]=A.Hex(c)
    d.color=c; d.key=key
    return d
end
function A.SetIdentityColor(hex)
    local d,why=A.GetIdentity()
    -- In case the generated color itself collided, obtain the key without relying on it.
    if not d then
        if type(UnitName)~='function' or type(GetRealmName)~='function' or type(UnitClass)~='function' or type(GetSpecialization)~='function' or type(GetSpecializationInfo)~='function' then return false,why end
        local name,realm=UnitName('player'); realm=(realm and realm~='' and realm) or GetRealmName()
        local _,class=UnitClass('player'); local idx=GetSpecialization(); local id=idx and GetSpecializationInfo(idx)
        if type(name)~='string' or type(realm)~='string' or type(class)~='string' or not A.ValidID(id) then return false,why end
        d={name=name,realm=realm,class=class,specID=id}; d.key=keyFor(d)
    end
    if type(hex)~='string' or not hex:match('^#%x%x%x%x%x%x$') then return false,'Ожидается #RRGGBB.' end
    local c={tonumber(hex:sub(2,3),16),tonumber(hex:sub(4,5),16),tonumber(hex:sub(6,7),16)}
    if not A.IsColor(c) then return false,'Чёрный зарезервирован.' end
    if collision(d.key,c) then return false,'Этот цвет уже занят другим персонажем/спеком в ApixDB.' end
    A.db.identities[d.key]=A.Hex(c); return true
end
function A.IdentityJSON(d)
    if not d then return 'null' end
    return '{"name":'..A.Quote(d.name)..',"realm":'..A.Quote(d.realm)..',"class":'..A.Quote(d.class)..',"className":'..A.Quote(d.className)..',"specID":'..d.specID..',"specName":'..A.Quote(d.specName)..',"color":'..A.Quote(A.Hex(d.color))..'}'
end
