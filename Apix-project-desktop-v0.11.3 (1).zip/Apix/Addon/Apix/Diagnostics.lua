local _, A = ...
A.diag={ updates=0, paints=0, errors=0, log={} }
function A.DiagLog(message)
    local d=A.diag
    local time=type(GetTime)=='function' and string.format('%.2f',GetTime()) or '?'
    d.log[#d.log+1]=time..' '..tostring(message)
    if #d.log>30 then table.remove(d.log,1) end
end
function A.DiagError(where,err)
    A.diag.errors=A.diag.errors+1
    local message=tostring(where)..': '..tostring(err)
    if message~=A.diag.lastError then A.DiagLog('ERROR '..message) end
    A.diag.lastError=message
end

-- Deliberately plain Lua 5.1: no xpcall handler, debugstack or introspection
-- of nonstandard APIs. Each optional getter is guarded independently.
function A.BuildDiagnostics()
    local lines={'APIX DIAGNOSTICS v0.6.6', 'Может содержать имя персонажа и мир.'}
    local function add(label,fn)
        local ok,v1,v2,v3,v4=pcall(fn)
        if not ok then
            lines[#lines+1]=label..'=ERROR: '..tostring(v1)
            return
        end
        local text=tostring(v1)
        if v2~=nil then text=text..', '..tostring(v2) end
        if v3~=nil then text=text..', '..tostring(v3) end
        if v4~=nil then text=text..', '..tostring(v4) end
        lines[#lines+1]=label..'='..text
    end
    local function get(obj,name,...)
        if not obj then return 'object missing' end
        if type(obj[name])~='function' then return 'method unavailable' end
        return obj[name](obj,...)
    end
    local function rgb(c)
        if not c then return 'nil' end
        return tostring(c[1])..','..tostring(c[2])..','..tostring(c[3])
    end
    add('addon_version',function() return GetAddOnMetadata('Apix','Version') end)
    add('hekili_version',function() return GetAddOnMetadata('Hekili','Version') end)
    add('game_build',function() return GetBuildInfo() end)
    add('clock',function() return GetTime() end)
    add('screen_size',function() return GetScreenWidth(),GetScreenHeight() end)
    add('cvar_uiscale',function() return GetCVar('uiScale'),GetCVar('useUiScale') end)
    add('test_mode',function() return A.testMode end)
    add('input_guard',function() return A.inputGuardBlocked,A.inputGuardReason end)
    add('input_focus_apis',function() return type(_G.GetCurrentKeyBoardFocus),type(_G.ChatEdit_GetActiveWindow) end)
    add('update_count',function() return A.diag.updates end)
    add('last_update_time',function() return A.diag.lastUpdateTime end)
    add('last_update_elapsed',function() return A.diag.lastElapsed end)
    add('paint_count',function() return A.diag.paints end)
    add('error_count',function() return A.diag.errors end)
    add('last_error',function() return A.diag.lastError end)
    add('spell_last_paint',function() return A.diag.spellPaint,A.diag.spellPaintResult end)
    add('identity_last_paint',function() return A.diag.identityPaint,A.diag.identityPaintResult end)
    add('rendered_spell',function() return A.currentID,rgb(A.currentColor),A.currentSource end)
    add('identity_cached',function()
        local d=A.currentIdentity
        if not d then return nil,A.identityError end
        return d.name,d.realm,d.class,d.specID
    end)
    add('identity_cached_color',function() return A.currentIdentity and rgb(A.currentIdentity.color) end)
    add('spell_now',function() return A.GetHekiliRecommendation() end)
    add('identity_now',function()
        local d,err=A.GetIdentity()
        if not d then return nil,err end
        return d.name,d.realm,d.class,d.specID
    end)
    add('identity_now_color',function() local d=A.GetIdentity(); return d and rgb(d.color) end)
    add('spell_config',function() return A.db.enabled,A.db.x,A.db.y,A.db.size end)
    add('identity_config',function()
        local x,y=A.IdentityPosition(); return A.db.identityEnabled,x,y,A.db.identitySize
    end)
    add('hekili_config',function() return A.db.display,A.db.iconFallback end)
    add('hekili_selected',function() local d,source=A.FindHekiliDisplay(); return source, d and d.Active end)
    lines[#lines+1]='[hekili_displays]'
    local h=_G.Hekili
    local displays=h and h.DB and h.DB.profile and h.DB.profile.displays
    if type(displays)=='table' then
        for i,conf in ipairs(displays) do
            if i>100 then lines[#lines+1]='truncated'; break end
            add('display_'..i,function()
                local f=_G['HekiliDisplay'..i]
                if not f and type(h.DisplayPool)=='table' then f=h.DisplayPool[i] or h.DisplayPool[tostring(i)] end
                local v=f and f.IsVisible and f:IsVisible()
                local alpha=f and f.GetEffectiveAlpha and f:GetEffectiveAlpha()
                local rec=f and type(f.Recommendations)=='table' and f.Recommendations[1]
                local action=type(rec)=='table' and (rec.actionName or rec.actionID or rec.spellID) or nil
                return 'name='..tostring(conf.Name)..' spec='..tostring(conf.Specialization)..' enabled='..tostring(conf.Enabled),
                    'active='..tostring(f and f.Active)..' visible='..tostring(v)..' alpha='..tostring(alpha),
                    'queue1='..tostring(action)..' (может быть устаревшей, если скрыт)'
            end)
        end
    else lines[#lines+1]='profile.displays unavailable' end
    add('geometry_valid',function() return A.GeometryValid() end)
    local function frame(label,obj)
        lines[#lines+1]='['..label..']'
        local names={'IsShown','IsVisible','GetAlpha','GetEffectiveAlpha','GetEffectiveScale','GetFrameStrata','GetFrameLevel','GetWidth','GetHeight','GetLeft','GetRight','GetTop','GetBottom'}
        for _,name in ipairs(names) do add(name,function() return get(obj,name) end) end
    end
    local function texture(label,obj)
        lines[#lines+1]='['..label..']'
        local names={'IsShown','IsVisible','GetAlpha','GetTexture','GetVertexColor','GetDrawLayer','GetWidth','GetHeight'}
        for _,name in ipairs(names) do add(name,function() return get(obj,name) end) end
    end
    add('spell_frame_onupdate',function() return get(A.frame,'GetScript','OnUpdate') end)
    frame('UIParent',UIParent); frame('spell_frame',A.frame); texture('spell_texture',A.texture)
    frame('identity_frame',A.identityFrame); texture('identity_texture',A.identityTexture)
    lines[#lines+1]='[recent_events]'
    add('events',function() return table.concat(A.diag.log,' | ') end)
    return table.concat(lines,'\n')
end

-- Read-only panel diagnostics. Does not read macro bodies or modify bindings.
function A.BuildBindingDiagnostics()
    local out={'APIX PANEL DIAGNOSTICS v0.6.6',
        'Read only. Includes addon names, binding names, keys, frame names and action IDs; no macro bodies.'}
    local function safe(fn,...)
        if type(fn)~='function' then return nil end
        local ok,a,b,c,d=pcall(fn,...)
        if ok then return a,b,c,d end
        return nil
    end
    local function t(v) if v==nil then return '-' end return tostring(v):gsub('[\r\n]',' ') end
    out[#out+1]='game='..t(safe(_G.GetBuildInfo))..' addon='..t(safe(_G.GetAddOnMetadata,'Apix','Version'))
    out[#out+1]='api: GetActionInfo='..type(_G.GetActionInfo)..' GetBindingKey='..type(_G.GetBindingKey)..' GetBindingAction='..type(_G.GetBindingAction)..' EnumerateFrames='..type(_G.EnumerateFrames)
    out[#out+1]='actionPage='..t(safe(_G.GetActionBarPage))
    out[#out+1]='[loaded addons]'
    local num=safe(_G.GetNumAddOns)
    if type(num)=='number' then
        for i=1,math.min(num,1000) do
            local name=safe(_G.GetAddOnInfo,i)
            if name and safe(_G.IsAddOnLoaded,i) then out[#out+1]=t(name) end
        end
    else out[#out+1]='unavailable' end
    out[#out+1]='[nonempty action slots 1..120]'
    local slotcount=0
    for i=1,120 do
        local kind,id,sub=safe(_G.GetActionInfo,i)
        if kind then out[#out+1]='slot='..i..' kind='..t(kind)..' id='..t(id)..' sub='..t(sub); slotcount=slotcount+1 end
    end
    out[#out+1]='nonempty_slots='..slotcount
    out[#out+1]='[game bindings]'
    local n=safe(_G.GetNumBindings); local kcount=0
    if type(n)=='number' then
        for i=1,math.min(n,3000) do
            local command=safe(_G.GetBinding,i)
            local k1,k2=safe(_G.GetBindingKey,command)
            if type(command)=='string' and (k1 or k2) then
                -- Limit to actions and clicked buttons; do not expose chat or unrelated bindings.
                if command:find('ACTIONBUTTON',1,true) or command:find('MULTIACTIONBAR',1,true) or command:find('CLICK ',1,true) or command:find('SPELL ',1,true) or command:find('MACRO ',1,true) then
                    local r1=k1 and safe(_G.GetBindingAction,k1,true); local r2=k2 and safe(_G.GetBindingAction,k2,true)
                    out[#out+1]='cmd='..t(command)..' keys='..t(k1)..','..t(k2)..' effective='..t(r1)..','..t(r2)
                    kcount=kcount+1
                    if kcount>=180 then out[#out+1]='TRUNCATED'; break end
                end
            end
        end
    else out[#out+1]='GetNumBindings unavailable' end
    out[#out+1]='[frames: candidate action buttons]'
    local examined,emitted=0,0
    local visibleEntries,otherEntries={},{}
    local f=nil
    if type(_G.EnumerateFrames)=='function' then
        while examined<30000 and emitted<1200 do
            local ok,nextFrame=pcall(_G.EnumerateFrames,f)
            if not ok or not nextFrame then break end
            f=nextFrame; examined=examined+1
            local name=safe(f.GetName,f)
            local typ=safe(f.GetAttribute,f,'type')
            local attr=safe(f.GetAttribute,f,'action')
            local property=f.action
            local g1,g2=safe(f.GetAction,f)
            local possible=(type(attr)=='number' and attr>0) or (type(property)=='number' and property>0) or typ=='action' or typ=='spell' or typ=='macro' or g1=='action' or g1=='spell' or g1=='macro'
            if name and possible then
                local visible=safe(f.IsVisible,f); local shown=safe(f.IsShown,f)
                local key1,key2=safe(_G.GetBindingKey,'CLICK '..name..':LeftButton')
                local sid=(type(property)=='number' and property>0 and property) or (type(attr)=='number' and attr>0 and attr) or (g1=='action' and g2)
                local kind,id=safe(_G.GetActionInfo,sid)
                local paged=safe(_G.ActionButton_GetPagedID,f)
                local calc=safe(_G.ActionButton_CalculateAction,f)
                local row='name='..t(name)..' visible='..t(visible)..' shown='..t(shown)..' type='..t(typ)..' action='..t(attr)..' field='..t(property)..' GetAction='..t(g1)..','..t(g2)..' paged='..t(paged)..' calc='..t(calc)..' slotInfo='..t(kind)..','..t(id)..' clickKeys='..t(key1)..','..t(key2)
                local target=visible and visibleEntries or otherEntries
                target[#target+1]=row
                emitted=emitted+1
            end
        end
        for i=1,math.min(#visibleEntries,120) do out[#out+1]=visibleEntries[i] end
        for i=1,math.min(#otherEntries,30) do out[#out+1]=otherEntries[i] end
    else out[#out+1]='EnumerateFrames unavailable' end
    out[#out+1]='frames_examined='..examined..' candidates='..emitted..' visible='..#visibleEntries..' other='..#otherEntries..((examined>=30000 or emitted>=1200 or #visibleEntries>120 or #otherEntries>30) and ' (limit reached)' or '')
    out[#out+1]='[apix scanner]'
    local ok,actions,macros,warnings=pcall(A.CollectActions)
    if not ok then out[#out+1]='ERROR='..t(actions)
    elseif not actions then out[#out+1]='ERROR='..t(macros)
    else
        local count=0; for id,a in pairs(actions) do count=count+1; out[#out+1]='spell='..t(id)..' button='..t(a.button)..' slot='..t(a.slot)..' key='..t(a.key) end
        out[#out+1]='triggers='..count..' macros='..#macros..' warnings='..#warnings
    end
    return table.concat(out,'\n')
end

-- Explicit opt-in: macro bodies can include private names and messages.
function A.BuildMacroDiagnostics()
    local out={'APIX MACRO DIAGNOSTICS v0.6.6',
        'ВНИМАНИЕ: тексты макросов могут содержать личные данные и команды чата. Проверьте перед отправкой.'}
    local actions,macros=A.CollectActions()
    if not actions then out[#out+1]='Ошибка сканирования: '..tostring(macros); return table.concat(out,'\n') end
    out[#out+1]='Макросы на обнаруженных видимых привязанных кнопках: '..#macros
    for _,m in ipairs(macros) do
        local name,body,reported,reportName
        if type(GetMacroInfo)=='function' then
            local ok,a,icon,b=pcall(GetMacroInfo,m.macroID)
            if ok then name,body=a,b end
        end
        if type(GetMacroSpell)=='function' then
            local ok,a,b,c=pcall(GetMacroSpell,m.macroID)
            if ok then reportName,reported=a,c end
        end
        out[#out+1]='--- macroID='..tostring(m.macroID)..' name='..tostring(name or m.macroName)..' key='..tostring(m.key)..' button='..tostring(m.button)..' slot='..tostring(m.slot)..' ---'
        out[#out+1]='GetMacroSpell: name='..tostring(reportName)..' id='..tostring(reported)..'; export_reason='..tostring(m.reason)
        out[#out+1]='BODY:'
        out[#out+1]=type(body)=='string' and body or '(недоступен)'
        out[#out+1]='END BODY'
    end
    return table.concat(out,'\n')
end
