local _, A = ...
local exportFrame
function A.BuildExport()
    local actions,macros,warnings=A.CollectActions()
    if not actions then return nil,macros end
    local ids={}; for id in pairs(actions) do ids[#ids+1]=id end; table.sort(ids)
    local colors,entries={},{}
    for _,id in ipairs(ids) do
        local c,err=A.GetColor(id)
        if not c then return nil,'Экспорт остановлен: '..id..' '..tostring(err) end
        if A.ColorsConflict(c,{0,0,0},10) then return nil,'Цвет '..id..' слишком близок к чёрному; /apix colors rebuild CONFIRM' end
        for other,prev in pairs(colors) do
            if A.ColorsConflict(c,prev,10) then
                return nil,'Цвета '..id..' и '..other..' пересекаются при tolerance 10. Остановите бот и выполните /apix colors rebuild CONFIRM'
            end
        end
        colors[id]=c
        local a=actions[id]
        local keys,unique={},{}
        local sources=a.sources or {a}; local sourceEntries={}
        for _,src in ipairs(sources) do
            local sk={}
            for _,key in ipairs(src.keys) do
                sk[#sk+1]=A.Quote(key)
                if not unique[key] then unique[key]=true; keys[#keys+1]=A.Quote(key) end
            end
            sourceEntries[#sourceEntries+1]='{"button":'..A.Quote(src.button)..',"slot":'..src.slot..',"keys":['..table.concat(sk,',')..']}'
        end
        entries[#entries+1]='{"spellID":'..id..',"spellName":'..A.Quote(A.SpellName(id))..',"color":'..A.Quote(A.Hex(c))..',"key":'..A.Quote(a.key)..',"keys":['..table.concat(keys,',')..'],"kind":'..A.Quote(a.kind)..',"button":'..A.Quote(a.button)..',"slot":'..a.slot..',"rawSpellID":'..(a.rawSpellID or 'null')..',"bindings":['..table.concat(sourceEntries,',')..'],"macroName":'..(a.macroName and A.Quote(a.macroName) or 'null')..'}'
    end
    local macroEntries={}
    for _,m in ipairs(macros) do
        local mkeys={}; for _,key in ipairs(m.keys) do mkeys[#mkeys+1]=A.Quote(key) end
        macroEntries[#macroEntries+1]='{"macroID":'..m.macroID..',"name":'..A.Quote(m.macroName)..',"key":'..A.Quote(m.key)..',"keys":['..table.concat(mkeys,',')..'],"button":'..A.Quote(m.button)..',"slot":'..m.slot..',"spellID":'..(m.spellID or 'null')..',"selectedForTrigger":'..(m.spellID and actions[m.spellID]==m and 'true' or 'false')..',"reason":'..(m.reason and A.Quote(m.reason) or 'null')..'}'
    end
    local aliases={}
    for _,id in ipairs(A.ConfiguredAliasIDs()) do
        local target,why=A.ResolveSpellAlias(id)
        if not target then return nil,'Ошибка alias '..id..': '..tostring(why) end
        aliases[#aliases+1]='{"spellID":'..id..',"targetSpellID":'..target..'}'
    end
    local identity=A.db.identityEnabled and A.GetIdentity() or nil
    local x,y=A.IdentityPosition()
    return 'APIX_EXPORT:{"schemaVersion":2,"identity":'..A.IdentityJSON(identity)..',"pixelLayout":{"unit":"ui","spell":{"x":'..A.db.x..',"y":'..A.db.y..',"size":'..A.db.size..'},"identity":{"x":'..x..',"y":'..y..',"size":'..A.db.identitySize..'}},"colorTolerance":10,"bindingSource":"visible-action-buttons","aliases":['..table.concat(aliases,',')..'],"triggers":['..table.concat(entries,',')..'],"macros":['..table.concat(macroEntries,',')..']}',nil,#ids,#macros,#warnings
end

local function ShowCopyWindow(text,titleText)
    if not exportFrame then
        local f=CreateFrame('Frame','ApixExportFrame',UIParent)
        f:SetSize(600,330); f:SetPoint('CENTER'); f:SetFrameStrata('DIALOG')
        f:SetBackdrop({bgFile='Interface\\DialogFrame\\UI-DialogBox-Background',edgeFile='Interface\\DialogFrame\\UI-DialogBox-Border',edgeSize=24,insets={left=6,right=6,top=6,bottom=6}})
        f:EnableMouse(true); f:SetMovable(true); f:RegisterForDrag('LeftButton'); f:SetScript('OnDragStart',f.StartMoving); f:SetScript('OnDragStop',f.StopMovingOrSizing)
        local title=f:CreateFontString(nil,'OVERLAY','GameFontNormal'); title:SetPoint('TOP',0,-15); f.title=title
        local close=CreateFrame('Button',nil,f,'UIPanelCloseButton'); close:SetPoint('TOPRIGHT',-3,-3)
        local scroll=CreateFrame('ScrollFrame','ApixExportScroll',f,'UIPanelScrollFrameTemplate'); scroll:SetPoint('TOPLEFT',20,-45); scroll:SetPoint('BOTTOMRIGHT',-38,20)
        local edit=CreateFrame('EditBox',nil,scroll); edit:SetMultiLine(true); edit:SetAutoFocus(false); edit:SetMaxLetters(0); edit:SetFontObject('ChatFontNormal'); edit:SetWidth(530); edit:SetScript('OnEscapePressed',function() f:Hide() end)
        scroll:SetScrollChild(edit); f.edit=edit; exportFrame=f
    end
    exportFrame.title:SetText(titleText..' — Ctrl+A, Ctrl+C; Esc закрывает')
    exportFrame.edit:SetText(text); exportFrame:Show(); exportFrame.edit:SetFocus(); exportFrame.edit:HighlightText()
end
local function Export()
    local text,err,count,macroCount,warningCount=A.BuildExport()
    if not text then A.Print(err); return end
    ShowCopyWindow(text,'Apix: экспорт')
    A.Print('Экспорт открыт. Спеллов: '..count..', макросов: '..macroCount..', нераспознанных макросов: '..warningCount..'. Ctrl+A, Ctrl+C.')
end
local function integer(s) local n=tonumber(s); if n and n==math.floor(n) then return n end end
local function applyGeometry(changes)
    local before={}
    for k,v in pairs(changes) do before[k]=A.db[k]; A.db[k]=v end
    if not A.GeometryValid() then
        for k,v in pairs(before) do A.db[k]=v end
        A.Print('Блоки перекрываются; позиция или размер не изменены.'); return false
    end
    A.UpdatePixelGeometry(); return true
end
local function printIdentity()
    local x,y=A.IdentityPosition(); local d,why
    if A.db.identityEnabled then d,why=A.GetIdentity() else why='выключен' end
    A.Print('Identity: x='..x..', y='..y..', size='..A.db.identitySize..', auto='..tostring(A.db.identityAuto)..', цвет='..(d and A.Hex(d.color) or '#000000'))
    if d then A.Print(d.name..' - '..d.realm..'; '..d.class..' ('..d.className..'); '..d.specName..' (specID='..d.specID..')')
    else A.Print('Identity: '..tostring(why)) end
end
function A.Command(input)
    local cmd, rest=A.Trim(input):match('^(%S+)%s*(.-)$'); cmd=string.lower(cmd or '')
    if cmd=='status' then
        local id,why=A.GetHekiliRecommendation(); local c=id and A.GetColor(id)
        A.Print('enabled='..tostring(A.db.enabled)..', display='..A.db.display..', x='..A.db.x..', y='..A.db.y..', size='..A.db.size)
        A.Print('spell='..tostring(id or 'нет')..(id and (' '..A.SpellName(id)) or '')..', цвет='..(c and A.Hex(c) or '#000000')..', источник='..tostring(why))
        printIdentity()
    elseif cmd=='debug' then
        local ok,text=pcall(A.BuildDiagnostics)
        if not ok then text='APIX DIAGNOSTICS v0.6.4: СБОЙ СБОРКИ\n'..tostring(text)..'\nПроверьте, что все файлы аддона обновлены.' end
        local shown,windowError=pcall(ShowCopyWindow,text,'Apix: диагностика')
        if not shown then A.Print('Ошибка окна диагностики: '..tostring(windowError)); A.Print(text); return end
        A.Print('Открыта диагностика. Ctrl+A, Ctrl+C. Отчёт содержит имя персонажа и мир.')
    elseif cmd=='binddebug' then
        local ok,text=pcall(A.BuildBindingDiagnostics)
        if not ok then text='APIX PANEL DIAGNOSTICS: ошибка сбора: '..tostring(text) end
        local shown,windowError=pcall(ShowCopyWindow,text,'Apix: диагностика панелей')
        if not shown then A.Print('Ошибка окна: '..tostring(windowError)); A.Print(text); return end
        A.Print('Диагностика панелей открыта. Ctrl+A, Ctrl+C. Отчёт содержит список аддонов и названия клавиш.')
    elseif cmd=='macrodebug' then
        local ok,text=pcall(A.BuildMacroDiagnostics)
        if not ok then text='APIX MACRO DIAGNOSTICS: ошибка сбора: '..tostring(text) end
        local shown,windowError=pcall(ShowCopyWindow,text,'Apix: тексты макросов')
        if not shown then A.Print('Ошибка окна: '..tostring(windowError)); return end
        A.Print('Открыты тексты макросов с видимых кнопок. Перед отправкой проверьте личные данные.')
    elseif cmd=='test' then
        if rest~='on' and rest~='off' then A.Print('Используйте /apix test on|off. Перед тестом остановите внешнее приложение!'); return end
        A.SetTestMode(rest=='on')
        A.Print(rest=='on' and 'ТЕСТ: первый блок красный, второй голубой. Внешнее приложение должно быть остановлено!' or 'Тест выключен; восстановлен обычный режим.')
    elseif cmd=='hekili' then
        local id,why=A.GetHekiliRecommendation(); A.Print('spell='..tostring(id or 'нет')..(id and (' '..A.SpellName(id)) or '')..'; '..tostring(why))
    elseif cmd=='scan' then
        local n,err,count,macros,warnings=A.ScanButtons(); A.Print(n and ('Панели: спеллов '..count..', макросов '..macros..', нераспознанных '..warnings..', новых цветов '..n..'.') or err)
    elseif cmd=='colors' then
        if rest~='rebuild CONFIRM' then A.Print('ВНИМАНИЕ: цвета всех сохранённых спеллов изменятся. Остановите бот, затем /apix colors rebuild CONFIRM; после этого нужен новый экспорт.'); return end
        local ok,result=A.RebuildColors()
        A.Print(ok and ('Пересоздано цветов: '..result..'. Старые экспорты недействительны; выполните /apix export.') or ('Ошибка: '..tostring(result)))
    elseif cmd=='size' then
        local n=integer(rest); if not n or n<1 or n>100 then A.Print('Используйте /apix size 1..100'); return end
        if applyGeometry({size=n}) then A.Print('Размер первого блока: '..n..' UI units.') end
    elseif cmd=='pos' then
        local x,y=rest:match('^(%S+)%s+(%S+)$'); x=integer(x); y=integer(y)
        if not x or not y or x<0 or y<0 or x>10000 or y>10000 then A.Print('Используйте /apix pos X Y (неотрицательные целые).'); return end
        if applyGeometry({x=x,y=y}) then A.Print('Позиция: '..x..', '..y..' UI units.') end
    elseif cmd=='identity' then
        local sub,arg=rest:match('^(%S+)%s*(.-)$'); sub=string.lower(sub or '')
        if sub=='' or sub=='status' then printIdentity()
        elseif sub=='auto' then if applyGeometry({identityAuto=true}) then A.Print('Позиция identity: автоматически справа.') end
        elseif sub=='on' or sub=='off' then
            A.db.identityEnabled=(sub=='on'); A.RefreshIdentity(); A.Print('Identity: '..sub..'.')
        elseif sub=='size' then
            local n=integer(arg); if not n or n<1 or n>100 then A.Print('Используйте /apix identity size 1..100'); return end
            if applyGeometry({identitySize=n}) then A.Print('Размер identity: '..n..' UI units.') end
        elseif sub=='pos' then
            local x,y=arg:match('^(%S+)%s+(%S+)$'); x=integer(x); y=integer(y)
            if not x or not y or x<0 or y<0 or x>10000 or y>10000 then A.Print('Используйте /apix identity pos X Y'); return end
            if applyGeometry({identityAuto=false,identityX=x,identityY=y}) then A.Print('Позиция identity: '..x..', '..y..' UI units.') end
        elseif sub=='color' then
            local ok,why=A.SetIdentityColor(arg)
            if not ok then A.Print(why); return end
            A.RefreshIdentity(); A.Print('Цвет identity: '..arg..'; повторите экспорт для этого персонажа/спека.')
        else A.Print('Используйте /apix identity [status|auto|on|off|size N|pos X Y|color #RRGGBB]') end
    elseif cmd=='toggle' then
        A.db.enabled=not A.db.enabled; A.Print(A.db.enabled and 'Включено.' or 'Отключено; чёрный.')
    elseif cmd=='iconfallback' then
        if rest~='on' and rest~='off' then A.Print('Используйте /apix iconfallback on|off'); return end
        A.db.iconFallback=(rest=='on'); A.Print('Icon fallback: '..rest..' (проверьте неоднозначности).')
    elseif cmd=='display' then
        if not rest:match('^[%w_%-]+$') then A.Print('Используйте /apix display auto или /apix display 5'); return end
        A.db.display=rest; A.Print('Дисплей: '..rest..(rest=='auto' and ' (автовыбор Primary)' or ' (ручной выбор)'))
    elseif cmd=='alias' then
        if rest=='list' or rest=='' then
            local n=0
            for _,id in ipairs(A.ConfiguredAliasIDs()) do
                local target=A.GetConfiguredAlias(id); A.Print('alias '..id..' -> '..tostring(target)); n=n+1
            end
            if n==0 then A.Print('Активных aliases нет.') end
        else
            local from,to=rest:match('^(%d+)%s+(%S+)$'); from=tonumber(from)
            if A.ValidID(from) and to=='reset' then
                local old=A.db.spellAliases[from]; A.db.spellAliases[from]=nil
                local target,why=A.ResolveSpellAlias(from)
                if not target then A.db.spellAliases[from]=old; A.Print('Alias не изменён: '..tostring(why)); return end
                A.Print('Правило '..from..' восстановлено по умолчанию; повторите экспорт.')
                return
            end
            if to=='off' then to=false else to=tonumber(to) end
            if not from or (to~=false and not to) then A.Print('Используйте /apix alias spellID targetID|off|reset или /apix alias list'); return end
            local ok,why=A.SetSpellAlias(from,to)
            if not ok then A.Print('Alias не изменён: '..tostring(why)); return end
            A.Print('Alias '..from..' -> '..tostring(to)..'; обновите экспорт и профиль.')
        end
    elseif cmd=='map' then
        local action,id=rest:match('^(%S+)%s+(%d+)$'); id=tonumber(id)
        if not action or not A.ValidID(id) or not GetSpellInfo(id) then A.Print('Используйте /apix map action_name spellID (заклинание должно существовать).'); return end
        local target,why=A.ResolveSpellAlias(id); if not target then A.Print('Ошибка alias: '..tostring(why)); return end
        A.db.actionMap[action]=id; A.GetColor(target); A.RebuildIconMap(); A.Print(action..' -> '..id..' '..A.SpellName(id)..(target~=id and ('; цвет от '..target) or ''))
    elseif cmd=='color' then
        local raw,hex=rest:match('^(%d+)%s+(#%x%x%x%x%x%x)$'); raw=tonumber(raw)
        local id,reason=A.ResolveSpellAlias(raw)
        if not id then A.Print('Ошибка alias: '..tostring(reason)); return end
        local ok,why=A.SetColor(id,hex)
        if not ok then A.Print(why); return end
        A.RebuildIconMap(); A.Print('Изменён цвет '..id..(raw~=id and (' (alias '..raw..')') or '')..' на '..hex..'; повторите экспорт.')
    elseif cmd=='key' then
        local id,key=rest:match('^(%d+)%s+(%S+)$'); id=tonumber(id)
        if not A.ValidID(id) or not key or #key>40 then A.Print('Ручные ключи не используются при экспорте 0.6; настройте привязку в игре.'); return end
        local target,why=A.ResolveSpellAlias(id); if not target then A.Print('Ошибка alias: '..tostring(why)); return end
        A.GetColor(target); A.db.keys[target]=key; A.RebuildIconMap(); A.Print('Сохранён старый ручной key, но экспорт 0.6 берёт привязку с панели WoW. Настройте биндинг в игре.')
    elseif cmd=='export' then Export()
    else A.Print('Команды: status, scan, hekili, debug, binddebug, macrodebug, colors, test on|off, size N, pos X Y, identity, toggle, display ID, iconfallback on|off, alias ID target|off|reset, map action_name spellID, color spellID #RRGGBB, key spellID KEY, export') end
end
SLASH_APIX1='/apix'
SlashCmdList.APIX=function(s) A.Command(s or '') end
