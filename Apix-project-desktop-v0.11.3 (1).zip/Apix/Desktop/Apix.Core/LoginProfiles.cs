using System.Text.Json;

namespace Apix.Core;

public sealed record ScreenPoint(int X,int Y);
public sealed record ScreenPatch(int Width,int Height,byte[] Pixels)
{
    public static ScreenPatch Capture(PixelFrame frame,int left,int top,int width,int height)
    {
        if(left<0 || top<0 || width<4 || height<4 || width>500 || height>80 || left+width>frame.Width || top+height>frame.Height) throw new InvalidOperationException("Область образца выходит за границы или имеет неподходящий размер.");
        var bytes=new byte[width*height*3];
        for(int y=0;y<height;y++) for(int x=0;x<width;x++) { var c=frame.Pixel(left+x,top+y); int i=(y*width+x)*3; bytes[i]=c.R;bytes[i+1]=c.G;bytes[i+2]=c.B; }
        return new ScreenPatch(width,height,bytes);
    }
    public bool Valid() => Width>=4 && Height>=4 && Width<=1024 && Height<=160 && Pixels is not null && Pixels.Length==Width*Height*3;
    public int ColorfulCount() {
        if(!Valid()) return 0; int n=0;
        for(int i=0;i<Pixels.Length;i+=3) { int max=Math.Max(Pixels[i],Math.Max(Pixels[i+1],Pixels[i+2]));int min=Math.Min(Pixels[i],Math.Min(Pixels[i+1],Pixels[i+2])); if(max>=130 && max-min>=35) n++; }
        return n;
    }
}
public sealed record LoginCalibration(int Width,int Height,ScreenPoint User,ScreenPoint Password,ScreenPoint Submit,ScreenPoint AnchorTopLeft,ScreenPatch Anchor);
public sealed record RealmCalibration(int Width,int Height,ScreenPoint TitleTopLeft,ScreenPatch Title,ScreenPoint OriginalRowTopLeft,ScreenPatch Realm,ScreenPoint Confirm);
public sealed record LoginProfile(Guid Id,string Name,string RealmName,string Executable,string ProtectedCredentials,LoginCalibration? Login,RealmCalibration? Realm);

public static class ScreenTemplate
{
    private static bool Close(Rgb c,byte r,byte g,byte b,int tolerance) => Math.Abs(c.R-r)<=tolerance && Math.Abs(c.G-g)<=tolerance && Math.Abs(c.B-b)<=tolerance;
    public static bool At(PixelFrame frame,ScreenPatch p,int x,int y,int tolerance=20)
    {
        if(!p.Valid() || x<0 || y<0 || x+p.Width>frame.Width || y+p.Height>frame.Height) return false;
        int good=0,goodColor=0,colorCount=0,total=p.Width*p.Height;
        for(int j=0;j<p.Height;j++) for(int i=0;i<p.Width;i++) {
            int idx=(j*p.Width+i)*3; byte r=p.Pixels[idx],g=p.Pixels[idx+1],b=p.Pixels[idx+2];
            bool match=Close(frame.Pixel(x+i,y+j),r,g,b,tolerance);
            if(match) good++;
            int max=Math.Max(r,Math.Max(g,b)), min=Math.Min(r,Math.Min(g,b));
            if(max>=130 && max-min>=35) { colorCount++; if(match) goodColor++; }
        }
        return colorCount>=15 && good*100>=total*97 && goodColor*1000>=colorCount*985;
    }
    public static IReadOnlyList<ScreenPoint> FindInColumn(PixelFrame frame,ScreenPatch p,int nearX,int yMin,int yMax)
        => FindInRect(frame,p,nearX-2,nearX+2,yMin,yMax);
    public static IReadOnlyList<ScreenPoint> FindInRect(PixelFrame frame,ScreenPatch p,int xMin,int xMax,int yMin,int yMax)
    {
        if(!p.Valid() || p.ColorfulCount()<15) return [];
        var probes=new List<(int x,int y,byte r,byte g,byte b)>();
        for(int j=0;j<p.Height;j++) for(int i=0;i<p.Width;i++) {
            int k=(j*p.Width+i)*3; byte r=p.Pixels[k],g=p.Pixels[k+1],b=p.Pixels[k+2];
            int max=Math.Max(r,Math.Max(g,b)), min=Math.Min(r,Math.Min(g,b));
            if(max>=160 && max-min>=55) probes.Add((i,j,r,g,b));
        }
        if(probes.Count<8) return [];
        var sample=Enumerable.Range(0,Math.Min(16,probes.Count)).Select(i=>probes[i*(probes.Count-1)/Math.Max(1,Math.Min(16,probes.Count)-1)]).ToArray();
        var matches=new List<ScreenPoint>();
        for(int y=Math.Max(0,yMin);y<=Math.Min(yMax,frame.Height-p.Height);y++)
            for(int x=Math.Max(0,xMin);x<=Math.Min(xMax,frame.Width-p.Width);x++) {
                int good=0; foreach(var q in sample) if(Close(frame.Pixel(x+q.x,y+q.y),q.r,q.g,q.b,20)) good++;
                if(good<sample.Length*0.8 || !At(frame,p,x,y)) continue;
                // Adjacent one-pixel alignments represent one occurrence.
                if(matches.All(m=>Math.Abs(m.Y-y)>p.Height/2 || Math.Abs(m.X-x)>4)) matches.Add(new(x,y));
                if(matches.Count>1) return matches;
            }
        return matches;
    }
}

public sealed class LoginProfileStore(string directory)
{
    private const int Limit=1_000_000;
    public string DirectoryPath { get; }=directory;
    private string PathFor(Guid id) => Path.Combine(DirectoryPath,id.ToString("N")+".json");
    public void Save(LoginProfile p)
    {
        if(p.Id==Guid.Empty || string.IsNullOrWhiteSpace(p.Name) || p.Name.Length>80 || p.RealmName.Length>120 || p.Executable.Length>2000 || string.IsNullOrEmpty(p.ProtectedCredentials) || p.ProtectedCredentials.Length>20000) throw new InvalidOperationException("Неверные данные профиля входа.");
        var json=JsonSerializer.Serialize(p);
        if(System.Text.Encoding.UTF8.GetByteCount(json)>Limit) throw new InvalidOperationException("Профиль входа слишком большой.");
        Directory.CreateDirectory(DirectoryPath); string path=PathFor(p.Id),tmp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
        try { File.WriteAllText(tmp,json); File.Move(tmp,path,true); } finally { if(File.Exists(tmp)) File.Delete(tmp); }
    }
    public void Delete(Guid id) { if(id==Guid.Empty) throw new ArgumentException("Invalid id"); File.Delete(PathFor(id)); }
    public (IReadOnlyList<LoginProfile> Profiles,IReadOnlyList<string> Errors) Load()
    {
        var profiles=new List<LoginProfile>();var errors=new List<string>();
        if(!Directory.Exists(DirectoryPath)) return (profiles,errors);
        foreach(var path in Directory.EnumerateFiles(DirectoryPath,"*.json").OrderBy(x=>x,StringComparer.OrdinalIgnoreCase)) {
            if(profiles.Count+errors.Count>=100) { errors.Add("Лимит 100 профилей входа."); break; }
            try {
                if(new FileInfo(path).Length>Limit) throw new InvalidDataException("Файл слишком большой.");
                var p=JsonSerializer.Deserialize<LoginProfile>(File.ReadAllText(path)) ?? throw new InvalidDataException("Пустой файл.");
                if(p.Id==Guid.Empty || !Path.GetFileNameWithoutExtension(path).Equals(p.Id.ToString("N"),StringComparison.OrdinalIgnoreCase) || string.IsNullOrWhiteSpace(p.Name) || string.IsNullOrEmpty(p.ProtectedCredentials) || p.Name.Length>80 || p.RealmName is null || p.Executable is null) throw new InvalidDataException("Неверный профиль входа.");
                profiles.Add(p);
            } catch(Exception e) when(e is IOException or UnauthorizedAccessException or JsonException or InvalidDataException) { errors.Add(Path.GetFileName(path)+": "+e.Message); }
        }
        return (profiles.AsReadOnly(),errors.AsReadOnly());
    }
}

// Reuse only when all applicable saved examples agree byte-for-byte. Never share credentials.
public static class LoginCalibrationReuse
{
    private static T? Unique<T>(IEnumerable<T> values) where T:class
    {
        var groups=values.GroupBy(v=>JsonSerializer.Serialize(v),StringComparer.Ordinal).Take(2).ToArray();
        return groups.Length==1 ? groups[0].First() : null;
    }
    public static LoginProfile Apply(LoginProfile profile,IEnumerable<LoginProfile> profiles)
    {
        if(string.IsNullOrWhiteSpace(profile.Executable)) return profile;
        var same=profiles.Where(p=>p.Id!=profile.Id && string.Equals(p.Executable,profile.Executable,StringComparison.OrdinalIgnoreCase)).ToArray();
        var login=profile.Login ?? Unique(same.Where(p=>p.Login is not null).Select(p=>p.Login!));
        var realm=profile.Realm ?? Unique(same.Where(p=>p.Realm is not null && string.Equals(p.RealmName,profile.RealmName,StringComparison.OrdinalIgnoreCase)).Select(p=>p.Realm!));
        return profile with {Login=login,Realm=realm};
    }
}
