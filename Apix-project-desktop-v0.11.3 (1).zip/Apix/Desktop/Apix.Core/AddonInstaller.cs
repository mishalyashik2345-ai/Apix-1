using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Apix.Core.Tests")]
namespace Apix.Core;

/// <summary>Installs the bundled addon only; never touches WTF or other addons.</summary>
public static class AddonInstaller
{
    public static readonly IReadOnlyList<string> Files = Array.AsReadOnly(new[] {
        "Utils.lua", "Config.lua", "ColorManager.lua", "Identity.lua", "HekiliReader.lua",
        "Bindings.lua", "Diagnostics.lua", "PixelRenderer.lua", "Commands.lua", "Core.lua", "Apix.toc"
    });

    // Accept WoW root or a commonly selected nested folder without guessing across drives.
    public static string NormalizeGameRoot(string selection)
    {
        if(string.IsNullOrWhiteSpace(selection)) throw new ArgumentException("Папка игры не указана.");
        var dir=new DirectoryInfo(Path.GetFullPath(selection));
        static bool Is(DirectoryInfo? d,string name) => d is not null && d.Name.Equals(name,StringComparison.OrdinalIgnoreCase);
        if(Is(dir,"Apix") && Is(dir.Parent,"AddOns") && Is(dir.Parent?.Parent,"Interface")) return dir.Parent!.Parent!.Parent!.FullName;
        if(Is(dir,"AddOns") && Is(dir.Parent,"Interface")) return dir.Parent!.Parent!.FullName;
        if(Is(dir,"Interface") && dir.Parent is not null) return dir.Parent.FullName;
        return dir.FullName;
    }

    public static bool IsGameRoot(string root)
    {
        if(string.IsNullOrWhiteSpace(root) || !Directory.Exists(root)) return false;
        string[] names=["Wow.exe","Wow-64.exe","WowB.exe","Wow-64B.exe"];
        if(names.Any(n=>File.Exists(Path.Combine(root,n)))) return true;
        // Private servers sometimes rename the executable. Require strong
        // structural evidence, not just an arbitrary user-selected folder.
        bool data=Directory.Exists(Path.Combine(root,"Data"));
        bool ui=Directory.Exists(Path.Combine(root,"Interface"));
        bool wtf=Directory.Exists(Path.Combine(root,"WTF"));
        bool addons=Directory.Exists(Path.Combine(root,"Interface","AddOns"));
        return (data && (ui || wtf)) || (addons && wtf);
    }

    public static string Install(string gameRoot,IReadOnlyDictionary<string,byte[]> payload) => Install(gameRoot,payload,null);

    // The test hook injects a deterministic failure to exercise rollback.
    internal static string Install(string gameRoot,IReadOnlyDictionary<string,byte[]> payload,Action<string>? beforeReplace)
    {
        string root=NormalizeGameRoot(gameRoot);
        if(!IsGameRoot(root)) throw new InvalidOperationException("Папка не похожа на клиент WoW: не найден исполняемый файл WoW или структура Data/Interface/WTF.");
        if(payload.Count!=Files.Count || Files.Any(n=>!payload.TryGetValue(n,out var b) || b is null || b.Length==0))
            throw new InvalidOperationException("Встроенный комплект аддона неполный. Установка отменена.");
        // TOC must list exactly the bundled Lua files; don't silently install a mixed version.
        var toc=System.Text.Encoding.UTF8.GetString(payload["Apix.toc"]);
        var luaLines=toc.Split('\n').Select(x=>x.Trim()).Where(x=>x.Length>0 && !x.StartsWith("#")).ToArray();
        if(luaLines.Length!=Files.Count-1 || !luaLines.SequenceEqual(Files.Take(Files.Count-1),StringComparer.Ordinal))
            throw new InvalidOperationException("Состав встроенного Apix.toc не соответствует комплекту аддона.");
        string ui=Path.Combine(root,"Interface"), addons=Path.Combine(ui,"AddOns"), target=Path.Combine(addons,"Apix");
        foreach(string p in new[]{ui,addons,target}) CheckNotLink(p);
        Directory.CreateDirectory(target);
        foreach(string p in new[]{ui,addons,target}) CheckNotLink(p);
        foreach(var name in Files) {
            string dest=Path.Combine(target,name); CheckNotLink(dest);
            if(Directory.Exists(dest)) throw new IOException("Вместо файла аддона обнаружена папка: "+dest);
        }
        string work=Path.Combine(addons,".apix-install-"+Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(work);
        bool preserveBackup=false;
        var originals=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var committed=new List<string>();
        try {
            foreach(var name in Files) {
                File.WriteAllBytes(Path.Combine(work,"new-"+name),payload[name]);
                var old=Path.Combine(target,name);
                if(File.Exists(old)) { File.Copy(old,Path.Combine(work,"old-"+name)); originals.Add(name); }
            }
            foreach(var name in Files) {
                CheckNotLink(target); CheckNotLink(Path.Combine(target,name));
                beforeReplace?.Invoke(name);
                File.Move(Path.Combine(work,"new-"+name),Path.Combine(target,name),true);
                committed.Add(name);
            }
        }
        catch(Exception ex) {
            var failed=new List<string>();
            foreach(var name in committed.AsEnumerable().Reverse()) {
                try {
                    string dst=Path.Combine(target,name);
                    CheckNotLink(target); CheckNotLink(dst);
                    if(originals.Contains(name)) File.Copy(Path.Combine(work,"old-"+name),dst,true);
                    else File.Delete(dst);
                } catch(Exception rollback) { failed.Add(name+": "+rollback.Message); }
            }
            if(failed.Count>0) {
                preserveBackup=true;
                throw new IOException("Установка не завершена, не все файлы восстановлены. Резервные копии: "+work+"; "+string.Join("; ",failed),ex);
            }
            throw new IOException("Установка не завершена; прежние изменённые файлы восстановлены. "+ex.Message,ex);
        }
        finally { if(!preserveBackup) try { Directory.Delete(work,true); } catch { /* A leftover staging folder is harmless. */ } }
        return target;
    }

    private static void CheckNotLink(string path)
    {
        if((File.Exists(path) || Directory.Exists(path)) && (File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0)
            throw new IOException("Ссылка или точка повторной обработки в папке аддонов: "+path+". Установка отменена.");
    }
}
