namespace Apix.Core;

// RegisterHotKey flags; NOREPEAT is applied by the Win32 caller.
public sealed record HotkeySpec(string Text,uint Modifiers,ushort VirtualKey)
{
    public static bool TryParse(string? text,out HotkeySpec? result)
    {
        result=null;
        if(string.IsNullOrWhiteSpace(text) || text.Length>60) return false;
        string normalized=string.Concat(text.Where(c=>!char.IsWhiteSpace(c))).Replace('+','-').ToUpperInvariant();
        // ~ is a name for the physical OEM_3 / grave key here, not an implicit
        // Shift modifier. On typical Russian/US keyboards it is the Ё / ` key.
        var parts=normalized.Split('-');
        if(parts[^1] is "~" or "`" or "Ё" or "TILDE") parts[^1]="GRAVE";
        normalized=string.Join("-",parts);
        if(!KeyChord.TryParse(normalized,out var chord) || chord is null || chord.Kind!=KeyKind.Keyboard) return false;
        ushort vk=OemVirtualKey(chord.Key) ?? InputPlanner.Create(normalized)?.MainVirtualKey ?? 0;
        if(vk==0 || vk==0x7B) return false; // F12: emergency key / debugger-reserved
        uint modifiers=(chord.Alt?1u:0u)|(chord.Ctrl?2u:0u)|(chord.Shift?4u:0u);
        string prefix=(chord.Ctrl?"CTRL-":"")+(chord.Alt?"ALT-":"")+(chord.Shift?"SHIFT-":"");
        result=new(prefix+(chord.Key=="GRAVE"?"~":chord.Key),modifiers,vk);
        return true;
    }
    // Even different modifiers can combine with a user's physical modifier;
    // don't allow injected trigger events to activate a registered hotkey.
    private static ushort? OemVirtualKey(string key) => key switch {
        "GRAVE"=>0xC0,"MINUS"=>0xBD,"EQUALS"=>0xBB,"COMMA"=>0xBC,"PERIOD"=>0xBE,
        "SLASH"=>0xBF,"SEMICOLON"=>0xBA,"APOSTROPHE"=>0xDE,
        "LEFTBRACKET"=>0xDB,"RIGHTBRACKET"=>0xDD,"BACKSLASH"=>0xDC,_=>null
    };
    public bool ConflictsWithTrigger(string key)
    {
        if(KeyChord.TryParse(key,out var chord) && chord is {Kind:KeyKind.Keyboard}) {
            ushort? oem=OemVirtualKey(chord.Key);
            if(oem.HasValue) return VirtualKey==oem.Value;
        }
        return InputPlanner.Create(key)?.MainVirtualKey==VirtualKey;
    }
}
