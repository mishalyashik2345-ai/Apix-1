namespace Apix.Core;

public enum ProfileStartChoice { UseCurrent, SearchSaved, NoProfiles, LibraryError }

// A saved profile is not proof that it belongs to the active character.
// SearchSaved only authorizes a paused search, never a keypress.
public static class ProfileStartup
{
    public static ProfileStartChoice Decide(bool currentProfileLoaded,int savedCount,bool libraryHasErrors)
    {
        if(savedCount<0) throw new ArgumentOutOfRangeException(nameof(savedCount));
        if(libraryHasErrors) return ProfileStartChoice.LibraryError;
        if(currentProfileLoaded) return ProfileStartChoice.UseCurrent;
        return savedCount>0 ? ProfileStartChoice.SearchSaved : ProfileStartChoice.NoProfiles;
    }
}
