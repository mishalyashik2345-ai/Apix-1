namespace Apix.Core;

// Geometry recovered only after a distinctive trained anchor has matched.
public enum ScaleFilter { Nearest, Bilinear }
public sealed record ResolvedAnchor(ScreenPoint Position,double Scale,ScreenPatch Patch,int Width,int Height,ScaleFilter Filter=ScaleFilter.Nearest,double PhaseX=0,double PhaseY=0)
{
    public ScreenPoint Map(ScreenPoint original,ScreenPoint originalAnchor) => new(
        Position.X+(int)Math.Round((original.X-originalAnchor.X)*Scale),
        Position.Y+(int)Math.Round((original.Y-originalAnchor.Y)*Scale));
    public bool Matches(PixelFrame frame) => frame.Width==Width && frame.Height==Height && ScreenTemplate.At(frame,Patch,Position.X,Position.Y);
}
public static class ScreenScaling
{
    public static ScreenPatch Scale(ScreenPatch patch,double factor,ScaleFilter filter=ScaleFilter.Nearest,double phaseX=0,double phaseY=0)
    {
        if(!patch.Valid() || factor<0.4 || factor>2.5) throw new ArgumentException("Unsupported screen scale.");
        int w=Math.Max(4,(int)Math.Round(patch.Width*factor)),h=Math.Max(4,(int)Math.Round(patch.Height*factor));
        if(w>1024 || h>160) throw new ArgumentException("Scaled screen anchor too large.");
        var data=new byte[w*h*3];
        for(int y=0;y<h;y++) for(int x=0;x<w;x++) {
            int dst=(y*w+x)*3;
            if(filter==ScaleFilter.Nearest) {
                int sx=Math.Clamp((int)Math.Floor((x+0.5)/factor+phaseX),0,patch.Width-1);
                int sy=Math.Clamp((int)Math.Floor((y+0.5)/factor+phaseY),0,patch.Height-1);
                int src=(sy*patch.Width+sx)*3;
                data[dst]=patch.Pixels[src];data[dst+1]=patch.Pixels[src+1];data[dst+2]=patch.Pixels[src+2];
            } else {
                double sx=Math.Clamp((x+0.5)/factor-0.5+phaseX,0,patch.Width-1);
                double sy=Math.Clamp((y+0.5)/factor-0.5+phaseY,0,patch.Height-1);
                int x0=(int)sx,y0=(int)sy,x1=Math.Min(x0+1,patch.Width-1),y1=Math.Min(y0+1,patch.Height-1);
                double fx=sx-x0,fy=sy-y0;
                for(int c=0;c<3;c++) {
                    double top=patch.Pixels[(y0*patch.Width+x0)*3+c]*(1-fx)+patch.Pixels[(y0*patch.Width+x1)*3+c]*fx;
                    double bottom=patch.Pixels[(y1*patch.Width+x0)*3+c]*(1-fx)+patch.Pixels[(y1*patch.Width+x1)*3+c]*fx;
                    data[dst+c]=(byte)Math.Clamp((int)Math.Round(top*(1-fy)+bottom*fy),0,255);
                }
            }
        }
        return new(w,h,data);
    }
    public static ResolvedAnchor? Resolve(PixelFrame frame,int trainedWidth,int trainedHeight,ScreenPoint origin,ScreenPatch patch)
    {
        if(trainedWidth<=0 || trainedHeight<=0 || !patch.Valid() || patch.ColorfulCount()<15) return null;
        if(frame.Width==trainedWidth && frame.Height==trainedHeight && ScreenTemplate.At(frame,patch,origin.X,origin.Y))
            return new(origin,1.0,patch,frame.Width,frame.Height);
        double hRatio=(double)frame.Height/trainedHeight,wRatio=(double)frame.Width/trainedWidth;
        var scales=new List<double>();
        foreach(double b in new[]{hRatio,wRatio,1.0}) foreach(double extra in new[]{1.0,0.95,1.05,0.9,1.1}) {
            double f=Math.Round(b*extra,4);
            if(f>=0.4 && f<=2.5 && scales.All(s=>Math.Abs(s-f)>0.004)) scales.Add(f);
        }
        ResolvedAnchor? found=null;
        foreach(double scale in scales) foreach(ScaleFilter filter in new[]{ScaleFilter.Nearest,ScaleFilter.Bilinear}) foreach(var phase in new[]{0.0,-0.1,0.1,-0.5,0.5}) foreach(var phaseY in new[]{0.0,-0.1,0.1,-0.5,0.5}) {
            ScreenPatch scaled;
            try { scaled=Scale(patch,scale,filter,phase,phaseY); } catch(ArgumentException) { continue; }
            int expectedX=(int)Math.Round(frame.Width/2.0+(origin.X-trainedWidth/2.0)*scale);
            int expectedY=(int)Math.Round(frame.Height/2.0+(origin.Y-trainedHeight/2.0)*scale);
            int rx=Math.Clamp(frame.Width/25,20,80), ry=Math.Clamp(frame.Height/25,20,80);
            var matches=ScreenTemplate.FindInRect(frame,scaled,expectedX-rx,expectedX+rx,expectedY-ry,expectedY+ry);
            foreach(var hit in matches) {
                if(found is null) found=new(hit,scale,scaled,frame.Width,frame.Height,filter,phase,phaseY);
                else if(Math.Abs(found.Position.X-hit.X)>2 || Math.Abs(found.Position.Y-hit.Y)>2 || Math.Abs(found.Scale-scale)>0.01) return null;
            }
        }
        return found;
    }
}
