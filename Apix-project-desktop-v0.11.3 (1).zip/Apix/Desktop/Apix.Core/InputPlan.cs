namespace Apix.Core;

// Pure plan only: no Windows calls. A caller must still validate focus, pointer,
// pointer safety and handle a partial SendInput result.
public enum InputDevice { Keyboard, Mouse }
public readonly record struct InputStep(InputDevice Device, ushort VirtualKey, uint MouseFlag, uint MouseData, bool Up, bool Extended=false);
public sealed record InputPlan(IReadOnlyList<InputStep> Steps, ushort MainVirtualKey, bool IsMouse);
public static class InputPlanner
{
    public static InputPlan? Create(string? key, IReadOnlySet<ushort>? heldModifiers=null)
    {
        if(!KeyChord.TryParse(key,out var c) || c is null) return null;
        // Do not synthesize an up event for a modifier that the player is already
        // holding. User and SendInput still share one Windows keyboard state.
        var mods=new List<ushort>();
        if(c.Ctrl && heldModifiers?.Contains(0x11)!=true) mods.Add(0x11);
        if(c.Alt && heldModifiers?.Contains(0x12)!=true) mods.Add(0x12);
        if(c.Shift && heldModifiers?.Contains(0x10)!=true) mods.Add(0x10);
        var result=new List<InputStep>();
        foreach(ushort m in mods) result.Add(new(InputDevice.Keyboard,m,0,0,false));
        ushort vk=0;
        if(c.Kind==KeyKind.Mouse)
        {
            var button=c.Key switch {
                "BUTTON1" => (Down:0x0002u,Up:0x0004u,Data:0u,Vk:(ushort)1),
                "BUTTON2" => (Down:0x0008u,Up:0x0010u,Data:0u,Vk:(ushort)2),
                "BUTTON3" => (Down:0x0020u,Up:0x0040u,Data:0u,Vk:(ushort)4),
                "BUTTON4" => (Down:0x0080u,Up:0x0100u,Data:1u,Vk:(ushort)5),
                "BUTTON5" => (Down:0x0080u,Up:0x0100u,Data:2u,Vk:(ushort)6),
                _ => (Down:0u,Up:0u,Data:0u,Vk:(ushort)0)
            };
            if(button.Vk==0) return null;
            vk=button.Vk;
            result.Add(new(InputDevice.Mouse,vk,button.Down,button.Data,false));
            result.Add(new(InputDevice.Mouse,vk,button.Up,button.Data,true));
        }
        else
        {
            (vk,bool extended)=VirtualKey(c.Key);
            if(vk==0) return null;
            result.Add(new(InputDevice.Keyboard,vk,0,0,false,extended));
            result.Add(new(InputDevice.Keyboard,vk,0,0,true,extended));
        }
        for(int i=mods.Count-1;i>=0;i--) result.Add(new(InputDevice.Keyboard,mods[i],0,0,true));
        return new(result.AsReadOnly(),vk,c.Kind==KeyKind.Mouse);
    }
    private static (ushort Vk,bool Extended) VirtualKey(string k)
    {
        if(k.Length==1 && ((k[0]>='A'&&k[0]<='Z')||(k[0]>='0'&&k[0]<='9'))) return (k[0],false);
        if(k[0]=='F' && int.TryParse(k.AsSpan(1),out int f) && f>=1 && f<=24) return ((ushort)(0x70+f-1),false);
        if(k.Length==7 && k.StartsWith("NUMPAD",StringComparison.Ordinal) && char.IsAsciiDigit(k[6])) return ((ushort)(0x60+k[6]-'0'),false);
        return k switch {
            "NUMPADPLUS"=>(0x6B,false),"NUMPADMINUS"=>(0x6D,false),"NUMPADMULTIPLY"=>(0x6A,false),"NUMPADDIVIDE"=>(0x6F,true),"NUMPADDECIMAL"=>(0x6E,false),"NUMPADENTER"=>(0x0D,true),
            "SPACE"=>(0x20,false),"TAB"=>(0x09,false),"ENTER"=>(0x0D,false),"BACKSPACE"=>(0x08,false),"DELETE"=>(0x2E,true),"INSERT"=>(0x2D,true),"HOME"=>(0x24,true),"END"=>(0x23,true),"PAGEUP"=>(0x21,true),"PAGEDOWN"=>(0x22,true),
            "UP"=>(0x26,true),"DOWN"=>(0x28,true),"LEFT"=>(0x25,true),"RIGHT"=>(0x27,true),_=> (0,false)
        };
    }
    // Compute only releases for events actually sent when SendInput is partial.
    public static IReadOnlyList<InputStep> ReleasesForPrefix(InputPlan plan, int count)
    {
        if(count<0 || count>plan.Steps.Count) throw new ArgumentOutOfRangeException(nameof(count));
        var held=new List<InputStep>();
        foreach(var step in plan.Steps.Take(count))
        {
            if(!step.Up) held.Add(step);
            else { int i=held.FindLastIndex(s=>s.Device==step.Device && s.VirtualKey==step.VirtualKey); if(i>=0) held.RemoveAt(i); }
        }
        held.Reverse();
        return held.Select(s=>s.Device==InputDevice.Keyboard?s with { Up=true }:s with { Up=true, MouseFlag=s.MouseFlag switch {0x0002=>0x0004u,0x0008=>0x0010u,0x0020=>0x0040u,0x0080=>0x0100u,_=>0u} }).ToList().AsReadOnly();
    }
}
