namespace Apix.Core;
public enum FocusAction { Proceed, Wait, Stop }
public static class FocusPolicy
{
    // A closed/replaced window is terminal. An existing but minimized or
    // unfocused window merely pauses; it can safely be checked again later.
    public static FocusAction Decide(bool exists,bool usable,bool foreground) =>
        !exists ? FocusAction.Stop : usable && foreground ? FocusAction.Proceed : FocusAction.Wait;
}
