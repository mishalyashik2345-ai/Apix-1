namespace Apix.Core;

// An immutable, top-down BGRA32 image of the selected client area.
public sealed class PixelFrame
{
    private readonly byte[] _data;
    public int Width { get; }
    public int Height { get; }
    public PixelFrame(int width,int height,byte[] bgra)
    {
        if(width<1 || height<1 || (long)width*height>20_000_000 || bgra is null || bgra.Length!=(long)width*height*4) throw new ArgumentException("Invalid frame dimensions or BGRA buffer.");
        Width=width; Height=height; _data=bgra;
    }
    public Rgb Pixel(int x,int y)
    {
        int i=(y*Width+x)*4; return new(_data[i+2],_data[i+1],_data[i]);
    }
    public IReadOnlyList<Rgb?>? Sample(int x,int y,int area)
    {
        if(area is not (1 or 3 or 5)) return null;
        int r=area/2;
        if(x-r<0 || y-r<0 || x+r>=Width || y+r>=Height) return null;
        var result=new List<Rgb?>(area*area);
        for(int dy=-r;dy<=r;dy++) for(int dx=-r;dx<=r;dx++) result.Add(Pixel(x+dx,y+dy));
        return result;
    }
}
public enum LocateState { Found, NotFound, Ambiguous, Invalid }
public sealed record PixelLocation(int SpellX,int SpellY,int IdentityX,int IdentityY,int Width,int Height);
public sealed record LocateResult(LocateState State,PixelLocation? Location,string Message);
public static class PixelLocator
{
    public static LocateResult Find(PixelFrame frame,Profile profile,int tolerance,int area)
    {
        if(profile.Identity is null || tolerance is <0 or >50 || area is not (1 or 3 or 5) || profile.PixelLayout.Unit!="ui") return new(LocateState.Invalid,null,"Нет identity или неверные параметры.");
        if(Palette.FindConflicts(profile.Triggers.Select(t=>(t.SpellId.ToString(),t.Color)),tolerance).Count>0) return new(LocateState.Invalid,null,"Цвета триггеров пересекаются при выбранном допуске.");
        var idColor=profile.Identity.Color;
        if(idColor.Distance(Rgb.Black)<=2*tolerance) return new(LocateState.Invalid,null,"Identity слишком близка к чёрному.");
        var uiId=profile.PixelLayout.Identity; var uiSpell=profile.PixelLayout.Spell;
        if(uiId.Size<=0 || uiSpell.Size<=0) return new(LocateState.Invalid,null,"Неверный размер блоков в экспорте.");
        bool Similar(int x,int y) => frame.Pixel(x,y).Distance(idColor)<=tolerance;
        var candidates=new List<PixelLocation>();
        int minSide=Math.Max(3,area);
        for(int y=0;y<frame.Height;y++)
        {
            int x=0;
            while(x<frame.Width)
            {
                if(!Similar(x,y)) {x++; continue;}
                int left=x; while(x<frame.Width && Similar(x,y)) x++;
                int width=x-left;
                if(width<minSide || width>1024) continue;
                int centerX=left+width/2;
                if(y>0 && Similar(centerX,y-1)) continue;
                int bottom=y;
                while(bottom<frame.Height && bottom-y<=1024 && Similar(centerX,bottom)) bottom++;
                int height=bottom-y;
                if(height<minSide || height>1024 || Math.Abs(width-height)>Math.Max(2,Math.Max(width,height)/5)) continue;
                bool solid=true;
                for(int iy=1;iy<=3 && solid;iy++) for(int ix=1;ix<=3;ix++)
                { int px=left+(width-1)*ix/4, py=y+(height-1)*iy/4; if(!Similar(px,py)) {solid=false;break;} }
                if(!solid) continue;
                int centerY=y+height/2;
                double dx=(uiSpell.X+uiSpell.Size/2.0)-(uiId.X+uiId.Size/2.0);
                double dy=(uiSpell.Y+uiSpell.Size/2.0)-(uiId.Y+uiId.Size/2.0);
                double tx=centerX+dx*width/uiId.Size, ty=centerY+dy*height/uiId.Size;
                if(tx<0 || ty<0 || tx>=frame.Width || ty>=frame.Height) continue;
                int sx=(int)Math.Round(tx),sy=(int)Math.Round(ty);
                var ip=frame.Sample(centerX,centerY,area); var sp=frame.Sample(sx,sy,area);
                if(ip is null || ip.Any(p=>p is null || p.Value.Distance(idColor)>tolerance) || sp is null) continue;
                var match=ColorMatcher.MatchArea(profile,sp,tolerance);
                if(match.State is not (MatchState.Matched or MatchState.Disabled or MatchState.Black)) continue;
                if(Math.Abs(centerX-sx)<area && Math.Abs(centerY-sy)<area) continue;
                candidates.Add(new(sx,sy,centerX,centerY,width,height));
                if(candidates.Count>1) return new(LocateState.Ambiguous,null,"Найдено несколько возможных пар блоков. Автоматический выбор запрещён.");
            }
        }
        return candidates.Count==1?new(LocateState.Found,candidates[0],"Найдена одна пара блоков."):new(LocateState.NotFound,null,"Не найдена однозначная пара блоков. Проверьте видимость, UI scale и захват кадра; доступна ручная калибровка.");
    }
}
