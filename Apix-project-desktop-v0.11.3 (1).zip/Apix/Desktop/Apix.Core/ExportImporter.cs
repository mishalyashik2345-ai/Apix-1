using System.Text;
using System.Text.Json;

namespace Apix.Core;

public sealed class ImportException(string message) : Exception(message);
public static class ExportImporter
{
    private const int MaxBytes=2_000_000;
    public static ImportResult Import(string text, int tolerance=10)
    {
        if (text is null || Encoding.UTF8.GetByteCount(text)>MaxBytes) throw new ImportException("Пустой или слишком большой экспорт (максимум 2 МБ).");
        text=text.Trim();
        if (text.StartsWith("APIX_EXPORT:",StringComparison.Ordinal)) text=text[12..];
        try
        {
            using var doc=JsonDocument.Parse(text,new JsonDocumentOptions{MaxDepth=32});
            RejectDuplicates(doc.RootElement);
            var root=RequireObject(doc.RootElement,"корень");
            int schema=Int(root,"schemaVersion",1,int.MaxValue);
            if(schema!=2) throw new ImportException($"Неподдерживаемая версия схемы: {schema}.");
            Identity? identity=null;
            if(root.TryGetProperty("identity",out var ident) && ident.ValueKind!=JsonValueKind.Null)
            {
                RequireObject(ident,"identity");
                identity=new(Text(ident,"name",128),Text(ident,"realm",200),Text(ident,"class",50),OptionalText(ident,"className",128)??"",Int(ident,"specID",1,int.MaxValue),OptionalText(ident,"specName",128)??"",Color(ident,"color"));
                if(identity.Color==Rgb.Black) throw new ImportException("Цвет identity не может быть чёрным.");
            }
            var layout=RequireObject(Property(root,"pixelLayout"),"pixelLayout");
            var unit=Text(layout,"unit",20);
            if(unit!="ui") throw new ImportException("Неизвестные единицы координат.");
            UiRectangle Rect(string name) { var r=RequireObject(Property(layout,name),name); return new(Int(r,"x",0,10000),Int(r,"y",0,10000),Int(r,"size",1,1000)); }
            var pixelLayout=new PixelLayout(unit,Rect("spell"),Rect("identity"));
            int declared=root.TryGetProperty("colorTolerance",out var tc) ? IntValue(tc,"colorTolerance",0,50) : 10;
            var list=RequireArray(Property(root,"triggers"),"triggers");
            if(list.GetArrayLength()>5000) throw new ImportException("Слишком много триггеров.");
            var triggers=new List<Trigger>(); var ids=new HashSet<int>(); var warnings=new List<string>();
            foreach(var item in list.EnumerateArray())
            {
                RequireObject(item,"trigger");
                int id=Int(item,"spellID",1,int.MaxValue);
                if(!ids.Add(id)) throw new ImportException($"Повторный spellID {id}.");
                var color=Color(item,"color");
                if(color==Rgb.Black) throw new ImportException($"Чёрный цвет запрещён: {id}.");
                var key=Text(item,"key",60);
                var keys=StringArray(item,"keys",60,64); if(keys.Count==0) keys.Add(key);
                if(!keys.Contains(key,StringComparer.Ordinal)) throw new ImportException($"Основная клавиша {key} отсутствует в keys ({id}).");
                if(!KeyChord.TryParse(key,out _)) warnings.Add($"{id}: клавиша {key} не поддерживается; отключите строку или выберите реально назначенную клавишу перед запуском.");
                var kind=OptionalText(item,"kind",40)??"spell";
                if(kind!="spell" && kind!="macro") throw new ImportException($"Неизвестный kind у {id}.");
                var button=OptionalText(item,"button",200)??"";
                int slot=OptionalInt(item,"slot",0,10000)??0;
                int raw=OptionalInt(item,"rawSpellID",1,int.MaxValue)??id;
                var bindings=new List<SourceBinding>();
                if(item.TryGetProperty("bindings",out var bs))
                {
                    RequireArray(bs,"bindings"); if(bs.GetArrayLength()>64) throw new ImportException("Слишком много bindings.");
                    foreach(var b in bs.EnumerateArray()) bindings.Add(new(Text(b,"button",200),Int(b,"slot",1,10000),StringArray(b,"keys",60,64).AsReadOnly()));
                }
                triggers.Add(new(id,Text(item,"spellName",256),color,key,keys.AsReadOnly(),kind,button,slot,raw,OptionalText(item,"macroName",256),bindings.AsReadOnly()));
            }
            var macros=new List<Macro>();
            if(root.TryGetProperty("macros",out var ms))
            {
                RequireArray(ms,"macros"); if(ms.GetArrayLength()>5000) throw new ImportException("Слишком много макросов.");
                foreach(var m in ms.EnumerateArray())
                {
                    int? sid=OptionalInt(m,"spellID",1,int.MaxValue);
                    bool selected=OptionalBool(m,"selectedForTrigger")??false;
                    macros.Add(new(Int(m,"macroID",1,int.MaxValue),Text(m,"name",256),Text(m,"key",60),sid,selected,OptionalText(m,"reason",1024)));
                    if(sid is null) warnings.Add($"Макрос {Text(m,"name",256)} ({Text(m,"key",60)}) не связан со spellID.");
                }
            }
            if(identity is null) warnings.Add("Identity отсутствует: автоматический выбор профиля невозможен.");
            if(triggers.Count==0) warnings.Add("В экспорте нет триггеров.");
            var profile=new Profile(schema,identity,pixelLayout,declared,triggers.AsReadOnly(),macros.AsReadOnly());
            var problems=Palette.FindConflicts(profile.Triggers.Select(t=>(t.SpellId.ToString(),t.Color)),tolerance);
            if(problems.Count>0) throw new ImportException("Небезопасная палитра: "+string.Join("; ",problems.Take(4)));
            return new(profile,warnings.AsReadOnly());
        }
        catch(JsonException e) { throw new ImportException("Неверный JSON: "+e.Message); }
        catch(InvalidOperationException e) { throw new ImportException("Неверная структура экспорта: "+e.Message); }
    }
    private static void RejectDuplicates(JsonElement e)
    {
        if(e.ValueKind==JsonValueKind.Object)
        {
            var names=new HashSet<string>(StringComparer.Ordinal);
            foreach(var p in e.EnumerateObject()) { if(!names.Add(p.Name)) throw new ImportException("Повторное поле JSON: "+p.Name); RejectDuplicates(p.Value); }
        }
        else if(e.ValueKind==JsonValueKind.Array) foreach(var x in e.EnumerateArray()) RejectDuplicates(x);
    }
    private static JsonElement Property(JsonElement e,string n) => e.TryGetProperty(n,out var v)?v:throw new ImportException("Нет поля "+n+".");
    private static JsonElement RequireObject(JsonElement e,string n) => e.ValueKind==JsonValueKind.Object?e:throw new ImportException(n+": ожидается объект.");
    private static JsonElement RequireArray(JsonElement e,string n) => e.ValueKind==JsonValueKind.Array?e:throw new ImportException(n+": ожидается массив.");
    private static string Text(JsonElement e,string n,int max) => OptionalText(e,n,max) is {Length:>0} s?s:throw new ImportException(n+": ожидается непустой текст.");
    private static string? OptionalText(JsonElement e,string n,int max)
    {
        RequireObject(e,n); if(!e.TryGetProperty(n,out var p) || p.ValueKind==JsonValueKind.Null) return null;
        if(p.ValueKind!=JsonValueKind.String) throw new ImportException(n+": ожидается текст.");
        string? s=p.GetString(); if(s is not null && s.Length>max) throw new ImportException(n+": слишком длинное значение."); return s;
    }
    private static int Int(JsonElement e,string n,int min,int max) => IntValue(Property(e,n),n,min,max);
    private static int IntValue(JsonElement p,string n,int min,int max) => p.ValueKind==JsonValueKind.Number && p.TryGetInt32(out int v) && v>=min && v<=max?v:throw new ImportException(n+": неверное число.");
    private static int? OptionalInt(JsonElement e,string n,int min,int max) => !e.TryGetProperty(n,out var p)||p.ValueKind==JsonValueKind.Null?null:IntValue(p,n,min,max);
    private static bool? OptionalBool(JsonElement e,string n) => !e.TryGetProperty(n,out var p)||p.ValueKind==JsonValueKind.Null?null:p.ValueKind is JsonValueKind.True or JsonValueKind.False?p.GetBoolean():throw new ImportException(n+": ожидается true или false.");
    private static Rgb Color(JsonElement e,string n) => Rgb.TryParse(Text(e,n,7),out var c)?c:throw new ImportException(n+": ожидается #RRGGBB.");
    private static List<string> StringArray(JsonElement e,string n,int maxLength,int maxCount)
    {
        var result=new List<string>(); if(!e.TryGetProperty(n,out var arr)) return result;
        RequireArray(arr,n); if(arr.GetArrayLength()>maxCount) throw new ImportException(n+": слишком много элементов.");
        foreach(var x in arr.EnumerateArray()) { if(x.ValueKind!=JsonValueKind.String || x.GetString() is not {Length:>0} s || s.Length>maxLength) throw new ImportException(n+": неверная строка."); if(!result.Contains(s,StringComparer.Ordinal)) result.Add(s); }
        return result;
    }
}
