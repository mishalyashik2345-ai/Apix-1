using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Apix.Core;
// Fields DelayMs/AntiRepeatMs/UsesGcd/Gcd/Jitter are retained only for reading
// older profile files. The clicker never uses them.
public sealed record RowFile(int Id,string Color,string Key,bool Enabled,int DelayMs,int AntiRepeatMs,bool UsesGcd,int Priority);
public sealed record ProfileFile(int Version,string Export,int SpellX,int SpellY,int IdentityX,int IdentityY,int Tolerance,int Interval,int Gcd,List<RowFile> Rows,int Area=1,int Jitter=0,bool AutoPixels=true);
public sealed record StoredProfile(ProfileFile File,Profile Profile);
public static class ProfileCodec
{
    public static StoredProfile Read(string json)
    {
        if(json is null || Encoding.UTF8.GetByteCount(json)>4_000_000) throw new ImportException("Профиль пуст или слишком велик.");
        ProfileFile file;
        try { file=JsonSerializer.Deserialize<ProfileFile>(json) ?? throw new ImportException("Пустой профиль."); }
        catch(JsonException e) { throw new ImportException("Неверный JSON профиля: "+e.Message); }
        if(file.Version is <1 or >4 || file.Export is null || file.Rows is null || file.Rows.Count>5000 ||
           file.SpellX is <0 or >100000 || file.SpellY is <0 or >100000 || file.IdentityX is <0 or >100000 || file.IdentityY is <0 or >100000 ||
           file.Tolerance is <0 or >50 || file.Interval is <5 or >500 || (file.Version>=2 && file.Area is not (1 or 3 or 5)))
            throw new ImportException("Неверный формат или настройки профиля.");
        var imported=ExportImporter.Import(file.Export,file.Tolerance).Profile;
        var rows=new Dictionary<int,RowFile>();
        foreach(var row in file.Rows) if(row is null || !rows.TryAdd(row.Id,row)) throw new ImportException("Повторный или неверный ID в профиле.");
        if(rows.Count!=imported.Triggers.Count || imported.Triggers.Any(t=>!rows.ContainsKey(t.SpellId))) throw new ImportException("Список настроек не соответствует экспорту.");
        var triggers=new List<Trigger>();
        foreach(var t in imported.Triggers)
        {
            var row=rows[t.SpellId];
            if(!Rgb.TryParse(row.Color,out var color) || color==Rgb.Black || row.Key is null || row.Key.Length>60 || row.Key.Length==0) throw new ImportException("Неверный цвет или клавиша у "+t.SpellId);
            triggers.Add(t with {Color=color,Key=row.Key,Enabled=row.Enabled,Priority=row.Priority});
        }
        if(Palette.FindConflicts(triggers.Select(t=>(t.SpellId.ToString(),t.Color)),file.Tolerance).Count>0) throw new ImportException("Конфликт цветов в профиле.");
        return new(file,imported with {Triggers=triggers.AsReadOnly()});
    }
    public static string Serialize(ProfileFile file) => JsonSerializer.Serialize(file,new JsonSerializerOptions{WriteIndented=true});
}
public sealed class ProfileLibrary(string directory)
{
    public string DirectoryPath {get;} = directory;
    private static string NameFor(Identity id)
    {
        byte[] hash=SHA256.HashData(Encoding.UTF8.GetBytes(id.StableKey));
        return Convert.ToHexString(hash)+".json";
    }
    public void Save(ProfileFile file)
    {
        string text=ProfileCodec.Serialize(file);
        var stored=ProfileCodec.Read(text);
        if(stored.Profile.Identity is null) throw new ImportException("Для автоматического сохранения нужен identity.");
        Directory.CreateDirectory(DirectoryPath);
        string path=Path.Combine(DirectoryPath,NameFor(stored.Profile.Identity));
        string temp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
        try { File.WriteAllText(temp,text,Encoding.UTF8); File.Move(temp,path,true); }
        finally { if(File.Exists(temp)) File.Delete(temp); }
    }
    public (IReadOnlyList<StoredProfile> Profiles,IReadOnlyList<string> Errors) LoadAll()
    {
        var entries=new List<StoredProfile>(); var errors=new List<string>();
        if(!Directory.Exists(DirectoryPath)) return (entries.AsReadOnly(),errors.AsReadOnly());
        foreach(string file in Directory.EnumerateFiles(DirectoryPath,"*.json").OrderBy(x=>x,StringComparer.OrdinalIgnoreCase))
        {
            if(entries.Count>=100) {errors.Add("Лимит библиотеки: 100 профилей."); break;}
            try {
                if(new FileInfo(file).Length>4_000_000) throw new ImportException("Файл слишком велик.");
                var p=ProfileCodec.Read(File.ReadAllText(file));
                if(p.Profile.Identity is null) throw new ImportException("Нет identity.");
                if(entries.Any(x=>x.Profile.Identity?.StableKey==p.Profile.Identity.StableKey)) throw new ImportException("Дублирующийся персонаж и специализация.");
                entries.Add(p);
            } catch(Exception e) when(e is ImportException or IOException or UnauthorizedAccessException) { errors.Add(Path.GetFileName(file)+": "+e.Message); }
        }
        return (entries.AsReadOnly(),errors.AsReadOnly());
    }
}
public sealed record ProfileLocateResult(LocateState State, StoredProfile? Profile, PixelLocation? Location,string Message);
public static class ProfileLocator
{
    public static ProfileLocateResult Find(PixelFrame frame,IReadOnlyList<StoredProfile> profiles,int tolerance,int area)
    {
        var valid=profiles.Where(p=>p.Profile.Identity is not null).ToList();
        if(valid.Count==0) return new(LocateState.NotFound,null,null,"Нет сохранённых профилей с identity.");
        StoredProfile? selected=null; PixelLocation? location=null;
        foreach(var profile in valid)
        {
            var result=PixelLocator.Find(frame,profile.Profile,tolerance,area);
            if(result.State==LocateState.Invalid) return new(LocateState.Invalid,null,null,result.Message);
            if(result.State==LocateState.Ambiguous) return new(LocateState.Ambiguous,null,null,result.Message);
            if(result.State==LocateState.Found)
            {
                if(selected is not null) return new(LocateState.Ambiguous,null,null,"На кадре найдено больше одного профиля. Выберите нужный вручную на странице «Профили».");
                selected=profile; location=result.Location;
            }
        }
        return selected is null ? new(LocateState.NotFound,null,null,"Активный персонаж не найден среди сохранённых профилей.") : new(LocateState.Found,selected,location,"Профиль найден.");
    }
    // An explicit choice constrains lookup to exactly that profile; it never proves
    // identity when another character's colour falls within the same tolerance.
    public static ProfileLocateResult FindSelected(PixelFrame frame,IReadOnlyList<StoredProfile> profiles,string stableKey,int tolerance,int area)
    {
        var selected=profiles.Where(p=>p.Profile.Identity?.StableKey==stableKey).Take(2).ToArray();
        if(selected.Length!=1) return new(LocateState.Invalid,null,null,"Выбранный профиль не найден или продублирован в библиотеке.");
        return Find(frame,selected,tolerance,area);
    }
}
