namespace Apix.Core;
public static class Palette
{
    public static IReadOnlyList<string> FindConflicts(IEnumerable<(string Name,Rgb Color)> source, int tolerance)
    {
        if(tolerance<0 || tolerance>50) throw new ArgumentOutOfRangeException(nameof(tolerance));
        var entries=source.ToList(); var problems=new List<string>();
        for(int i=0;i<entries.Count;i++)
        {
            if(entries[i].Color.Distance(Rgb.Black)<=2*tolerance) problems.Add(entries[i].Name+" слишком близок к чёрному");
            for(int j=0;j<i;j++) if(entries[i].Color.Distance(entries[j].Color)<=2*tolerance) problems.Add(entries[i].Name+" пересекается с "+entries[j].Name);
            if(problems.Count>=100) break;
        }
        return problems;
    }
}
public enum MatchState { CaptureError, Black, Unknown, Ambiguous, MixedArea, Disabled, Matched }
public sealed record MatchResult(MatchState State, Trigger? Trigger=null);
public static class ColorMatcher
{
    // Include disabled colours in ambiguity detection. A disabled colour must never
    // cause a nearby enabled ability to fire. Read failure is not black.
    public static MatchResult Match(Profile profile, Rgb? reading, int tolerance)
    {
        if(tolerance<0 || tolerance>50) throw new ArgumentOutOfRangeException(nameof(tolerance));
        if(reading is null) return new(MatchState.CaptureError);
        var matches=profile.Triggers.Where(t=>t.Color.Distance(reading.Value)<=tolerance).Take(2).ToList();
        bool black=Rgb.Black.Distance(reading.Value)<=tolerance;
        if(matches.Count>1 || (black && matches.Count>0)) return new(MatchState.Ambiguous);
        if(black) return new(MatchState.Black);
        if(matches.Count==0) return new(MatchState.Unknown);
        return matches[0].Enabled?new(MatchState.Matched,matches[0]):new(MatchState.Disabled,matches[0]);
    }
    // Black may be read mid-frame together with the old recommendation while
    // the addon switches the guard signal. Never fire during that transition;
    // wait for a uniform signal instead of permanently disarming.
    public static bool IsBlackTransition(MatchResult match,IReadOnlyList<Rgb?>? pixels,int tolerance)
    {
        if(tolerance<0 || tolerance>50) throw new ArgumentOutOfRangeException(nameof(tolerance));
        return match.State==MatchState.MixedArea && pixels is not null &&
            pixels.Any(p=>p is Rgb c && c.Distance(Rgb.Black)<=tolerance);
    }
    public static MatchResult MatchArea(Profile profile, IReadOnlyList<Rgb?>? pixels, int tolerance)
    {
        if(pixels is null || pixels.Count==0) return new(MatchState.CaptureError);
        MatchResult? first=null;
        foreach(var pixel in pixels)
        {
            var current=Match(profile,pixel,tolerance);
            if(current.State is MatchState.CaptureError or MatchState.Ambiguous) return current;
            if(first is null) first=current;
            else if(first.State!=current.State || first.Trigger?.SpellId!=current.Trigger?.SpellId) return new(MatchState.MixedArea);
        }
        return first!;
    }
}
public static class IdentityMatcher
{
    public static Profile? Match(IEnumerable<Profile> profiles, Rgb? reading, int tolerance)
    {
        if(tolerance<0 || tolerance>50) throw new ArgumentOutOfRangeException(nameof(tolerance));
        if(reading is null || reading.Value.Distance(Rgb.Black)<=tolerance) return null;
        var matches=profiles.Where(p=>p.Identity is not null && p.Identity.Color.Distance(reading.Value)<=tolerance).Take(2).ToList();
        return matches.Count==1?matches[0]:null;
    }
}
