namespace Apix.Core;
// A single global rate limit. No GCD, spell cooldown or per-spell anti-repeat.
// Missed ticks are never replayed; a late click moves the next deadline forward.
public sealed class ClickSchedule
{
    public int IntervalMs {get;}
    private long? _last;
    public ClickSchedule(int intervalMs)
    {
        if(intervalMs is <5 or >500) throw new ArgumentOutOfRangeException(nameof(intervalMs));
        IntervalMs=intervalMs;
    }
    public bool Due(long monotonicMs) => _last is null || (monotonicMs>=_last.Value && monotonicMs-_last.Value>=IntervalMs);
    public void MarkSent(long monotonicMs)
    {
        if(!Due(monotonicMs)) throw new InvalidOperationException("The click interval has not elapsed.");
        _last=monotonicMs;
    }
}
