namespace Apix.Core;

public readonly record struct Rgb(byte R, byte G, byte B)
{
    public static Rgb Black => new(0, 0, 0);
    public static bool TryParse(string? text, out Rgb color)
    {
        color = default;
        if (text is null || text.Length != 7 || text[0] != '#' || text.AsSpan(1).ToArray().Any(c=>!Uri.IsHexDigit(c))) return false;
        if (!byte.TryParse(text.AsSpan(1, 2), System.Globalization.NumberStyles.HexNumber, null, out byte r) ||
            !byte.TryParse(text.AsSpan(3, 2), System.Globalization.NumberStyles.HexNumber, null, out byte g) ||
            !byte.TryParse(text.AsSpan(5, 2), System.Globalization.NumberStyles.HexNumber, null, out byte b)) return false;
        color = new(r, g, b); return true;
    }
    public int Distance(Rgb other) => Math.Max(Math.Abs(R-other.R), Math.Max(Math.Abs(G-other.G), Math.Abs(B-other.B)));
    public override string ToString() => $"#{R:X2}{G:X2}{B:X2}";
}

public sealed record Identity(string Name, string Realm, string Class, string ClassName, int SpecId, string SpecName, Rgb Color)
{
    public string StableKey => string.Join("\u001f", Name, Realm, Class, SpecId.ToString(System.Globalization.CultureInfo.InvariantCulture));
}
public sealed record UiRectangle(int X, int Y, int Size);
public sealed record PixelLayout(string Unit, UiRectangle Spell, UiRectangle Identity);
public sealed record SourceBinding(string Button, int Slot, IReadOnlyList<string> Keys);
public sealed record Trigger(int SpellId, string Name, Rgb Color, string Key, IReadOnlyList<string> Keys,
    string Kind, string Button, int Slot, int RawSpellId, string? MacroName, IReadOnlyList<SourceBinding> Bindings,
    bool Enabled = false, int Priority = 0, int DelayMs = 0, int AntiRepeatMs = 100, bool UsesGcd = true);
public sealed record Macro(int MacroId, string Name, string Key, int? SpellId, bool SelectedForTrigger, string? Reason);
public sealed record Profile(int SchemaVersion, Identity? Identity, PixelLayout PixelLayout, int DeclaredColorTolerance,
    IReadOnlyList<Trigger> Triggers, IReadOnlyList<Macro> Macros);
public sealed record ImportResult(Profile Profile, IReadOnlyList<string> Warnings);

public enum KeyKind { Keyboard, Mouse }
public sealed record KeyChord(KeyKind Kind, string Key, bool Ctrl, bool Alt, bool Shift)
{
    public static bool TryParse(string? raw, out KeyChord? result)
    {
        result=null;
        if (string.IsNullOrWhiteSpace(raw) || raw.Length>60 || raw != raw.Trim()) return false;
        string[] parts=raw.ToUpperInvariant().Split('-');
        bool ctrl=false,alt=false,shift=false;
        if (parts.Length==0 || parts.Any(string.IsNullOrEmpty)) return false;
        for(int i=0;i<parts.Length-1;i++)
        {
            switch(parts[i])
            {
                case "CTRL" when !ctrl: ctrl=true; break;
                case "ALT" when !alt: alt=true; break;
                case "SHIFT" when !shift: shift=true; break;
                default: return false;
            }
        }
        string key=parts[^1];
        bool mouse=key is "BUTTON1" or "BUTTON2" or "BUTTON3" or "BUTTON4" or "BUTTON5";
        bool keyboard=(key.Length==1 && ((key[0]>='A' && key[0]<='Z') || (key[0]>='0' && key[0]<='9')))
            || (key.Length>=2 && key[0]=='F' && int.TryParse(key.AsSpan(1), out int f) && f>=1 && f<=24 && key==$"F{f}")
            || (key.Length==7 && key.StartsWith("NUMPAD", StringComparison.Ordinal) && key[6]>='0' && key[6]<='9')
            || key is "NUMPADPLUS" or "NUMPADMINUS" or "NUMPADMULTIPLY" or "NUMPADDIVIDE" or "NUMPADDECIMAL" or "NUMPADENTER"
                or "SPACE" or "TAB" or "ENTER" or "BACKSPACE" or "DELETE" or "INSERT" or "HOME" or "END" or "PAGEUP" or "PAGEDOWN"
                or "UP" or "DOWN" or "LEFT" or "RIGHT" or "MINUS" or "EQUALS" or "COMMA" or "PERIOD" or "SLASH" or "SEMICOLON"
                or "APOSTROPHE" or "LEFTBRACKET" or "RIGHTBRACKET" or "BACKSLASH" or "GRAVE";
        if (!mouse && !keyboard) return false;
        result=new(mouse?KeyKind.Mouse:KeyKind.Keyboard,key,ctrl,alt,shift); return true;
    }
}
