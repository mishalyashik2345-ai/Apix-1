namespace Apix.Core;

public static class WindowDiscoveryRules
{
    // This is a discovery heuristic, not authentication of the process.
    // Users must still explicitly select the correct HWND and PID.
    public static bool LooksLikeWow(string? processName,string? title)
    {
        if(!string.IsNullOrWhiteSpace(processName) && processName.StartsWith("wow",StringComparison.OrdinalIgnoreCase)) return true;
        return !string.IsNullOrWhiteSpace(title) && title.Contains("World of Warcraft",StringComparison.OrdinalIgnoreCase);
    }
}
