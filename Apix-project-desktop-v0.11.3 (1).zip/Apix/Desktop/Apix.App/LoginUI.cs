using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using Apix.Core;

namespace Apix.App;
public partial class MainWindow
{
    private readonly LoginProfileStore _accountStore=new(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Apix","Accounts"));
    private readonly ObservableCollection<LoginProfile> _accounts=[];
    private bool _loginBusy;
    private CancellationTokenSource? _loginCts;

    private void LoadLoginAccounts(Guid? selected=null)
    {
        try {
            var result=_accountStore.Load();
            _accounts.Clear(); foreach(var p in result.Profiles) _accounts.Add(LoginCalibrationReuse.Apply(p,result.Profiles));
            AccountPicker.ItemsSource=_accounts;
            AccountPicker.SelectedItem=selected.HasValue ? _accounts.FirstOrDefault(p=>p.Id==selected.Value) : _accounts.FirstOrDefault();
            if(_accounts.Count==0 && string.IsNullOrEmpty(AccountExecutable.Text)) AccountExecutable.Text=TryDetectWowExe() ?? "";
            foreach(var error in result.Errors.Take(3)) Log("Ошибка профиля входа: "+error);
            if(result.Errors.Count>0) AccountStatus.Text="Некоторые профили входа не прочитаны; см. журнал.";
        } catch(Exception) { AccountStatus.Text="Не удалось прочитать профили входа. Проверьте доступ к папке Apix/Accounts."; Log(AccountStatus.Text); }
    }
    private void AccountPicker_SelectionChanged(object sender,SelectionChangedEventArgs e)
    {
        if(AccountPicker.SelectedItem is not LoginProfile p) return;
        AccountName.Text=p.Name; AccountRealm.Text=p.RealmName; AccountExecutable.Text=p.Executable;
        AccountUser.Clear(); AccountPassword.Clear();
        TrainingStatus.Text=$"Вход: {(p.Login is null?"не обучен":"обучен")} · мир: {(p.Realm is null?"не обучен":"обучен")}. Логин и пароль сохранены.";
    }
    private string? TryDetectWowExe()
    {
        try {
            var windows=Native.FindWindows();
            if(windows.Count==1) {
                using var proc=Process.GetProcessById(windows[0].ProcessId);
                var exe=proc.MainModule?.FileName;
                if(exe is not null && File.Exists(exe) && Path.GetExtension(exe).Equals(".exe",StringComparison.OrdinalIgnoreCase)) return exe;
            }
            if(windows.Count>0) return null;
            if(File.Exists(_gameInstallPath) && new FileInfo(_gameInstallPath).Length<32768) {
                string root=File.ReadAllText(_gameInstallPath).Trim();
                string[] names=["Wow.exe","Wow-64.exe","WowB.exe","Wow-64B.exe"];
                var hits=names.Select(n=>Path.Combine(root,n)).Where(File.Exists).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
                if(hits.Length==1) return hits[0];
            }
        } catch(Exception) { /* Leave empty: user may select the actual client. */ }
        return null;
    }
    private void NewAccount_Click(object sender,RoutedEventArgs e)
    {
        if(_loginBusy) return;
        AccountPicker.SelectedIndex=-1; AccountName.Clear(); AccountRealm.Clear(); AccountExecutable.Text=TryDetectWowExe() ?? ""; AccountUser.Clear(); AccountPassword.Clear();
        AccountSaveStatus.Text="Можно сохранить до обучения экранов.";
        TrainingStatus.Text="Новый профиль: введите данные и сохраните.";
    }
    private void BrowseWow_Click(object sender,RoutedEventArgs e)
    {
        if(_loginBusy) return;
        var dialog=new OpenFileDialog {Title="Выберите исполняемый файл клиента WoW 7.3.5",Filter="Приложения (*.exe)|*.exe",CheckFileExists=true};
        if(dialog.ShowDialog(this)==true) AccountExecutable.Text=dialog.FileName;
    }
    private void SaveAccount_Click(object sender,RoutedEventArgs e)
    {
        if(_loginBusy) return;
        try {
            var old=AccountPicker.SelectedItem as LoginProfile;
            string name=AccountName.Text.Trim(),realm=AccountRealm.Text.Trim(),exe=AccountExecutable.Text.Trim();
            if(string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(realm)) throw new InvalidOperationException("Укажите название профиля и мира.");
            if(!File.Exists(exe) || !Path.GetExtension(exe).Equals(".exe",StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Выберите существующий файл клиента WoW (.exe).");
            string user=AccountUser.Text,password=AccountPassword.Password;
            string secret;
            if(user.Length==0 && password.Length==0 && old is not null) secret=old.ProtectedCredentials;
            else secret=WindowsSecrets.Protect(user,password);
            bool exeChanged=old is not null && !string.Equals(old.Executable,exe,StringComparison.OrdinalIgnoreCase);
            bool realmChanged=old is not null && !string.Equals(old.RealmName,realm,StringComparison.Ordinal);
            var p=new LoginProfile(old?.Id??Guid.NewGuid(),name,realm,Path.GetFullPath(exe),secret,exeChanged?null:old?.Login,(exeChanged||realmChanged)?null:old?.Realm);
            p=LoginCalibrationReuse.Apply(p,_accounts);
            _accountStore.Save(p); AccountUser.Clear(); AccountPassword.Clear();
            LoadLoginAccounts(p.Id); AccountSaveStatus.Text="Профиль сохранён."; AccountStatus.Text=p.Login is not null && p.Realm is not null ? "Профиль сохранён. Подходящее обучение использовано повторно." : "Профиль сохранён. При необходимости обучите отсутствующие экраны."; Log("Профиль автовхода сохранён с защитой Windows DPAPI.");
        } catch(Exception ex) {
            // Never include input values or passwords in the diagnostic fallback.
            string detail=ex is InvalidOperationException or IOException or UnauthorizedAccessException or System.ComponentModel.Win32Exception or ArgumentException
                ? ex.Message : "Ошибка защиты или записи профиля ("+ex.GetType().Name+").";
            AccountSaveStatus.Text="Профиль не сохранён: "+detail; AccountStatus.Text=AccountSaveStatus.Text; Log("Не удалось сохранить профиль входа: "+detail);
        }
    }
    private void DeleteAccount_Click(object sender,RoutedEventArgs e)
    {
        if(_loginBusy || AccountPicker.SelectedItem is not LoginProfile p) return;
        if(MessageBox.Show("Удалить выбранный профиль входа? Это удалит его сохранённые учётные данные и обучение.","Apix — удалить профиль",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes) return;
        try { _accountStore.Delete(p.Id); LoadLoginAccounts(); if(_accounts.Count==0) NewAccount_Click(sender,e); AccountStatus.Text="Профиль входа удалён."; }
        catch(Exception ex) { AccountStatus.Text="Не удалось удалить профиль: "+ex.Message; }
    }
    private async void TrainLogin_Click(object sender,RoutedEventArgs e) => await TrainAsync(false);
    private async void TrainRealm_Click(object sender,RoutedEventArgs e) => await TrainAsync(true);
    private async Task TrainAsync(bool realm)
    {
        if(_loginBusy || _installInProgress || _startInProgress || AccountPicker.SelectedItem is not LoginProfile profile) { AccountStatus.Text="Сначала сохраните и выберите профиль входа."; return; }
        if(_armed) Disarm("Ввод остановлен для обучения автовхода.");
        _loginBusy=true; AccountPicker.IsEnabled=false; using var cts=new CancellationTokenSource(); _loginCts=cts;
        try {
            var wins=Native.FindWindows(); if(wins.Count!=1) throw new InvalidOperationException("Откройте ровно одно окно клиента WoW.");
            var game=wins[0];
            using(var running=Process.GetProcessById(game.ProcessId)) {
                string? path=running.MainModule?.FileName;
                if(path is null || !string.Equals(Path.GetFullPath(path),Path.GetFullPath(profile.Executable),StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Открыт не тот исполняемый файл, который выбран в профиле. Запустите выбранный клиент.");
            }
            AccountStatus.Text=realm?"Перейдите в WoW к списку миров за 5 секунд. Уберите курсор с заголовка и названия мира.":"Перейдите в WoW к экрану входа за 5 секунд. Уберите курсор с кнопки «Вход».";
            Log("Обучение автовхода: перейдите в окно игры за 5 секунд.");
            await Task.Delay(5000,cts.Token);
            if(!Native.Valid(game) || Native.GetForegroundWindow()!=game.Handle) throw new InvalidOperationException("Окно WoW не в фокусе. Повторите обучение и переключитесь в игру.");
            var frame=Native.CaptureClient(game) ?? throw new InvalidOperationException("Не удалось захватить изображение WoW через GDI.");
            var dialog=new LoginCalibrationWindow(frame,realm) {Owner=this};
            if(dialog.ShowDialog()!=true) { AccountStatus.Text="Обучение отменено."; return; }
            cts.Token.ThrowIfCancellationRequested();
            var updated=realm?profile with {Realm=dialog.RealmResult}:profile with {Login=dialog.LoginResult};
            _accountStore.Save(updated); LoadLoginAccounts(updated.Id);
            AccountStatus.Text=realm?"Экран мира сохранён.":"Экран входа сохранён.";
            Log(AccountStatus.Text+" Сохраняются только небольшие образцы кнопки и названия, не полный снимок.");
        } catch(OperationCanceledException) { AccountStatus.Text="Обучение отменено."; }
        catch(Exception ex) { AccountStatus.Text="Обучение не выполнено: "+ex.Message; Log(AccountStatus.Text); }
        finally { _loginCts=null; _loginBusy=false; AccountPicker.IsEnabled=true; }
    }
    private void CancelAccountLogin_Click(object sender,RoutedEventArgs e) { _loginCts?.Cancel(); AccountStatus.Text="Отмена…"; }

    private async void StartAccountLogin_Click(object sender,RoutedEventArgs e)
    {
        if(_loginBusy || _installInProgress || _startInProgress) return;
        if(!_hotkeyRegistered) { AccountStatus.Text="Ctrl+F12 не зарегистрирован. Освободите сочетание и перезапустите Apix."; Log(AccountStatus.Text); return; }
        if(AccountPicker.SelectedItem is not LoginProfile profile) { Navigation_Click(NavAccounts,e); AccountStatus.Text="Создайте и выберите профиль входа."; return; }
        if(profile.Login is null || profile.Realm is null) { Navigation_Click(NavAccounts,e); AccountStatus.Text="Сначала обучите экран входа и выбор мира для этого профиля."; return; }
        if(_armed) Disarm("Кликер остановлен перед автовходом.");
        _loginBusy=true; AccountPicker.IsEnabled=false; using var cts=new CancellationTokenSource(); _loginCts=cts;
        try { await RunLoginAsync(profile,cts.Token); }
        catch(OperationCanceledException) { AccountStatus.Text="Автовход отменён. Дальнейший ввод остановлен."; Log(AccountStatus.Text); }
        catch(LoginAutomationException ex) { AccountStatus.Text="Автовход остановлен: "+ex.Message; Log(AccountStatus.Text); }
        catch(Exception) { AccountStatus.Text="Автовход остановлен из-за ошибки клиента или доступа к профилю. Никаких повторных попыток не выполняется."; Log(AccountStatus.Text); }
        finally { _loginCts=null; _loginBusy=false; AccountPicker.IsEnabled=true; }
    }
    private sealed class LoginAutomationException(string message):Exception(message);
    private void LoginProgress(string message) { AccountStatus.Text=message; Log(message); }
    private static (PixelFrame Frame,ResolvedAnchor Anchor)? ResolveFrame(GameWindow game,int width,int height,ScreenPoint anchor,ScreenPatch patch)
    {
        if(!Native.LoginReady(game)) return null;
        var frame=Native.CaptureClient(game);
        if(frame is null || !Native.LoginReady(game)) return null;
        var resolved=ScreenScaling.Resolve(frame,width,height,anchor,patch);
        return resolved is null || !Native.LoginReady(game) ? null : (frame,resolved);
    }
    private static PixelFrame? VerifyFrame(GameWindow game,ResolvedAnchor anchor)
    {
        if(!Native.LoginReady(game)) return null;
        var frame=Native.CaptureClient(game);
        return frame is not null && Native.LoginReady(game) && anchor.Matches(frame) ? frame : null;
    }
    private static async Task TypeSecret(GameWindow game,string text,CancellationToken token)
    {
        foreach(char c in text) {
            token.ThrowIfCancellationRequested();
            if(char.IsControl(c) || !Native.SendLoginChar(game,c)) throw new LoginAutomationException("Окно потеряло фокус или ввод недоступен. Попытка прервана.");
            await Task.Delay(20,token);
        }
    }
    private static void MustClick(GameWindow game,ScreenPoint p)
    {
        if(!Native.ClickLoginPoint(game,p.X,p.Y)) throw new LoginAutomationException("Не удалось нажать в окне WoW или потерян фокус.");
    }
    private async Task RunLoginAsync(LoginProfile profile,CancellationToken token)
    {
        var login=profile.Login!;var realm=profile.Realm!;
        if(!File.Exists(profile.Executable)) throw new LoginAutomationException("Файл клиента не найден. Укажите его заново в профиле.");
        var existing=Native.FindWindows();
        if(existing.Count>1) throw new LoginAutomationException("Найдено несколько окон WoW. Оставьте одно окно, чтобы не вводить данные не в тот клиент.");
        GameWindow? attached=existing.Count==1?existing[0]:null;
        Process process;
        if(attached is not null) {
            Process? candidate=null;
            try {
                if(!Native.Exists(attached)) throw new LoginAutomationException("Окно WoW больше не существует.");
                candidate=Process.GetProcessById(attached.ProcessId);
                var path=candidate.MainModule?.FileName;
                if(path is null || !string.Equals(Path.GetFullPath(path),Path.GetFullPath(profile.Executable),StringComparison.OrdinalIgnoreCase))
                    throw new LoginAutomationException("Открыт другой клиент. Выберите правильный .exe в профиле или закройте окно.");
                process=candidate; candidate=null;
            } catch(LoginAutomationException) { candidate?.Dispose(); throw; }
              catch(Exception) { candidate?.Dispose(); throw new LoginAutomationException("Не удалось проверить путь работающего клиента. Проверьте права и .exe профиля."); }
            LoginProgress("Использую открытый клиент WoW. Перейдите на обученный экран входа и верните фокус игре.");
        } else {
            LoginProgress("Запускаю WoW. Ожидаю экран входа; при необходимости переключитесь в игру.");
            process=Process.Start(new ProcessStartInfo(profile.Executable) {UseShellExecute=false,WorkingDirectory=Path.GetDirectoryName(profile.Executable)!}) ?? throw new LoginAutomationException("Клиент не запустился.");
        }
        using(process) {
        GameWindow? game=null; ResolvedAnchor? loginAnchor=null; bool triedForeground=false; DateTime deadline=DateTime.UtcNow.AddSeconds(90);
        while(DateTime.UtcNow<deadline) {
            token.ThrowIfCancellationRequested();
            if(process.HasExited) throw new LoginAutomationException("Клиент WoW завершился.");
            game=Native.FindWindows().FirstOrDefault(w=>w.ProcessId==process.Id && (attached is null || (w.Handle==attached.Handle && w.ProcessId==attached.ProcessId)));
            if(game is not null && Native.Valid(game)) {
                if(attached is null && !triedForeground) { _=Native.SetForegroundWindow(game.Handle); triedForeground=true; }
                var candidateFrame=await Task.Run(()=>ResolveFrame(game,login.Width,login.Height,login.AnchorTopLeft,login.Anchor),token);
                if(candidateFrame is not null) {
                    await Task.Delay(350,token);
                    if(VerifyFrame(game,candidateFrame.Value.Anchor) is not null) { loginAnchor=candidateFrame.Value.Anchor; break; }
                }
            }
            await Task.Delay(350,token); game=null;
        }
        if(game is null || loginAnchor is null || VerifyFrame(game,loginAnchor) is null) throw new LoginAutomationException("Экран входа не распознан однозначно. Проверьте фокус, масштаб интерфейса и захват кадра.");
        LoginProgress("Экран входа распознан. Заполняю поля; не нажимайте клавиши и не двигайте мышь.");
        LoginSecret secret;
        try { secret=WindowsSecrets.Unprotect(profile.ProtectedCredentials); }
        catch(Exception) { throw new LoginAutomationException("Не удалось расшифровать данные текущим пользователем Windows. Сохраните логин и пароль заново."); }
        MustClick(game,loginAnchor.Map(login.User,login.AnchorTopLeft)); await Task.Delay(120,token);
        if(!Native.LoginReady(game) || Native.SendKey(game,"CTRL-A",out _)!=InputSendResult.Sent) throw new LoginAutomationException("Не удалось выделить поле логина.");
        await TypeSecret(game,secret.User,token);
        if(VerifyFrame(game,loginAnchor) is null) throw new LoginAutomationException("Экран входа изменился; ввод остановлен.");
        MustClick(game,loginAnchor.Map(login.Password,login.AnchorTopLeft)); await Task.Delay(120,token);
        if(!Native.LoginReady(game) || Native.SendKey(game,"CTRL-A",out _)!=InputSendResult.Sent) throw new LoginAutomationException("Не удалось выделить поле пароля.");
        await TypeSecret(game,secret.Password,token);
        if(VerifyFrame(game,loginAnchor) is null) throw new LoginAutomationException("Экран входа изменился; пароль не отправлен на вход.");
        MustClick(game,loginAnchor.Map(login.Submit,login.AnchorTopLeft));
        LoginProgress("Попытка ввода завершена. Ожидаю окно выбора мира; если появился код, ошибка или CAPTCHA, завершите проверку вручную.");
        deadline=DateTime.UtcNow.AddSeconds(90); PixelFrame? image=null; ResolvedAnchor? realmAnchor=null;
        while(DateTime.UtcNow<deadline) {
            token.ThrowIfCancellationRequested(); if(!Native.Exists(game)) throw new LoginAutomationException("Окно WoW закрыто.");
            var candidateFrame=await Task.Run(()=>ResolveFrame(game,realm.Width,realm.Height,realm.TitleTopLeft,realm.Title),token);
            if(candidateFrame is not null) {
                await Task.Delay(350,token); image=VerifyFrame(game,candidateFrame.Value.Anchor);
                if(image is not null) { realmAnchor=candidateFrame.Value.Anchor; break; }
            }
            await Task.Delay(350,token);
        }
        if(image is null || realmAnchor is null) throw new LoginAutomationException("Окно выбора мира не распознано однозначно. Выберите мир вручную или проверьте масштаб.");
        var originalRow=realmAnchor.Map(realm.OriginalRowTopLeft,realm.TitleTopLeft);
        ScreenPatch targetRealm;
        double realmPhaseX=realmAnchor.PhaseX+(originalRow.X-realmAnchor.Position.X)/realmAnchor.Scale-(realm.OriginalRowTopLeft.X-realm.TitleTopLeft.X);
        double realmPhaseY=realmAnchor.PhaseY+(originalRow.Y-realmAnchor.Position.Y)/realmAnchor.Scale-(realm.OriginalRowTopLeft.Y-realm.TitleTopLeft.Y);
        try { targetRealm=ScreenScaling.Scale(realm.Realm,realmAnchor.Scale,realmAnchor.Filter,realmPhaseX,realmPhaseY); }
        catch(ArgumentException) { throw new LoginAutomationException("Масштаб образца мира не поддерживается."); }
        var confirm=realmAnchor.Map(realm.Confirm,realm.TitleTopLeft);
        LoginProgress("Окно миров распознано. Ищу обученный мир.");
        for(int i=0;i<90;i++) {
            token.ThrowIfCancellationRequested();
            if(!Native.MoveLoginPointer(game,realmAnchor.Width-5,realmAnchor.Height-5)) throw new LoginAutomationException("Окно выбора мира потеряло фокус.");
            image=VerifyFrame(game,realmAnchor) ?? throw new LoginAutomationException("Окно выбора мира изменилось или потеряло фокус.");
            var matches=ScreenTemplate.FindInColumn(image,targetRealm,originalRow.X,realmAnchor.Position.Y+10,image.Height);
            if(matches.Count>1) throw new LoginAutomationException("Название мира найдено несколько раз; выбор остановлен.");
            if(matches.Count==1) {
                var point=new ScreenPoint(matches[0].X+targetRealm.Width/2,matches[0].Y+targetRealm.Height/2);
                MustClick(game,point); await Task.Delay(400,token);
                if(VerifyFrame(game,realmAnchor) is null) throw new LoginAutomationException("Окно выбора мира изменилось до подтверждения.");
                MustClick(game,confirm);
                LoginProgress("Команда выбора мира отправлена. Проверьте экран персонажей; кликер не запускался."); return;
            }
            int direction=i<15?120:-120;
            if(!Native.ScrollLogin(game,originalRow.X+5,originalRow.Y+targetRealm.Height/2,direction)) throw new LoginAutomationException("Не удалось прокрутить список миров или потерян фокус.");
            await Task.Delay(220,token);
        }
        throw new LoginAutomationException("Обученный мир не найден. Проверьте прокрутку и обучите название целиком заново.");
        } // process handle; the game process itself continues running
    }
}
