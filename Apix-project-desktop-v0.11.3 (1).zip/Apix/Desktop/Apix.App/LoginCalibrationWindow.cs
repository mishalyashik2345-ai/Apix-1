using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Apix.Core;

namespace Apix.App;
internal sealed class LoginCalibrationWindow : Window
{
    private readonly PixelFrame _frame;
    private readonly bool _realm;
    private readonly Image _image;
    private readonly TextBlock _help;
    private readonly List<ScreenPoint> _points=[];
    public LoginCalibration? LoginResult { get; private set; }
    public RealmCalibration? RealmResult { get; private set; }
    public LoginCalibrationWindow(PixelFrame frame,bool realm)
    {
        _frame=frame; _realm=realm;
        Title=realm?"Apix — обучение выбора мира":"Apix — обучение экрана входа";
        Width=1120; Height=800; MinWidth=800; MinHeight=600; WindowStartupLocation=WindowStartupLocation.CenterOwner;
        Background=new SolidColorBrush(Color.FromRgb(7,17,29)); Foreground=Brushes.White;
        var root=new Grid{Margin=new Thickness(14)}; root.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto}); root.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)}); root.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        _help=new TextBlock{FontSize=15,FontWeight=FontWeights.SemiBold,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,10)};
        root.Children.Add(_help);
        var data=new byte[frame.Width*frame.Height*4];
        for(int y=0;y<frame.Height;y++) for(int x=0;x<frame.Width;x++) { var c=frame.Pixel(x,y); int idx=(y*frame.Width+x)*4; data[idx]=c.B;data[idx+1]=c.G;data[idx+2]=c.R;data[idx+3]=255; }
        var bitmap=BitmapSource.Create(frame.Width,frame.Height,96,96,PixelFormats.Bgra32,null,data,frame.Width*4); bitmap.Freeze();
        _image=new Image{Source=bitmap,Stretch=Stretch.Uniform,HorizontalAlignment=HorizontalAlignment.Stretch,VerticalAlignment=VerticalAlignment.Stretch,Cursor=Cursors.Cross};
        _image.MouseLeftButtonDown+=OnClick; Grid.SetRow(_image,1); root.Children.Add(_image);
        var cancel=new Button{Content="Отмена",Width=110,Height=32,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(0,10,0,0)};
        cancel.Click+=(_,_)=>{DialogResult=false;}; Grid.SetRow(cancel,2); root.Children.Add(cancel); Content=root; SetHelp();
    }
    private void SetHelp()
    {
        string[] steps=_realm ? ["1/4. Нажмите на центр заголовка «Выбор мира».","2/4. Нажмите немного выше и левее начала названия нужного мира.","3/4. Нажмите немного ниже и правее конца этого названия (не захватывайте соседние строки).","4/4. Нажмите на центр кнопки «ОК»."] : ["1/3. Нажмите на центр поля логина.","2/3. Нажмите на центр поля пароля.","3/3. Нажмите на центр кнопки «Вход»."];
        _help.Text=steps[Math.Min(_points.Count,steps.Length-1)]+"  (На снимке; в игру ничего не отправляется.)";
    }
    private void OnClick(object sender,MouseButtonEventArgs e)
    {
        double scale=Math.Min(_image.ActualWidth/_frame.Width,_image.ActualHeight/_frame.Height);
        if(scale<=0) return; var p=e.GetPosition(_image);
        double left=(_image.ActualWidth-_frame.Width*scale)/2,top=(_image.ActualHeight-_frame.Height*scale)/2;
        int x=(int)((p.X-left)/scale),y=(int)((p.Y-top)/scale);
        if(x<0 || y<0 || x>=_frame.Width || y>=_frame.Height) return;
        _points.Add(new(x,y));
        int count=_realm?4:3;
        if(_points.Count<count) { SetHelp(); return; }
        try {
            if(!_realm) {
                var u=_points[0];var pw=_points[1];var submit=_points[2];
                if(Math.Abs(u.Y-pw.Y)<12 || Math.Abs(pw.Y-submit.Y)<12) throw new InvalidOperationException("Поля и кнопка должны находиться в разных местах.");
                int ax=submit.X-50,ay=submit.Y-10;
                var patch=ScreenPatch.Capture(_frame,ax,ay,100,20);
                if(patch.ColorfulCount()<15) throw new InvalidOperationException("Образец кнопки не распознан: нажмите точно в центре надписи «Вход».");
                LoginResult=new(_frame.Width,_frame.Height,u,pw,submit,new(ax,ay),patch);
            } else {
                var title=_points[0]; int ax=title.X-55,ay=title.Y-10;
                var anchor=ScreenPatch.Capture(_frame,ax,ay,110,20);
                int l=Math.Min(_points[1].X,_points[2].X),t=Math.Min(_points[1].Y,_points[2].Y);
                int w=Math.Abs(_points[1].X-_points[2].X)+1,h=Math.Abs(_points[1].Y-_points[2].Y)+1;
                if(h<7 || h>35 || w<20 || w>400) throw new InvalidOperationException("Обведите только название одного мира (высота до 35 пикселей).");
                var name=ScreenPatch.Capture(_frame,l,t,w,h);
                if(anchor.ColorfulCount()<15 || name.ColorfulCount()<15) throw new InvalidOperationException("Заголовок или название не распознаны. Выберите видимый текст целиком.");
                if(ScreenTemplate.FindInColumn(_frame,name,l,0,_frame.Height).Count!=1) throw new InvalidOperationException("Образец мира неоднозначен. Выделите его полное название с [Proxy ...].");
                RealmResult=new(_frame.Width,_frame.Height,new(ax,ay),anchor,new(l,t),name,_points[3]);
            }
            DialogResult=true;
        } catch(Exception ex) { _points.Clear(); _help.Text="Ошибка: "+ex.Message+" Начните выбор заново."; }
    }
}
