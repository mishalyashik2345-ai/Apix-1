namespace Apix.App;
public sealed record ProfileCard(string Title,string Detail,string Status,string StableKey);
