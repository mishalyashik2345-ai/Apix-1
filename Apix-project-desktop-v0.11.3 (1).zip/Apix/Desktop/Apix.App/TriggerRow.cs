using Apix.Core;
namespace Apix.App;
internal sealed class TriggerRow
{
    private readonly Trigger _source;
    public TriggerRow(Trigger t) { _source=t; Id=t.SpellId; Name=t.Name; Color=t.Color.ToString(); Key=t.Key; AllKeys=string.Join(", ",t.Keys); Kind=t.Kind; Enabled=false; DelayMs=t.DelayMs; AntiRepeatMs=t.AntiRepeatMs; UsesGcd=t.UsesGcd; Priority=t.Priority; }
    public int Id { get; }
    public string Name { get; }
    public string AllKeys { get; }
    public string Kind { get; }
    public string Color { get; set; }
    public string Key { get; set; }
    public bool Enabled { get; set; }
    public int DelayMs { get; set; }
    public int AntiRepeatMs { get; set; }
    public bool UsesGcd { get; set; }
    public int Priority { get; set; }
    public Trigger ToTrigger()
    {
        if(!Rgb.TryParse(Color,out var c) || c==Rgb.Black) throw new InvalidOperationException($"{Id}: цвет должен быть #RRGGBB и не чёрным.");
        if(Enabled && !KeyChord.TryParse(Key,out _)) throw new InvalidOperationException($"{Id}: непонятная клавиша {Key}.");
        if(Enabled && !Native.CanSend(Key)) throw new InvalidOperationException($"{Id}: ввод {Key} пока не поддерживается (часть спецклавиш не реализована). Выберите доступную клавиатурную привязку.");
        return _source with { Color=c,Key=Key,Enabled=Enabled,DelayMs=DelayMs,AntiRepeatMs=AntiRepeatMs,UsesGcd=UsesGcd,Priority=Priority };
    }
}
