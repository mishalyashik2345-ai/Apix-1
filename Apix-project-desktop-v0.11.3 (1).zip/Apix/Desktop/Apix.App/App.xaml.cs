using System.Runtime.InteropServices;
using System.Windows;
namespace Apix.App;
public partial class App : Application
{
    [DllImport("shell32.dll",CharSet=CharSet.Unicode,ExactSpelling=true)]
    private static extern int SetCurrentProcessExplicitAppUserModelID(string appId);
    protected override void OnStartup(StartupEventArgs e)
    {
        // Give Explorer a stable identity even when the app is started via dotnet.
        // Failure must never prevent the clicker from starting.
        try { _=SetCurrentProcessExplicitAppUserModelID("Apix.Desktop"); }
        catch(DllNotFoundException) { }
        catch(EntryPointNotFoundException) { }
        base.OnStartup(e);
    }
}
