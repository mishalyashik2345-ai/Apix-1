using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using System.IO;
using System.Text.Json;
using Microsoft.Win32;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Threading;
using Apix.Core;

namespace Apix.App;
public partial class MainWindow : Window
{
    private readonly ObservableCollection<TriggerRow> _rows=[];
    private readonly ObservableCollection<ProfileCard> _profileCards=[];
    private readonly DispatcherTimer _timer=new();
    private readonly DispatcherTimer _discoveryTimer=new() { Interval=TimeSpan.FromSeconds(2) };
    private GameWindow? _selectedWindow;
    private const int FixedIntervalMs=5;
    private int _profileSpellX=12,_profileSpellY=12,_profileIdentityX=35,_profileIdentityY=12;
    private int _profileTolerance=10,_profileArea=1;
    private bool _profileAutoPixels=true;
    private bool _nextStartIsTest, _resumeTestMode;
    private string _windowSignature="!initial";
    private readonly Stopwatch _clock=Stopwatch.StartNew();
    private readonly ProfileLibrary _library=new(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Apix","Profiles"));
    private IReadOnlyList<StoredProfile> _profiles=[];
    private IReadOnlyList<string> _profileErrors=[];
    private int _libraryGeneration;
    private bool _passiveScanBusy;
    private long _lastActionLog;
    private long? _previousSentAt;
    private long _spacingTotal;
    private int _spacingCount;
    private ClickSchedule? _schedule;
    private int _clickInterval;
    private string? _lastPassiveFailure;
    private long? _searchStarted;
    private long _lastSearchAt;
    private Profile? _profile, _runningProfile;
    private string? _manualProfileKey;
    private string? _exportText;
    private GameWindow? _window;
    private bool _armed, _focusPaused, _hotkeyRegistered, _dryRun, _autoLocate, _needsCalibration, _calibrating;
    private bool _startInProgress, _installInProgress;
    private readonly List<GameWindow> _restartRequiredWindows=[];
    private readonly string _gameInstallPath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Apix","game-folder.txt");
    private int _safetyEpoch;
    private HotkeySpec? _toggleHotkey;
    private int _toggleHotkeyId;
    private readonly string _settingsPath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Apix","settings.json");
    private sealed record AppSettings(string? ToggleHotkey);
    private int _calibrationGeneration, _calibrationWidth, _calibrationHeight;
    private int _sx,_sy,_ix,_iy,_tolerance,_areaSize;
    private nint _handle;
    private HwndSource? _source;
    private const int HotkeyId=3141;
    public MainWindow()
    {
        InitializeComponent(); TriggerGrid.ItemsSource=_rows; ProfileList.ItemsSource=_profileCards;
        _rows.CollectionChanged+=(_,_)=>ActionCountOverview.Text=_rows.Count.ToString();
        _timer.Tick+=Tick;
        _discoveryTimer.Tick+=(_,_)=> { AutoFindWindows(); TrySelectProfileWhenIdle(); };
        _discoveryTimer.Start();
        ReloadProfiles();
        LoadLoginAccounts();
        if(_profileErrors.Count>0) {
            ProfileLabel.Text="Ошибка загрузки библиотеки профилей";
            Log("Проверьте ошибки библиотеки в журнале. Папка: "+_library.DirectoryPath);
        } else if(_profiles.Count>0) {
            ProfileLabel.Text=$"Сохранено профилей: {_profiles.Count} · ожидание персонажа";
            Log($"Загружено сохранённых профилей: {_profiles.Count}. Активный персонаж определится, когда WoW получит фокус.");
        } else Log("Сохранённых профилей не найдено: "+_library.DirectoryPath+". Если это первая установка, импортируйте экспорт аддона.");
        SourceInitialized+=OnSourceInitialized;
        Closing+=(_,_)=> { if(!_armed && _profile?.Identity is not null) try { SaveCurrentToLibrary(); } catch(Exception ex) { MessageBox.Show("Не удалось автоматически сохранить профиль: "+ex.Message); } };
        Closed+=(_,_)=> { _loginCts?.Cancel(); _timer.Stop(); _discoveryTimer.Stop(); if(_hotkeyRegistered) Native.UnregisterHotKey(_handle,HotkeyId); if(_toggleHotkeyId!=0) Native.UnregisterHotKey(_handle,_toggleHotkeyId); if(_source is not null) _source.RemoveHook(Hook); };
        Log("Приложение запускается остановленным. После импорта строки включены; ввод начинается только после явного вооружения.");
    }
    private void OnSourceInitialized(object? sender,EventArgs e)
    {
        _handle=new WindowInteropHelper(this).Handle; _source=HwndSource.FromHwnd(_handle); _source?.AddHook(Hook);
        _hotkeyRegistered=Native.RegisterHotKey(_handle,HotkeyId,0x4002,0x7B); // MOD_CONTROL | MOD_NOREPEAT, F12
        LoadToggleHotkey();
        AutoFindWindows();
        Log(_hotkeyRegistered?"Аварийный Ctrl+F12 зарегистрирован.":"ОШИБКА: Ctrl+F12 не зарегистрирован. Запуск заблокирован; проверьте конфликт с другой программой.");
    }
    private nint Hook(nint hwnd,int message,nint wParam,nint lParam,ref bool handled)
    {
        if(message==0x0312 && wParam.ToInt32()==HotkeyId) { _loginCts?.Cancel(); Disarm("Аварийная остановка Ctrl+F12"); handled=true; }
        else if(message==0x0312 && _toggleHotkeyId!=0 && wParam.ToInt32()==_toggleHotkeyId) {
            handled=true;
            if(!_startInProgress && !_installInProgress && !_loginBusy) {
                if(_armed) Disarm("Пауза по хоткею. Повторное нажатие запускает кликер.");
                else { _nextStartIsTest=_resumeTestMode; try { Start_Click(this,new RoutedEventArgs()); } finally { _nextStartIsTest=false; } }
            }
        }
        return 0;
    }
    private void LoadToggleHotkey()
    {
        if(!File.Exists(_settingsPath)) { HotkeyLabel.Text="Не назначен — выберите свободную клавишу и нажмите «Назначить»"; return; }
        try {
            if(new FileInfo(_settingsPath).Length>4096) throw new InvalidOperationException("Файл настроек слишком велик.");
            var settings=JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(_settingsPath));
            if(!HotkeySpec.TryParse(settings?.ToggleHotkey,out var key) || key is null) throw new InvalidOperationException("Неверный хоткей в настройках.");
            ToggleHotkeyBox.Text=key.Text;
            if(!RegisterToggleHotkey(key)) { HotkeyLabel.Text="Не зарегистрирован: клавиша занята"; Log("Хоткей "+key.Text+" не зарегистрирован: клавиша может быть занята. Выберите другую."); }
        } catch(Exception ex) { HotkeyLabel.Text="Не назначен"; Log("Не удалось загрузить хоткей: "+ex.Message); }
    }
    private bool RegisterToggleHotkey(HotkeySpec key)
    {
        if(_toggleHotkey is not null && _toggleHotkeyId!=0 && _toggleHotkey.VirtualKey==key.VirtualKey && _toggleHotkey.Modifiers==key.Modifiers) return true;
        int newId=_toggleHotkeyId==3142?3143:3142;
        if(!Native.RegisterHotKey(_handle,newId,key.Modifiers|0x4000,key.VirtualKey)) return false; // MOD_NOREPEAT
        if(_toggleHotkeyId!=0) Native.UnregisterHotKey(_handle,_toggleHotkeyId);
        _toggleHotkeyId=newId; _toggleHotkey=key;
        ToggleHotkeyBox.Text=key.Text; HotkeyLabel.Text="Назначен: "+key.Text+" (глобально)";
        Log("Пуск/пауза: "+key.Text+". Клавиша перехватывается глобально, выберите свободный бинд.");
        return true;
    }
    private void ApplyHotkey_Click(object sender,RoutedEventArgs e)
    {
        if(_armed || _startInProgress) return;
        if(!HotkeySpec.TryParse(ToggleHotkeyBox.Text,out var key) || key is null) { Log("Неверный хоткей. Пример: ~, Ё, F8 или CTRL-F11. F12 оставлен аварийному останову; мышь не поддерживается."); return; }
        if(_rows.Any(r=>r.Enabled && key.ConflictsWithTrigger(r.Key))) { Log("Хоткей конфликтует с включённой клавишей действия. Выберите другую основную клавишу или отключите действие."); return; }
        if(!RegisterToggleHotkey(key)) { Log("Не удалось назначить "+key.Text+": возможно, клавиша занята системой или другой программой. Предыдущий хоткей сохранён."); return; }
        try {
            Directory.CreateDirectory(Path.GetDirectoryName(_settingsPath)!);
            string temp=_settingsPath+"."+Guid.NewGuid().ToString("N")+".tmp";
            try { File.WriteAllText(temp,JsonSerializer.Serialize(new AppSettings(key.Text))); File.Move(temp,_settingsPath,true); }
            finally { if(File.Exists(temp)) File.Delete(temp); }
        } catch(Exception ex) { Log("Хоткей работает, но не сохранён после перезапуска: "+ex.Message); }
    }
    private void ClearHotkey_Click(object sender,RoutedEventArgs e)
    {
        if(_armed || _startInProgress) return;
        if(_toggleHotkeyId!=0) Native.UnregisterHotKey(_handle,_toggleHotkeyId);
        _toggleHotkeyId=0; _toggleHotkey=null; HotkeyLabel.Text="Не назначен";
        try { if(File.Exists(_settingsPath)) File.Delete(_settingsPath); Log("Хоткей пуска/паузы снят. Аварийный Ctrl+F12 продолжает работать."); }
        catch(Exception ex) { Log("Хоткей снят сейчас, но файл настроек не удалён; он может вернуться после перезапуска: "+ex.Message); }
    }
    private string? UnsafeTriggerKey(Profile p)
    {
        foreach(var t in p.Triggers.Where(x=>x.Enabled)) {
            var plan=InputPlanner.Create(t.Key);
            if(plan is null) return "Неподдерживаемая клавиша: "+t.Key;
            if(plan.MainVirtualKey==0x7B) return "F12 зарезервирована для аварийного Ctrl+F12: "+t.Key;
            if(_toggleHotkey?.ConflictsWithTrigger(t.Key)==true) return "Хоткей пуска/паузы конфликтует с действием: "+t.Key+". Выберите другую основную клавишу хоткея.";
        }
        return null;
    }
    private void EnterFocusPause()
    {
        if(!_armed || _focusPaused) return;
        _focusPaused=true; _calibrationGeneration++; _calibrating=false; _needsCalibration=_autoLocate; _searchStarted=null; _previousSentAt=null;
        StateLabel.Text="Пауза: WoW не в фокусе. При возврате ввод возобновится после проверки";
        Log("Фокус WoW потерян или окно свёрнуто. Ввод приостановлен; при возврате фокуса выполнится проверка и работа продолжится.");
    }
    private bool PauseIfUnavailable()
    {
        if(_window is null) return true;
        bool exists=Native.Exists(_window);
        var action=FocusPolicy.Decide(exists,exists && Native.Valid(_window),Native.GetForegroundWindow()==_window.Handle);
        if(action==FocusAction.Stop) { Disarm("Окно WoW закрыто или PID изменился"); return true; }
        if(action==FocusAction.Wait) { EnterFocusPause(); return true; }
        return false;
    }
    private void Log(string text)
    {
        bool preserveSelection=LogText.IsKeyboardFocusWithin;
        int selectionStart=LogText.SelectionStart, selectionEnd=selectionStart+LogText.SelectionLength;
        var allLines=LogText.Text.Split('\n').Where(s=>s.Length>0).ToList();
        int drop=Math.Max(0,allLines.Count-70);
        int removed=allLines.Take(drop).Sum(line=>line.Length+1);
        var lines=allLines.Skip(drop).ToList();
        lines.Add($"{DateTime.Now:HH:mm:ss}  {text}");
        LogText.Text=string.Join("\n",lines);
        if(!RecentLogText.IsKeyboardFocusWithin) {
            RecentLogText.Text=string.Join("\n",lines.TakeLast(5));
            RecentLogText.ScrollToEnd();
        }
        if(preserveSelection) {
            int length=LogText.Text.Length;
            int start=Math.Clamp(selectionStart-removed,0,length), end=Math.Clamp(selectionEnd-removed,start,length);
            LogText.Select(start,end-start);
        } else LogText.ScrollToEnd();
    }
    private static Dictionary<string,byte[]> ReadBundledAddon()
    {
        var files=new Dictionary<string,byte[]>(StringComparer.Ordinal);
        var assembly=typeof(MainWindow).Assembly;
        foreach(string name in AddonInstaller.Files) {
            using var stream=assembly.GetManifestResourceStream("Apix.BundledAddon."+name)
                ?? throw new InvalidOperationException("Отсутствует встроенный файл: "+name);
            using var memory=new MemoryStream(); stream.CopyTo(memory); files.Add(name,memory.ToArray());
        }
        return files;
    }
    private static string? ProcessGameRoot(GameWindow window)
    {
        if(!Native.Exists(window)) return null;
        using var process=Process.GetProcessById(window.ProcessId);
        string? exe=process.MainModule?.FileName;
        if(string.IsNullOrEmpty(exe) || !Native.Exists(window)) return null;
        return Path.GetDirectoryName(exe);
    }
    private string? AutoInstallRoot()
    {
        var windows=Native.FindWindows();
        if(windows.Count>0) {
            var roots=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach(var window in windows) {
                try {
                    string? root=ProcessGameRoot(window);
                    if(root is null || !AddonInstaller.IsGameRoot(root)) {
                        Log("Не удалось распознать папку окна WoW: "+(root ?? "путь процесса недоступен")+". Выберите папку вручную."); return null;
                    }
                    roots.Add(Path.GetFullPath(root));
                } catch(Exception ex) {
                    Log("Нет доступа к пути процесса WoW: "+ex.Message+". Выберите папку вручную."); return null;
                }
            }
            if(roots.Count==1) return roots.Single();
            Log("Открыто несколько разных папок WoW. Выберите нужную папку вручную."); return null;
        }
        try {
            if(File.Exists(_gameInstallPath) && new FileInfo(_gameInstallPath).Length<=32768) {
                string saved=File.ReadAllText(_gameInstallPath).Trim();
                if(AddonInstaller.IsGameRoot(saved)) return saved;
            }
        } catch(Exception ex) { Log("Сохранённая папка игры недоступна: "+ex.Message); }
        Log("Запущенная игра не найдена. Выберите папку WoW 7.3.5 вручную."); return null;
    }
    private string? ChooseGameRoot()
    {
        var dialog=new OpenFolderDialog {Title="Выберите папку WoW 7.3.5, Interface или AddOns",Multiselect=false};
        return dialog.ShowDialog(this)==true ? dialog.FolderName : null;
    }
    private void InstallAddon_Click(object sender,RoutedEventArgs e) => InstallAddon(false);
    private void ChooseAddonFolder_Click(object sender,RoutedEventArgs e) => InstallAddon(true);
    private void InstallAddon(bool chooseManually)
    {
        if(_installInProgress || _loginBusy) return;
        if(_armed || _startInProgress) Disarm("Ввод остановлен перед установкой аддона.");
        _installInProgress=true;
        try {
            string? root=chooseManually ? ChooseGameRoot() : AutoInstallRoot() ?? ChooseGameRoot();
            if(root is null) { InstallStatusLabel.Text="Установка отменена."; return; }
            root=AddonInstaller.NormalizeGameRoot(root);
            if(!AddonInstaller.IsGameRoot(root)) throw new InvalidOperationException("Папка не распознана: "+root+". Выберите корневую папку WoW, Interface или AddOns; в клиенте должны быть Wow.exe/Wow-64.exe либо папки Data и Interface/WTF.");
            // A full WoW restart is required. Block starts for currently open WoW
            // windows in this application session, including ambiguous cases.
            var openWindows=Native.FindWindows();
            foreach(var window in openWindows)
                if(!_restartRequiredWindows.Any(w=>w.Handle==window.Handle && w.ProcessId==window.ProcessId)) _restartRequiredWindows.Add(window);
            string destination=AddonInstaller.Install(root,ReadBundledAddon());
            try { Directory.CreateDirectory(Path.GetDirectoryName(_gameInstallPath)!); File.WriteAllText(_gameInstallPath,Path.GetFullPath(root)); }
            catch(Exception ex) { Log("Аддон установлен, но папку для следующего раза сохранить не удалось: "+ex.Message); }
            InstallStatusLabel.Text="Аддон установлен: "+destination+". Полностью перезапустите WoW.";
            Log("Apix 0.6.6 установлен в "+destination+". WTF и другие аддоны не изменялись. Полностью перезапустите WoW; проверьте, что это клиент 7.3.5.");
        } catch(Exception ex) {
            InstallStatusLabel.Text="Ошибка установки: "+ex.Message;
            Log("Ошибка установки аддона: "+ex.Message+". Проверьте путь и права записи.");
        } finally { _installInProgress=false; }
    }
    private void CopyLog_Click(object sender,RoutedEventArgs e)
    {
        try {
            if(string.IsNullOrEmpty(LogText.Text)) { LogCopyStatus.Text="Журнал пока пуст."; return; }
            Clipboard.SetText(LogText.Text);
            LogCopyStatus.Text="Журнал скопирован. Он может содержать имя персонажа и название окна.";
        } catch(Exception ex) {
            LogCopyStatus.Text="Не удалось скопировать: "+ex.Message+". Попробуйте выделить текст и нажать Ctrl+C.";
        }
    }
    private Profile Snapshot()
    {
        if(_profile is null) throw new InvalidOperationException("Сначала импортируйте экспорт аддона.");
        if(!TriggerGrid.CommitEdit(DataGridEditingUnit.Cell,true) || !TriggerGrid.CommitEdit(DataGridEditingUnit.Row,true)) throw new InvalidOperationException("Завершите редактирование и исправьте ошибочные значения в таблице.");
        var t=_rows.Select(r=>r.ToTrigger()).ToList();
        return _profile with { Triggers=t.AsReadOnly() };
    }
    private void Import_Click(object sender,RoutedEventArgs e)
    {
        if(_armed) { Log("Сначала остановите приложение."); return; }
        try {
            int tol=_profileTolerance;
            string input=Clipboard.GetText(); var result=ExportImporter.Import(input,tol);
            if(_profile?.Identity is not null) SaveCurrentToLibrary();
            // Replace only after full parsing/validation.
            _profile=result.Profile; _manualProfileKey=_profile.Identity?.StableKey; _exportText=input; _rows.Clear(); foreach(var t in _profile.Triggers) _rows.Add(new TriggerRow(t) {Enabled=true});
            ProfileLabel.Text=$"{_profile.Identity?.Name ?? "Без identity"}  ·  {_profile.Identity?.Realm ?? ""}  ·  {_profile.Identity?.SpecName ?? ""}  ·  {_rows.Count} действий / {_profile.Macros.Count} макросов";
            if(_profile.Identity is not null) { SaveCurrentToLibrary(); Log("Профиль автоматически сохранён в локальную библиотеку."); }
            else Log("Нет identity: автоматический выбор профиля невозможен.");
            Log($"Импортировано {_rows.Count} действий, все включены. Программа не запускается автоматически; проверьте клавиши.");
            foreach(string warning in result.Warnings) Log("Предупреждение: "+warning);
            foreach(var row in _rows.Where(r=>!Native.CanSend(r.Key))) Log($"Неподдерживаемая клавиша {row.Key} ({row.Name}): отключите строку или выберите действительный бинд до запуска.");
            if(_profile.Triggers.Any(t=>t.Keys.Contains("CTRL-F12",StringComparer.OrdinalIgnoreCase))) Log("ВНИМАНИЕ: Ctrl+F12 занят аварийным хоткеем приложения.");
        } catch(Exception ex) { Log("Ошибка импорта или локального сохранения: "+ex.Message); }
    }
    private ProfileFile CurrentProfileFile()
    {
        if(_profile is null || _exportText is null) throw new InvalidOperationException("Нет открытого профиля.");
        if(!TriggerGrid.CommitEdit(DataGridEditingUnit.Cell,true) || !TriggerGrid.CommitEdit(DataGridEditingUnit.Row,true)) throw new InvalidOperationException("Исправьте значения в таблице.");
        var data=new ProfileFile(4,_exportText,_profileSpellX,_profileSpellY,_profileIdentityX,_profileIdentityY,_profileTolerance,FixedIntervalMs,1000,
            _rows.Select(r=>new RowFile(r.Id,r.Color,r.Key,r.Enabled,0,100,false,r.Priority)).ToList(),_profileArea,0,_profileAutoPixels);
        _=ProfileCodec.Read(ProfileCodec.Serialize(data));
        return data;
    }
    private void ReloadProfiles()
    {
        try {
            var loaded=_library.LoadAll(); _profiles=loaded.Profiles; _profileErrors=loaded.Errors; _libraryGeneration++;
            RefreshProfileCards();
            foreach(var err in _profileErrors.Take(3)) Log("Ошибка библиотеки профилей: "+err);
        } catch(Exception ex) { _profiles=[]; _profileErrors=[ex.Message]; _libraryGeneration++; RefreshProfileCards(); Log("Библиотека профилей недоступна: "+ex.Message); }
    }
    private void RefreshProfileCards()
    {
        _profileCards.Clear();
        foreach(var entry in _profiles) {
            var id=entry.Profile.Identity;
            if(id is null) continue;
            string title=id.Name+" · "+id.SpecName;
            string detail=id.ClassName+" · "+id.Realm+" · "+entry.Profile.Triggers.Count+" действий";
            string state=id.StableKey==_manualProfileKey ? "ВЫБРАН ВРУЧНУЮ" : id.StableKey==_profile?.Identity?.StableKey ? "ОТКРЫТ" : "СОХРАНЁН";
            _profileCards.Add(new ProfileCard(title,detail,state,id.StableKey));
        }
        ProfileCountOverview.Text=_profileCards.Count.ToString();
        ProfileCountLabel.Text=_profileCards.Count.ToString();
        ProfileEmptyLabel.Visibility=_profileCards.Count==0?Visibility.Visible:Visibility.Collapsed;
    }
    private void ChooseProfile_Click(object sender,RoutedEventArgs e)
    {
        if(_armed || _startInProgress || _loginBusy || _installInProgress) { Log("Остановите ввод перед сменой профиля."); return; }
        if(sender is not Button {Tag:string key}) return;
        try {
            if(_profile?.Identity is not null) SaveCurrentToLibrary();
            var stored=_profiles.SingleOrDefault(p=>p.Profile.Identity?.StableKey==key);
            if(stored is null) { Log("Профиль больше не найден в библиотеке."); return; }
            _manualProfileKey=key; _libraryGeneration++; ApplyStoredProfile(stored,false);
            Log("Выбран профиль вручную: "+stored.Profile.Identity!.Name+" / "+stored.Profile.Identity.SpecName+". Если identity совпадает у персонажей, проверьте персонажа в WoW самостоятельно.");
        } catch(Exception ex) { Log("Не удалось выбрать профиль: "+ex.Message); }
    }
    private void AutomaticProfile_Click(object sender,RoutedEventArgs e)
    {
        if(_armed || _startInProgress || _loginBusy || _installInProgress) { Log("Остановите ввод перед сменой режима профиля."); return; }
        _manualProfileKey=null; _libraryGeneration++; _lastPassiveFailure=null; RefreshProfileCards();
        Log("Автоматический выбор профиля включён. Если текущему сигналу соответствуют несколько профилей, выберите нужный вручную.");
        TrySelectProfileWhenIdle();
    }
    private void SaveCurrentToLibrary()
    {
        var file=CurrentProfileFile();
        _library.Save(file); ReloadProfiles();
        if(_profileErrors.Count>0) throw new InvalidOperationException("Библиотека содержит ошибки; автоматический выбор заблокирован.");
    }
    private void ApplyStoredProfile(StoredProfile stored,bool preserveRunSettings)
    {
        var data=stored.File; _profile=stored.Profile; _exportText=data.Export;
        _rows.Clear();
        foreach(var trigger in stored.Profile.Triggers)
            _rows.Add(new TriggerRow(trigger) { Enabled=trigger.Enabled, Color=trigger.Color.ToString(), Key=trigger.Key, Priority=trigger.Priority });
        if(!preserveRunSettings) {
            _profileSpellX=data.SpellX; _profileSpellY=data.SpellY; _profileIdentityX=data.IdentityX; _profileIdentityY=data.IdentityY;
            _profileTolerance=data.Tolerance; _profileArea=data.Version==1?1:data.Area; _profileAutoPixels=data.Version<3 || data.AutoPixels;
        }
        ProfileLabel.Text=$"{_profile.Identity?.Name ?? "Без identity"}  ·  {_profile.Identity?.Realm ?? ""}  ·  {_profile.Identity?.SpecName ?? ""}  ·  {_rows.Count} действий / {_profile.Macros.Count} макросов";
        RefreshProfileCards();
    }
    private void Save_Click(object sender,RoutedEventArgs e)
    {
        if(_armed) return;
        try {
            var data=CurrentProfileFile();
            var dialog=new SaveFileDialog { Filter="Apix profile (*.json)|*.json",FileName="apix-profile.json",AddExtension=true };
            if(dialog.ShowDialog()!=true) return;
            string temp=dialog.FileName+"."+Guid.NewGuid().ToString("N")+".tmp";
            try { File.WriteAllText(temp,ProfileCodec.Serialize(data)); File.Move(temp,dialog.FileName,true); }
            finally { if(File.Exists(temp)) File.Delete(temp); }
            SaveCurrentToLibrary();
            Log("Профиль сохранён в файл и локальную библиотеку. Он содержит имя и мир персонажа.");
        } catch(Exception ex) { Log("Профиль не сохранён: "+ex.Message); }
    }
    private void Load_Click(object sender,RoutedEventArgs e)
    {
        if(_armed) return;
        try {
            var dialog=new OpenFileDialog { Filter="Apix profile (*.json)|*.json",CheckFileExists=true };
            if(dialog.ShowDialog()!=true) return;
            if(new FileInfo(dialog.FileName).Length>4_000_000) throw new InvalidOperationException("Файл слишком большой.");
            var loaded=ProfileCodec.Read(File.ReadAllText(dialog.FileName));
            if(_profile?.Identity is not null) SaveCurrentToLibrary();
            _manualProfileKey=loaded.Profile.Identity?.StableKey;
            ApplyStoredProfile(loaded,false);
            if(loaded.Profile.Identity is not null) SaveCurrentToLibrary();
            Log("Профиль открыт и добавлен в библиотеку; ввод не запущен. Старые GCD/антиповтор не используются.");
        } catch(Exception ex) { Log("Профиль не загружен: "+ex.Message); }
    }
    private void EnableAll_Click(object sender,RoutedEventArgs e)
    {
        if(_armed) return;
        foreach(var row in _rows) row.Enabled=true;
        TriggerGrid.Items.Refresh(); Log("Все строки включены. Ввод не запущен.");
    }
    private void DisableAll_Click(object sender,RoutedEventArgs e)
    {
        if(_armed) return;
        foreach(var row in _rows) row.Enabled=false;
        TriggerGrid.Items.Refresh(); Log("Все строки выключены.");
    }
    private void AutoFindWindows()
    {
        if(_armed) return;
        try {
            var found=Native.FindWindows();
            string sig=string.Join("|",found.Select(w=>$"{w.Handle}:{w.ProcessId}:{w.Title}:{w.ProcessName}"));
            if(sig==_windowSignature) return;
            _windowSignature=sig;
            var previous=_selectedWindow;
            var still=previous is null?null:found.FirstOrDefault(w=>w.Handle==previous.Handle && w.ProcessId==previous.ProcessId);
            if(still is not null) _selectedWindow=still;
            else if(found.Count==1) { _selectedWindow=found[0]; Log("Окно WoW обнаружено автоматически: "+found[0]); }
            else {
                _selectedWindow=null;
                if(found.Count>1) Log($"Найдено {found.Count} окон WoW. Оставьте одно окно игры: автоматический выбор неоднозначен.");
            }
            WindowStatusLabel.Text=_selectedWindow is not null?"Окно игры найдено":found.Count>1?"Найдено несколько окон WoW":"Окно игры не найдено";
        } catch(Exception ex) { _selectedWindow=null; _windowSignature="!retry"; WindowStatusLabel.Text="Ошибка поиска окна"; Log("Ошибка автопоиска окна: "+ex.Message); }
    }
    private async void TrySelectProfileWhenIdle()
    {
        if(_manualProfileKey is not null || _armed || _passiveScanBusy || _profiles.Count==0 || _profileErrors.Count>0 || _selectedWindow is not GameWindow game || !Native.Valid(game) || Native.GetForegroundWindow()!=game.Handle) return;
        try {
            int tolerance=_profileTolerance,area=_profileArea;
            if(_profile?.Identity is not null) {
                var current=Native.ReadArea(game,_profileIdentityX,_profileIdentityY,1);
                if(current is {Length:1}) {
                    var known=IdentityMatcher.Match(_profiles.Select(p=>p.Profile),current[0],tolerance);
                    if(known?.Identity?.StableKey==_profile.Identity.StableKey) return;
                }
            }
            _passiveScanBusy=true; int version=_libraryGeneration; var snapshot=_profiles.ToArray();
            var result=await Task.Run(()=> {
                var frame=Native.CaptureClient(game);
                return frame is null?new ProfileLocateResult(LocateState.Invalid,null,null,"GDI не смог захватить кадр."):ProfileLocator.Find(frame,snapshot,tolerance,area);
            });
            if(_manualProfileKey is not null || _armed || version!=_libraryGeneration || _selectedWindow is not GameWindow selected || selected.Handle!=game.Handle || selected.ProcessId!=game.ProcessId || !Native.Valid(game) || Native.GetForegroundWindow()!=game.Handle) return;
            if(result.State!=LocateState.Found || result.Profile is null || result.Location is null) {
                if(_lastPassiveFailure!=result.Message) { _lastPassiveFailure=result.Message; Log("Автовыбор профиля: "+result.Message); }
                return;
            }
            _lastPassiveFailure=null;
            if(_profile?.Identity?.StableKey!=result.Profile.Profile.Identity?.StableKey) {
                string key=result.Profile.Profile.Identity!.StableKey;
                if(_profile?.Identity is not null) SaveCurrentToLibrary();
                var stored=_profiles.FirstOrDefault(p=>p.Profile.Identity?.StableKey==key) ?? result.Profile;
                ApplyStoredProfile(stored,false);
                Log("Автоматически выбран профиль: "+stored.Profile.Identity!.Name+" / "+stored.Profile.Identity.SpecName);
            }
            if(_profileAutoPixels) {
                _profileSpellX=result.Location.SpellX; _profileSpellY=result.Location.SpellY;
                _profileIdentityX=result.Location.IdentityX; _profileIdentityY=result.Location.IdentityY;
            }
        } catch(Exception ex) { Log("Автовыбор профиля: "+ex.Message); }
        finally { _passiveScanBusy=false; }
    }
    private void Navigation_Click(object sender,RoutedEventArgs e)
    {
        if(sender is not Button button) return;
        string tag=button.Tag?.ToString() ?? "overview";
        FrameworkElement[] pages=[OverviewPage,AccountsPage,ProfilesPage,SettingsPage,ActionsPage,JournalPage];
        var nav=new[]{NavOverview,NavAccounts,NavProfiles,NavSettings,NavActions,NavJournal};
        string[] tags=["overview","accounts","profiles","settings","actions","journal"];
        string[] titles=["Обзор","Аккаунты","Профили","Хоткей","Действия","Журнал"];
        string[] descriptions=["Управление профилем и автоматическим вводом","Локальные профили входа и выбор мира","Управление профилями и установка аддона","Глобальные клавиши управления приложением","Действия и клавиши текущего профиля","События, действия и ошибки за текущий сеанс"];
        int selected=Array.IndexOf(tags,tag); if(selected<0) selected=0;
        for(int i=0;i<pages.Length;i++) {
            pages[i].Visibility=i==selected?Visibility.Visible:Visibility.Collapsed;
            nav[i].Style=(Style)FindResource(i==selected?"NavActive":"NavButton");
        }
        PageTitle.Text=titles[selected]; PageSubtitle.Text=descriptions[selected];
        if(selected==2) RefreshProfileCards();
    }
    private void Start_Click(object sender,RoutedEventArgs e)
    {
        if(_armed || _startInProgress || _installInProgress || _loginBusy) return;
        _startInProgress=true; int epoch=_safetyEpoch;
        try {
            if(!_hotkeyRegistered) throw new InvalidOperationException("Не зарегистрирован аварийный Ctrl+F12.");
            _restartRequiredWindows.RemoveAll(w=>!Native.Exists(w));
            if(_restartRequiredWindows.Count>0) throw new InvalidOperationException("После установки аддона полностью перезапустите открытые окна WoW.");
            if(_selectedWindow is not GameWindow w || !Native.Exists(w)) throw new InvalidOperationException("Окно WoW не найдено автоматически. Убедитесь, что открыто одно окно игры.");
            if(!w.LooksLikeWow && MessageBox.Show("Вы выбрали окно, которое автоматический поиск не распознал как WoW:\n\n"+w+"\n\nПродолжайте только если уверены, что это окно игры.","Apix — проверка окна",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes) return;
            // On launch the library may be loaded while no character is selected.
            // Never choose the first/last profile as if it were active: arm only a
            // paused search, then require a unique identity+pixel match in WoW.
            if(_profile is null) ReloadProfiles();
            var startup=ProfileStartup.Decide(_profile is not null,_profiles.Count,_profileErrors.Count>0);
            if(startup==ProfileStartChoice.LibraryError) throw new InvalidOperationException("Библиотека профилей содержит ошибки. Проверьте журнал и папку "+_library.DirectoryPath);
            if(startup==ProfileStartChoice.NoProfiles) throw new InvalidOperationException("Нет сохранённых профилей. Один раз импортируйте экспорт аддона; папка: "+_library.DirectoryPath);
            Profile? p=null;
            if(startup==ProfileStartChoice.UseCurrent) {
                p=Snapshot(); if(p.Identity is null) throw new InvalidOperationException("В экспорте отсутствует identity; запуск запрещён.");
                if(!p.Triggers.Any(t=>t.Enabled)) throw new InvalidOperationException("Не включено ни одного действия.");
                if(UnsafeTriggerKey(p) is string problem) throw new InvalidOperationException(problem);
                _sx=_profileSpellX; _sy=_profileSpellY; _ix=_profileIdentityX; _iy=_profileIdentityY;
                _areaSize=_profileArea; _autoLocate=_profileAutoPixels; _tolerance=_profileTolerance;
                if(!_autoLocate && Math.Abs(_sx-_ix)<_areaSize && Math.Abs(_sy-_iy)<_areaSize) throw new InvalidOperationException("Области двух блоков пересекаются.");
                var conflicts=Palette.FindConflicts(p.Triggers.Select(t=>(t.SpellId.ToString(),t.Color)),_tolerance);
                if(conflicts.Count>0) throw new InvalidOperationException("Допуск создаёт пересечения: "+string.Join("; ",conflicts.Take(3)));
                if(p.Identity.Color.Distance(Rgb.Black)<=2*_tolerance) throw new InvalidOperationException("Identity слишком близка к чёрному.");
                SaveCurrentToLibrary();
            } else {
                // No current profile: forced auto-location, no input until it resolves.
                _autoLocate=true; _tolerance=_profileTolerance; _areaSize=_profileArea;
            }
            int interval=FixedIntervalMs;
            _dryRun=_nextStartIsTest;
            if(epoch!=_safetyEpoch) return;
            _window=w; _runningProfile=p; _clickInterval=interval; _schedule=new ClickSchedule(interval); _lastActionLog=long.MinValue/2; _previousSentAt=null; _spacingTotal=0; _spacingCount=0; _searchStarted=null; _lastSearchAt=long.MinValue/2;
            _calibrationGeneration++; _calibrating=false; _needsCalibration=_autoLocate; _calibrationWidth=_calibrationHeight=0;
            _armed=true; _focusPaused=false; _resumeTestMode=_dryRun;
            ModeBadge.Text=_dryRun?"ТЕСТ · БЕЗ ВВОДА":"РЕАЛЬНЫЙ ВВОД";
            TriggerGrid.IsEnabled=false; StartButton.IsEnabled=false; TestButton.IsEnabled=false; ToggleHotkeyBox.IsEnabled=false; ApplyHotkeyButton.IsEnabled=false; ClearHotkeyButton.IsEnabled=false;
            _timer.Interval=TimeSpan.FromMilliseconds(interval); _timer.Start();
            StateLabel.Text=_dryRun?"Тест: ожидание фокуса WoW (без ввода)":"Запущено: ожидание фокуса WoW";
            if(_manualProfileKey is not null) Log("Ручной профиль зафиксирован. Смену персонажа с совпадающим цветом identity определить невозможно; убедитесь, что выбран нужный персонаж.");
            if(p is null) Log("Профили сохранены. Ожидаю фокус WoW для безопасного выбора персонажа; до этого ввод не отправляется.");
            Log((_dryRun?"ТЕСТ БЕЗ ВВОДА. ":"РЕАЛЬНЫЙ ВВОД. ")+"При потере фокуса ввод на паузе; при возврате — повторная проверка и автоматическое продолжение. Для кнопок мыши указатель должен быть над клиентской областью игры.");
        } catch(Exception ex) { Log("Запуск запрещён: "+ex.Message); }
        finally { _startInProgress=false; }
    }
    private void Test_Click(object sender,RoutedEventArgs e)
    {
        if(_armed || _startInProgress) return;
        _nextStartIsTest=true;
        try { Start_Click(sender,e); } finally { _nextStartIsTest=false; }
    }
    private void Stop_Click(object sender,RoutedEventArgs e) => Disarm("Остановлено пользователем");
    private void Disarm(string reason)
    {
        _safetyEpoch++; _armed=false; _focusPaused=false; _timer.Stop(); _window=null; _runningProfile=null; _schedule=null; _searchStarted=null; _calibrationGeneration++; _calibrating=false; _needsCalibration=false;
        TriggerGrid.IsEnabled=true; StartButton.IsEnabled=true; TestButton.IsEnabled=true; ToggleHotkeyBox.IsEnabled=true; ApplyHotkeyButton.IsEnabled=true; ClearHotkeyButton.IsEnabled=true;
        ModeBadge.Text="ОСТАНОВЛЕНО"; StateLabel.Text=reason; Log(reason);
    }
    private async void BeginCalibration(GameWindow game,Profile? profile,int tolerance,int area)
    {
        if(_calibrating) return;
        _calibrating=true; int generation=++_calibrationGeneration;
        var profiles=_profiles.ToArray();
        var selectedKey=_manualProfileKey;
        StateLabel.Text=selectedKey is null ? "Автопоиск профиля и блоков: ввод приостановлен" : "Поиск блоков выбранного профиля: ввод приостановлен";
        try {
            var result=await Task.Run(()=> {
                if(!Native.Valid(game) || Native.GetForegroundWindow()!=game.Handle) return (Result:new ProfileLocateResult(LocateState.Invalid,null,null,"Окно потеряло фокус."),Width:0,Height:0,FocusLost:true);
                var image=Native.CaptureClient(game);
                if(!Native.Valid(game) || Native.GetForegroundWindow()!=game.Handle) return (Result:new ProfileLocateResult(LocateState.Invalid,null,null,"Окно потеряло фокус."),Width:0,Height:0,FocusLost:true);
                if(image is null) return (Result:new ProfileLocateResult(LocateState.Invalid,null,null,"Не удалось захватить клиентскую область через GDI."),Width:0,Height:0,FocusLost:false);
                return (Result:selectedKey is null ? ProfileLocator.Find(image,profiles,tolerance,area) : ProfileLocator.FindSelected(image,profiles,selectedKey,tolerance,area),Width:image.Width,Height:image.Height,FocusLost:false);
            });
            if(generation!=_calibrationGeneration || !_armed || _window!=game) return;
            _calibrating=false;
            if(PauseIfUnavailable()) return;
            if(result.FocusLost) { EnterFocusPause(); return; }
            if(!Native.ClientSize(game,out int width,out int height)) { if(!PauseIfUnavailable()) Disarm("Невозможно проверить размер окна"); return; }
            if(result.Width==0 || result.Height==0) { Disarm("Автопоиск не выполнен: "+result.Result.Message+" Используйте ручную калибровку."); return; }
            if(width!=result.Width || height!=result.Height) { _needsCalibration=true; Log("Размер окна изменился во время поиска; повторяем калибровку."); return; }
            if(result.Result.State==LocateState.NotFound) {
                long now=_clock.ElapsedMilliseconds; _searchStarted ??= now;
                if(now-_searchStarted>15000) { Disarm("Профиль или блоки не найдены в течение 15 секунд."); return; }
                _needsCalibration=true; StateLabel.Text="Ожидание identity активного персонажа; ввод приостановлен"; return;
            }
            if(result.Result.State!=LocateState.Found || result.Result.Location is not PixelLocation location || result.Result.Profile is not StoredProfile found) { Disarm("Автовыбор не выполнен: "+result.Result.Message+" При необходимости используйте ручную калибровку."); return; }
            _searchStarted=null;
            if(!found.Profile.Triggers.Any(t=>t.Enabled)) { Disarm("В выбранном профиле нет включённых действий."); return; }
            if(UnsafeTriggerKey(found.Profile) is string problem) { Disarm(problem); return; }
            if(profile is null) {
                // First selection after restart: restore that profile's settings,
                // then repeat the search if its tolerance/area differ. Never use
                // coordinates found under looser or otherwise different rules.
                ApplyStoredProfile(found,false); _runningProfile=found.Profile;
                _tolerance=_profileTolerance; _areaSize=_profileArea;
                Log("Автоматически выбран сохранённый профиль: "+found.Profile.Identity!.Name+" / "+found.Profile.Identity.SpecName);
                if(_tolerance!=tolerance || _areaSize!=area) {
                    _needsCalibration=true; _calibrationWidth=0; _calibrationHeight=0;
                    Log("Проверяем блоки повторно с сохранёнными параметрами профиля."); return;
                }
            } else if(found.Profile.Identity?.StableKey!=profile.Identity?.StableKey) {
                ApplyStoredProfile(found,true); _runningProfile=found.Profile;
                Log("Автоматически переключён профиль: "+found.Profile.Identity!.Name+" / "+found.Profile.Identity.SpecName);
            }
            _sx=location.SpellX; _sy=location.SpellY; _ix=location.IdentityX; _iy=location.IdentityY;
            _calibrationWidth=width; _calibrationHeight=height; _needsCalibration=false;
            _profileSpellX=_sx; _profileSpellY=_sy; _profileIdentityX=_ix; _profileIdentityY=_iy;
            Log($"Автопоиск: спелл {_sx},{_sy}; identity {_ix},{_iy}; окно {width}×{height}. Проверьте в тестовом режиме.");
        } catch(Exception ex) {
            if(generation==_calibrationGeneration && _armed) { _calibrating=false; Disarm("Ошибка автопоиска: "+ex.Message); }
        }
    }
    private void Tick(object? sender,EventArgs e)
    {
        if(!_armed || _window is null) return;
        try {
            long now=_clock.ElapsedMilliseconds;
            if(PauseIfUnavailable()) return;
            if(_focusPaused) {
                _focusPaused=false; _needsCalibration=_autoLocate; _searchStarted=null; _lastSearchAt=long.MinValue/2;
                StateLabel.Text="Фокус WoW восстановлен: проверка профиля и блоков";
                Log("Фокус WoW восстановлен. Проверяем профиль и сигналы перед возобновлением.");
            }
            if(_autoLocate) {
                if(!Native.ClientSize(_window,out int width,out int height)) { if(!PauseIfUnavailable()) Disarm("Невозможно проверить размер клиентской области"); return; }
                if(_calibrationWidth!=0 && (width!=_calibrationWidth || height!=_calibrationHeight)) { _needsCalibration=true; }
                if(_needsCalibration) { if(!_calibrating && now-_lastSearchAt>=500) { _lastSearchAt=now; BeginCalibration(_window,_runningProfile,_tolerance,_areaSize); } return; }
            }
            if(_runningProfile is null) { Disarm("Профиль ещё не определён; ввод заблокирован."); return; }
            var identity=Native.ReadArea(_window,_ix,_iy,_areaSize);
            if(identity is null) { if(!PauseIfUnavailable()) Disarm("Ошибка чтения области identity или она вышла за границы окна"); return; }
            if(identity.Any(pixel=>IdentityMatcher.Match([_runningProfile],pixel,_tolerance) is null)) {
                if(PauseIfUnavailable()) return;
                if(_autoLocate) { _needsCalibration=true; Log("Identity изменился; ввод приостановлен до выбора профиля."); return; }
                Disarm("Неизвестный или неоднородный identity-сигнал"); return;
            }
            var pixels=Native.ReadArea(_window,_sx,_sy,_areaSize);
            var match=ColorMatcher.MatchArea(_runningProfile,pixels,_tolerance);
            if(ColorMatcher.IsBlackTransition(match,pixels,_tolerance)) { StateLabel.Text="Пауза: смена сигнала; ожидание устойчивого цвета"; return; }
            if(match.State is MatchState.CaptureError or MatchState.Ambiguous or MatchState.MixedArea) { if(!PauseIfUnavailable()) Disarm("Ошибка или смешанные цвета области: "+match.State); return; }
            var pixel=pixels?[_areaSize*_areaSize/2];
            if(match.State!=MatchState.Matched || match.Trigger is null)
            { StateLabel.Text=match.State==MatchState.Black?"Работает · нет рекомендации или открыт ввод текста":"Работает · сигнал "+match.State+" · "+pixel; return; }
            var t=match.Trigger; StateLabel.Text=$"{(_dryRun?"ТЕСТ":"РАБОТА")} · {t.Name} · {pixel} · {t.Key} · {_clickInterval} мс";
            if(PauseIfUnavailable()) return;
            if(_schedule is null || !_schedule.Due(now)) return;
            if(InputPlanner.Create(t.Key) is { IsMouse:true } && !Native.PointerOnGame(_window)) { StateLabel.Text="Ожидание: для ввода мышью верните указатель в WoW"; return; }
            if(!_dryRun) {
                var send=Native.SendKey(_window,t.Key,out string sendError);
                if(send==InputSendResult.FocusLost) { if(!PauseIfUnavailable()) EnterFocusPause(); return; }
                if(send==InputSendResult.PointerOutside) { StateLabel.Text="Ожидание: для ввода мышью верните указатель в WoW"; return; }
                if(send==InputSendResult.Failed) { Disarm("Ошибка SendInput: "+sendError); return; }
            }
            long sentAt=_clock.ElapsedMilliseconds;
            _schedule.MarkSent(sentAt);
            if(_previousSentAt is long previous && sentAt-previous<=_clickInterval*3L) { _spacingTotal+=sentAt-previous; _spacingCount++; }
            else { _spacingTotal=0; _spacingCount=0; }
            _previousSentAt=sentAt;
            if(sentAt-_lastActionLog>=1000) {
                string actual=_spacingCount>0?$", фактически ~{(double)_spacingTotal/_spacingCount:0.0} мс":"";
                Log($"{(_dryRun?"Тест (без ввода)":"Ввод")}: {t.Name} [{t.SpellId}] → {t.Key}, цель {_clickInterval} мс{actual}");
                _lastActionLog=sentAt; _spacingCount=0; _spacingTotal=0;
            }
        } catch(Exception ex) { Disarm("Ошибка цикла: "+ex.Message); }
    }
}
