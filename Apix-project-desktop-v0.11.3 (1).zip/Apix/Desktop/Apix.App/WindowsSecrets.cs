using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text.Json;

namespace Apix.App;
internal sealed record LoginSecret(string User,string Password);
internal static class WindowsSecrets
{
    [StructLayout(LayoutKind.Sequential)] private struct Blob { public int Length; public IntPtr Data; }
    [DllImport("crypt32.dll",SetLastError=true,CharSet=CharSet.Unicode)]
    private static extern bool CryptProtectData(ref Blob input,string? description,IntPtr entropy,IntPtr reserved,IntPtr prompt,uint flags,out Blob output);
    [DllImport("crypt32.dll",SetLastError=true,CharSet=CharSet.Unicode)]
    private static extern bool CryptUnprotectData(ref Blob input,IntPtr description,IntPtr entropy,IntPtr reserved,IntPtr prompt,uint flags,out Blob output);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr p);
    private static byte[] Transform(byte[] bytes,bool encrypt)
    {
        if(bytes.Length is <1 or >20000) throw new InvalidOperationException("Неверная длина защищённых данных.");
        IntPtr mem=Marshal.AllocHGlobal(bytes.Length); Blob output=default;
        try {
            Marshal.Copy(bytes,0,mem,bytes.Length); var input=new Blob{Length=bytes.Length,Data=mem};
            bool ok=encrypt?CryptProtectData(ref input,null,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,1,out output):CryptUnprotectData(ref input,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,1,out output);
            if(!ok) throw new Win32Exception(Marshal.GetLastWin32Error(),"Windows не смогла обработать защищённые данные профиля.");
            if(output.Length is <1 or >20000 || output.Data==IntPtr.Zero) throw new InvalidOperationException("Ошибка защиты данных Windows.");
            var result=new byte[output.Length]; Marshal.Copy(output.Data,result,0,result.Length); return result;
        } finally {
            if(mem!=IntPtr.Zero) { Marshal.Copy(new byte[bytes.Length],0,mem,bytes.Length); Marshal.FreeHGlobal(mem); }
            if(output.Data!=IntPtr.Zero) { if(output.Length>0 && output.Length<=20000) Marshal.Copy(new byte[output.Length],0,output.Data,output.Length); LocalFree(output.Data); }
        }
    }
    public static string Protect(string user,string password)
    {
        if(string.IsNullOrEmpty(user) || string.IsNullOrEmpty(password) || user.Length>256 || password.Length>256) throw new InvalidOperationException("Введите логин и пароль (до 256 символов). ");
        byte[] plain=JsonSerializer.SerializeToUtf8Bytes(new LoginSecret(user,password));
        try { return Convert.ToBase64String(Transform(plain,true)); } finally { CryptographicOperations.ZeroMemory(plain); }
    }
    public static LoginSecret Unprotect(string ciphertext)
    {
        byte[] encrypted=Convert.FromBase64String(ciphertext); byte[] plain=Transform(encrypted,false);
        try {
            var secret=JsonSerializer.Deserialize<LoginSecret>(plain);
            if(secret is null || string.IsNullOrEmpty(secret.User) || string.IsNullOrEmpty(secret.Password) || secret.User.Length>256 || secret.Password.Length>256)
                throw new InvalidOperationException("Не удалось прочитать защищённый профиль.");
            return secret;
        } finally { CryptographicOperations.ZeroMemory(plain); CryptographicOperations.ZeroMemory(encrypted); }
    }
}
