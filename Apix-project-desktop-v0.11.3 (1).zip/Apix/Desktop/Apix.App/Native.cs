using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using Apix.Core;

namespace Apix.App;
internal sealed record GameWindow(nint Handle, int ProcessId, string Title, string ProcessName, bool LooksLikeWow)
{
    public override string ToString() => $"{Title} — {ProcessName}, PID {ProcessId}, HWND 0x{Handle.ToInt64():X}";
}
internal enum InputSendResult { Sent, PointerOutside, FocusLost, Failed }
internal static class Native
{
    private delegate bool EnumWindowsProc(nint hwnd,nint lParam);
    [DllImport("user32.dll",SetLastError=true)] private static extern bool EnumWindows(EnumWindowsProc callback,nint lParam);
    [DllImport("user32.dll")] private static extern bool IsWindowVisible(nint hwnd);
    [DllImport("user32.dll")] internal static extern bool IsWindow(nint hwnd);
    [DllImport("user32.dll")] internal static extern bool IsIconic(nint hwnd);
    [DllImport("user32.dll")] internal static extern nint GetForegroundWindow();
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] private static extern int GetWindowText(nint hwnd,StringBuilder text,int max);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(nint hwnd,out uint pid);
    [DllImport("user32.dll")] private static extern bool GetClientRect(nint hwnd,out Rect rect);
    [DllImport("user32.dll")] private static extern nint GetDC(nint hwnd);
    [DllImport("user32.dll")] private static extern int ReleaseDC(nint hwnd,nint hdc);
    [DllImport("gdi32.dll")] private static extern uint GetPixel(nint hdc,int x,int y);
    [DllImport("gdi32.dll",SetLastError=true)] private static extern nint CreateCompatibleDC(nint hdc);
    [DllImport("gdi32.dll",SetLastError=true)] private static extern nint CreateCompatibleBitmap(nint hdc,int width,int height);
    [DllImport("gdi32.dll",SetLastError=true)] private static extern nint SelectObject(nint hdc,nint obj);
    [DllImport("gdi32.dll")] private static extern bool DeleteObject(nint obj);
    [DllImport("gdi32.dll")] private static extern bool DeleteDC(nint hdc);
    [DllImport("gdi32.dll",SetLastError=true)] private static extern bool BitBlt(nint dst,int x,int y,int width,int height,nint src,int sx,int sy,uint rop);
    [DllImport("gdi32.dll",SetLastError=true)] private static extern int GetDIBits(nint hdc,nint bitmap,uint start,uint count,[Out] byte[] pixels,ref BitmapInfo info,uint usage);

    [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int key);
    [DllImport("user32.dll")] private static extern bool GetCursorPos(out Point point);
    [DllImport("user32.dll")] private static extern bool SetCursorPos(int x,int y);
    [DllImport("user32.dll")] private static extern bool ClientToScreen(nint hwnd,ref Point point);
    [DllImport("user32.dll")] internal static extern bool SetForegroundWindow(nint hwnd);
    [DllImport("user32.dll")] private static extern bool ScreenToClient(nint hwnd,ref Point point);
    [DllImport("user32.dll")] private static extern nint WindowFromPoint(Point point);
    [DllImport("user32.dll")] private static extern nint GetAncestor(nint hwnd,uint flags);
    [DllImport("user32.dll",SetLastError=true)] private static extern uint SendInput(uint n,Input[] inputs,int size);
    [DllImport("user32.dll",SetLastError=true)] internal static extern bool RegisterHotKey(nint hwnd,int id,uint modifiers,uint vk);
    [DllImport("user32.dll")] internal static extern bool UnregisterHotKey(nint hwnd,int id);
    [StructLayout(LayoutKind.Sequential)] private struct BitmapInfoHeader
    {
        public uint Size; public int Width,Height; public ushort Planes,BitCount; public uint Compression,SizeImage;
        public int XPelsPerMeter,YPelsPerMeter; public uint ClrUsed,ClrImportant;
    }
    [StructLayout(LayoutKind.Sequential)] private struct BitmapInfo { public BitmapInfoHeader Header; public uint Colors; }
    [StructLayout(LayoutKind.Sequential)] private struct Point { public int X,Y; }
    [StructLayout(LayoutKind.Sequential)] private struct Rect { public int Left,Top,Right,Bottom; }
    [StructLayout(LayoutKind.Sequential)] private struct Input { public uint Type; public InputUnion Data; }
    [StructLayout(LayoutKind.Explicit)] private struct InputUnion { [FieldOffset(0)] public KeyInput Keyboard; [FieldOffset(0)] public MouseInput Mouse; }
    [StructLayout(LayoutKind.Sequential)] private struct KeyInput { public ushort Vk,Scan; public uint Flags,Time; public nuint ExtraInfo; }
    [StructLayout(LayoutKind.Sequential)] private struct MouseInput { public int Dx,Dy; public uint MouseData,Flags,Time; public nuint ExtraInfo; }

    internal static IReadOnlyList<GameWindow> FindWindows(bool includeOther=false)
    {
        var result=new List<GameWindow>();
        bool completed=EnumWindows((h,_)=> {
            if(!IsWindowVisible(h)) return true;
            var title=new StringBuilder(1024); GetWindowText(h,title,title.Capacity);
            if(title.Length==0) return true;
            GetWindowThreadProcessId(h,out uint id);
            if(id==0 || id==(uint)Environment.ProcessId) return true;
            string name;
            try { using var p=Process.GetProcessById((int)id); name=p.ProcessName; }
            catch(ArgumentException) { return true; }
            catch(InvalidOperationException) { return true; }
            catch(System.ComponentModel.Win32Exception) { name="<недоступно>"; }
            bool looksLikeWow=WindowDiscoveryRules.LooksLikeWow(name,title.ToString());
            if(includeOther || looksLikeWow) result.Add(new(h,(int)id,title.ToString(),name,looksLikeWow));
            return true;
        },0);
        if(!completed) throw new InvalidOperationException("EnumWindows не завершился; Win32 error="+Marshal.GetLastWin32Error());
        return result.OrderByDescending(w=>w.LooksLikeWow).ThenBy(w=>w.Title,StringComparer.OrdinalIgnoreCase).ToList().AsReadOnly();
    }
    internal static bool Exists(GameWindow w)
    {
        if(!IsWindow(w.Handle)) return false;
        GetWindowThreadProcessId(w.Handle,out uint pid); return pid==(uint)w.ProcessId;
    }
    internal static bool Valid(GameWindow w) => Exists(w) && !IsIconic(w.Handle);
    internal static bool ClientSize(GameWindow w,out int width,out int height)
    {
        width=height=0;
        if(!Valid(w) || !GetClientRect(w.Handle,out var r)) return false;
        width=r.Right-r.Left; height=r.Bottom-r.Top;
        return width>0 && height>0 && (long)width*height<=20_000_000;
    }
    internal static PixelFrame? CaptureClient(GameWindow w)
    {
        if(!ClientSize(w,out int width,out int height)) return null;
        nint src=GetDC(w.Handle); if(src==0) return null;
        nint mem=0,bitmap=0,old=0; bool selected=false;
        try {
            mem=CreateCompatibleDC(src); if(mem==0) return null;
            bitmap=CreateCompatibleBitmap(src,width,height); if(bitmap==0) return null;
            old=SelectObject(mem,bitmap); if(old==0 || old==new nint(-1)) return null;
            selected=true;
            if(!BitBlt(mem,0,0,width,height,src,0,0,0x00CC0020)) return null;
            nint restored=SelectObject(mem,old); if(restored==0 || restored==new nint(-1)) return null; selected=false;
            var bytes=new byte[checked(width*height*4)];
            var info=new BitmapInfo { Header=new BitmapInfoHeader {Size=(uint)Marshal.SizeOf<BitmapInfoHeader>(),Width=width,Height=-height,Planes=1,BitCount=32,Compression=0,SizeImage=(uint)bytes.Length} };
            if(GetDIBits(src,bitmap,0,(uint)height,bytes,ref info,0)!=height) return null;
            if(!ClientSize(w,out int w2,out int h2) || w2!=width || h2!=height) return null;
            return new PixelFrame(width,height,bytes);
        }
        finally {
            if(selected && old!=0 && mem!=0) SelectObject(mem,old);
            if(bitmap!=0) DeleteObject(bitmap);
            if(mem!=0) DeleteDC(mem);
            ReleaseDC(w.Handle,src);
        }
    }
    internal static Rgb?[]? ReadArea(GameWindow w,int x,int y,int size)
    {
        if(size is not (1 or 3 or 5)) return null;
        int r=size/2;
        if(!Valid(w) || !GetClientRect(w.Handle,out var rect) || x-r<0 || y-r<0 || x+r>=rect.Right-rect.Left || y+r>=rect.Bottom-rect.Top) return null;
        nint dc=GetDC(w.Handle); if(dc==0) return null;
        try {
            var pixels=new Rgb?[size*size]; int i=0;
            for(int dy=-r;dy<=r;dy++) for(int dx=-r;dx<=r;dx++) {
                uint c=GetPixel(dc,x+dx,y+dy); if(c==0xFFFFFFFF) return null;
                pixels[i++]=new((byte)(c&255),(byte)((c>>8)&255),(byte)((c>>16)&255));
            }
            return pixels;
        } finally { ReleaseDC(w.Handle,dc); }
    }
    internal static bool CanSend(string key) => InputPlanner.Create(key) is not null;
    internal static bool PointerOnGame(GameWindow w)
    {
        if(!GetCursorPos(out var screen)) return false;
        nint under=WindowFromPoint(screen);
        if(under==0 || GetAncestor(under,2)!=w.Handle) return false; // GA_ROOT
        var client=screen;
        return ScreenToClient(w.Handle,ref client) && GetClientRect(w.Handle,out var rect) &&
            client.X>=0 && client.Y>=0 && client.X<rect.Right-rect.Left && client.Y<rect.Bottom-rect.Top;
    }
    internal static bool LoginReady(GameWindow w) => Valid(w) && GetForegroundWindow()==w.Handle &&
        new[]{0x10,0x11,0x12,0x5B,0x5C,0x01,0x02}.All(k=>(GetAsyncKeyState(k)&0x8000)==0);
    internal static bool ClickLoginPoint(GameWindow w,int x,int y)
    {
        if(!LoginReady(w) || !GetClientRect(w.Handle,out var r) || x<0 || y<0 || x>=r.Right || y>=r.Bottom) return false;
        var pt=new Point {X=x,Y=y}; if(!ClientToScreen(w.Handle,ref pt) || !SetCursorPos(pt.X,pt.Y)) return false;
        if(!LoginReady(w) || !PointerOnGame(w)) return false;
        Input[] seq=[new() {Type=0,Data=new InputUnion { Mouse=new MouseInput {Flags=0x0002}}}, new() {Type=0,Data=new InputUnion {Mouse=new MouseInput {Flags=0x0004}}}];
        uint n=SendInput(2,seq,Marshal.SizeOf<Input>());
        if(n==1) SendInput(1,[seq[1]],Marshal.SizeOf<Input>());
        return n==2;
    }
    internal static bool MoveLoginPointer(GameWindow w,int x,int y)
    {
        if(!LoginReady(w) || !GetClientRect(w.Handle,out var r) || x<0 || y<0 || x>=r.Right || y>=r.Bottom) return false;
        var pt=new Point {X=x,Y=y};
        return ClientToScreen(w.Handle,ref pt) && SetCursorPos(pt.X,pt.Y) && LoginReady(w) && PointerOnGame(w);
    }
    internal static bool ScrollLogin(GameWindow w,int x,int y,int amount)
    {
        if(!LoginReady(w) || !GetClientRect(w.Handle,out var r) || x<0 || y<0 || x>=r.Right || y>=r.Bottom) return false;
        var pt=new Point {X=x,Y=y}; if(!ClientToScreen(w.Handle,ref pt) || !SetCursorPos(pt.X,pt.Y) || !LoginReady(w) || !PointerOnGame(w)) return false;
        var input=new Input {Type=0,Data=new InputUnion { Mouse=new MouseInput {Flags=0x0800,MouseData=unchecked((uint)amount)} }};
        return SendInput(1,[input],Marshal.SizeOf<Input>())==1;
    }
    internal static bool SendLoginChar(GameWindow w,char character)
    {
        if(!LoginReady(w)) return false;
        Input[] seq=[new() {Type=1,Data=new InputUnion {Keyboard=new KeyInput {Vk=0,Scan=character,Flags=4}}},new() {Type=1,Data=new InputUnion {Keyboard=new KeyInput {Vk=0,Scan=character,Flags=6}}}];
        uint n=SendInput(2,seq,Marshal.SizeOf<Input>());
        if(n==1) SendInput(1,[seq[1]],Marshal.SizeOf<Input>());
        return n==2;
    }
    private static Input Convert(InputStep s) => s.Device==InputDevice.Keyboard
        ? new Input { Type=1, Data=new InputUnion {Keyboard=new KeyInput {Vk=s.VirtualKey, Flags=(s.Up?2u:0u)|(s.Extended?1u:0u)} } }
        : new Input { Type=0, Data=new InputUnion {Mouse=new MouseInput {MouseData=s.MouseData,Flags=s.MouseFlag} } };
    // SendInput is system-wide: focus/cursor can change between the check and delivery.
    internal static InputSendResult SendKey(GameWindow w,string raw,out string error)
    {
        error="";
        // Respect modifiers already down: do not release a modifier held by the player.
        var held=new HashSet<ushort>();
        foreach(ushort key in new ushort[]{0x10,0x11,0x12})
            if((GetAsyncKeyState(key)&0x8000)!=0) held.Add(key);
        var plan=InputPlanner.Create(raw,held);
        if(plan is null) { error="неподдерживаемая клавиша"; return InputSendResult.Failed; }
        if(!Exists(w)) { error="окно закрыто или PID изменился"; return InputSendResult.Failed; }
        if(!Valid(w) || GetForegroundWindow()!=w.Handle) { error="окно свёрнуто или потеряло фокус"; return InputSendResult.FocusLost; }
        if(plan.IsMouse && !PointerOnGame(w)) { error="указатель вне клиентской области WoW или другое окно под указателем"; return InputSendResult.PointerOutside; }
        if(!Exists(w)) { error="окно закрыто или PID изменился"; return InputSendResult.Failed; }
        if(!Valid(w) || GetForegroundWindow()!=w.Handle) { error="фокус изменился"; return InputSendResult.FocusLost; }
        if(plan.IsMouse && !PointerOnGame(w)) { error="положение указателя изменилось"; return InputSendResult.PointerOutside; }
        var inputs=plan.Steps.Select(Convert).ToArray();
        uint sent=SendInput((uint)inputs.Length,inputs,Marshal.SizeOf<Input>());
        if(sent==(uint)inputs.Length) return InputSendResult.Sent;
        // Release only synthetic downs actually accepted in the prefix.
        var releases=InputPlanner.ReleasesForPrefix(plan,(int)Math.Min(sent,(uint)inputs.Length)).Select(Convert).ToArray();
        if(releases.Length>0) SendInput((uint)releases.Length,releases,Marshal.SizeOf<Input>());
        error=$"SendInput принял {sent} из {inputs.Length} событий; попытка освобождения отправленных нажатий выполнена";
        return InputSendResult.Failed;
    }
}
