using System.Text.Json.Nodes;
using Apix.Core;

int passed=0;
void Check(bool condition,string name) { if(!condition) throw new Exception("FAIL: "+name); passed++; }
void Reject(Action a,string name) { try { a(); throw new Exception("Expected rejection: "+name); } catch(ImportException) { passed++; } }
string fixturePath=Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,"../../../../fixtures/sanitized-export.txt"));
string text=File.ReadAllText(fixturePath);
var result=ExportImporter.Import(text);
var profile=result.Profile;
Check(profile.Triggers.Count==21 && profile.Macros.Count==5,"fixture counts");
Check(profile.Triggers.All(t=>!t.Enabled),"default disabled");
Check(profile.Triggers.Single(t=>t.SpellId==17364).Key=="3","stormstrike key");
Check(profile.Triggers.Single(t=>t.SpellId==187874).Keys.SequenceEqual(["BUTTON5","5"]),"two bindings");
Check(profile.Identity?.Color==new Rgb(107,250,195),"identity");
Check(Palette.FindConflicts(profile.Triggers.Select(t=>(t.Name,t.Color)),10).Count==0,"palette 10");
Check(Palette.FindConflicts(profile.Triggers.Select(t=>(t.Name,t.Color)),16).Count>0,"palette 16");
Check(!Rgb.TryParse("# 0FF00",out _),"reject whitespace in hex");
Check(KeyChord.TryParse("SHIFT-R",out var shift) && shift is {Shift:true,Key:"R"},"modifier");
Check(KeyChord.TryParse("BUTTON5",out var mouse) && mouse?.Kind==KeyKind.Mouse,"mouse parsed, not dispatched");
Check(!KeyChord.TryParse("CTRL-CTRL-F",out _),"duplicate modifier");
Check(!KeyChord.TryParse("WHEEL-SOMETHING",out _),"unknown key");
Check(ColorMatcher.Match(profile,null,10).State==MatchState.CaptureError,"error differs from black");
Check(ColorMatcher.Match(profile,Rgb.Black,10).State==MatchState.Black,"black");
Check(ColorMatcher.Match(profile,new(255,255,255),10).State==MatchState.Unknown,"unknown");
var target=profile.Triggers.Single(t=>t.SpellId==17364);
Check(ColorMatcher.Match(profile,target.Color,10).State==MatchState.Disabled,"disabled match");
var enabled=profile with {Triggers=profile.Triggers.Select(t=>t.SpellId==17364?t with {Enabled=true}:t).ToList()};
Check(ColorMatcher.Match(enabled,target.Color,10).State==MatchState.Matched,"enabled match");
Check(ColorMatcher.Match(enabled,new(16,1,255),16).State==MatchState.Ambiguous,"ambiguous even when disabled");
Check(IdentityMatcher.Match([profile],profile.Identity!.Color,10)==profile,"identity match");
Check(IdentityMatcher.Match([profile,profile],profile.Identity.Color,10) is null,"identity ambiguity");
Reject(()=>ExportImporter.Import("APIX_EXPORT:{\"schemaVersion\":2,\"schemaVersion\":2}"),"duplicate json field");
Reject(()=>ExportImporter.Import(text.Replace("\"schemaVersion\":2","\"schemaVersion\":3")),"wrong schema");
Reject(()=>ExportImporter.Import(text.Replace("#00FF93","#000000")),"black trigger");
Reject(()=>ExportImporter.Import(text.Replace("#00FF93","#00FFB4")),"identical colors");
Reject(()=>ExportImporter.Import(text.Replace("#00FF93","#00FFA4")),"overlap ±10");
Reject(()=>ExportImporter.Import(text+" nonsense"),"trailing junk");
Reject(()=>ExportImporter.Import(new string('x',2_000_001)),"oversized");
var root=JsonNode.Parse(text[12..])!.AsObject();
root["triggers"]![0]!["key"]="CUSTOM_X"; root["triggers"]![0]!["keys"]=new JsonArray("CUSTOM_X");
var unsupported=ExportImporter.Import(root.ToJsonString());
Check(unsupported.Warnings.Any(s=>s.Contains("CUSTOM_X")),"unsupported key warning");
root["identity"]=null; var noIdentity=ExportImporter.Import(root.ToJsonString());
Check(noIdentity.Profile.Identity is null && noIdentity.Warnings.Any(s=>s.Contains("Identity")),"missing identity warning");
// Exact-match safety for multi-pixel samples.
var same=Enumerable.Repeat<Rgb?>(target.Color,9).ToArray();
Check(ColorMatcher.MatchArea(enabled,same,10).State==MatchState.Matched,"3x3 stable match");
Check(ColorMatcher.MatchArea(enabled,Enumerable.Repeat<Rgb?>(Rgb.Black,9).ToArray(),10).State==MatchState.Black,"black chat guard signal never matches a trigger");
var mixed=same.ToArray(); mixed[4]=Rgb.Black;
Check(ColorMatcher.MatchArea(enabled,mixed,10).State==MatchState.MixedArea,"3x3 mixed match and black fails closed");
Check(ColorMatcher.IsBlackTransition(ColorMatcher.MatchArea(enabled,mixed,10),mixed,10),"black transition waits without firing");
var mixedOther=same.ToArray(); mixedOther[4]=new Rgb(255,255,255);
Check(!ColorMatcher.IsBlackTransition(ColorMatcher.MatchArea(enabled,mixedOther,10),mixedOther,10),"non-black mixed area is not treated as chat transition");
mixed[4]=null; Check(ColorMatcher.MatchArea(enabled,mixed,10).State==MatchState.CaptureError,"3x3 read failure");
Check(ColorMatcher.MatchArea(enabled,Array.Empty<Rgb?>(),10).State==MatchState.CaptureError,"empty area");
Check(ColorMatcher.MatchArea(enabled,[new Rgb(16,1,255)],16).State==MatchState.Ambiguous,"area ambiguity");
// A player's held modifiers never cause a stop; when a target chord needs one,
// the plan reuses it without sending a synthetic release for that modifier.
var heldShift=new HashSet<ushort>{0x10};
var reusable=InputPlanner.Create("SHIFT-F",heldShift)!;
Check(reusable.Steps.Count==2 && reusable.Steps.All(x=>x.VirtualKey==0x46),"held target modifier is not synthetically pressed or released");
var prefixWithHeld=InputPlanner.ReleasesForPrefix(reusable,1);
Check(prefixWithHeld.Count==1 && prefixWithHeld[0].VirtualKey==0x46 && prefixWithHeld[0].Up,"partial release excludes player's modifier");
var mixedMods=InputPlanner.Create("CTRL-SHIFT-R",heldShift)!;
Check(mixedMods.Steps.Count==4 && mixedMods.Steps[0].VirtualKey==0x11 && mixedMods.Steps[^1].VirtualKey==0x11 && mixedMods.Steps.All(x=>x.VirtualKey!=0x10),"only missing target modifiers synthesized");
var unrelated=InputPlanner.Create("F",heldShift)!;
Check(unrelated.Steps.Count==2 && unrelated.Steps.All(x=>x.VirtualKey==0x46),"unrelated held modifier does not suppress send");
var heldMouseChord=InputPlanner.Create("SHIFT-BUTTON4",heldShift)!;
Check(heldMouseChord.IsMouse && heldMouseChord.Steps.Count==2 && heldMouseChord.Steps.All(x=>x.Device==InputDevice.Mouse),"held modifier reused for mouse chord");
var m4=InputPlanner.Create("SHIFT-BUTTON4")!;
Check(m4.IsMouse && m4.MainVirtualKey==5 && m4.Steps.Count==4,"mouse four plan");
Check(m4.Steps[1] is {Device:InputDevice.Mouse,MouseFlag:0x80,MouseData:1,Up:false} && m4.Steps[2] is {MouseFlag:0x100,MouseData:1,Up:true},"XBUTTON1 packet");
var m5=InputPlanner.Create("CTRL-BUTTON5")!;
Check(m5.IsMouse && m5.MainVirtualKey==6 && m5.Steps[1].MouseData==2,"XBUTTON2 packet");
Check(InputPlanner.ReleasesForPrefix(m4,0).Count==0,"zero accepted: no releases");
var release=InputPlanner.ReleasesForPrefix(m4,2);
Check(release.Count==2 && release[0] is {Device:InputDevice.Mouse,MouseFlag:0x100,MouseData:1,Up:true} && release[1] is {Device:InputDevice.Keyboard,VirtualKey:0x10,Up:true},"partial mouse releases in reverse");
Check(InputPlanner.ReleasesForPrefix(m4,4).Count==0,"complete sequence leaves no held keys");
var arrow=InputPlanner.Create("LEFT")!;
Check(arrow.Steps.All(s=>s.Extended),"extended navigation key");
Check(InputPlanner.Create("NUMPADENTER")!.Steps.All(s=>s.Extended),"numpad enter extended");
Check(InputPlanner.Create("WHEEL-SOMETHING") is null && InputPlanner.Create("MINUS") is null,"unsupported input rejected");
// Synthetic client captures: location and scale come from the exported UI layout.
PixelFrame Picture(int width,int height, params (int X,int Y,int Size,Rgb Color)[] boxes)
{
    byte[] b=new byte[width*height*4];
    for(int i=0;i<b.Length;i+=4) {b[i]=70;b[i+1]=70;b[i+2]=70;b[i+3]=255;}
    foreach(var box in boxes) for(int y=box.Y;y<box.Y+box.Size;y++) for(int x=box.X;x<box.X+box.Size;x++)
    { int n=(y*width+x)*4; b[n]=box.Color.B; b[n+1]=box.Color.G; b[n+2]=box.Color.R; }
    return new PixelFrame(width,height,b);
}
var photo=Picture(180,100,(30,12,20,target.Color),(53,12,20,profile.Identity!.Color));
var locate=PixelLocator.Find(photo,enabled,10,3);
Check(locate.State==LocateState.Found && locate.Location is {SpellX:40,SpellY:22,IdentityX:63,IdentityY:22},"locate moved blocks");
var scaled=Picture(240,160,(44,24,40,target.Color),(90,24,40,profile.Identity.Color));
var scaledResult=PixelLocator.Find(scaled,enabled,10,5);
Check(scaledResult.State==LocateState.Found && scaledResult.Location is {SpellX:64,SpellY:44,IdentityX:110,IdentityY:44},"locate 2x UI scale");
var fractional=Picture(240,130,(102,23,25,target.Color),(131,23,25,profile.Identity.Color));
var fractionalResult=PixelLocator.Find(fractional,enabled,10,3);
Check(fractionalResult.State==LocateState.Found && fractionalResult.Location is {SpellX:114,SpellY:35,IdentityX:143,IdentityY:35},"locate fractional 1.25 scale");
var ambiguous=Picture(300,120,(30,12,20,target.Color),(53,12,20,profile.Identity.Color),(180,12,20,target.Color),(203,12,20,profile.Identity.Color));
Check(PixelLocator.Find(ambiguous,enabled,10,1).State==LocateState.Ambiguous,"locator refuses two pairs");
var unknown=Picture(180,100,(30,12,20,new Rgb(80,80,80)),(53,12,20,profile.Identity.Color));
Check(PixelLocator.Find(unknown,enabled,10,3).State==LocateState.NotFound,"locator refuses unknown recommendation");
var black=Picture(180,100,(30,12,20,Rgb.Black),(53,12,20,profile.Identity.Color));
Check(PixelLocator.Find(black,enabled,10,3).State==LocateState.Found,"locator accepts reserved black");
Check(PixelLocator.Find(photo,noIdentity.Profile,10,3).State==LocateState.Invalid,"locator requires identity");
Check(WindowDiscoveryRules.LooksLikeWow("Wow-64","some window"),"classic Wow process");
Check(WindowDiscoveryRules.LooksLikeWow("WoWB","some window"),"custom WoW process");
Check(WindowDiscoveryRules.LooksLikeWow("CustomLauncher","World of Warcraft"),"game title fallback");
Check(WindowDiscoveryRules.LooksLikeWow("<недоступно>","WORLD OF WARCRAFT — TEST"),"game title case and process inaccessible");
Check(!WindowDiscoveryRules.LooksLikeWow("notepad","Notes"),"non-game requires manual choice");
Check(!WindowDiscoveryRules.LooksLikeWow(null,null),"empty window not detected");
Check(CompatibilityProbe.ReadLegacyProfile(),"v1 settings defaults for new fields");
// Focus loss/minimize pauses an armed session; a closed/replaced window stops.
Check(FocusPolicy.Decide(true,true,true)==FocusAction.Proceed,"foreground allows check");
Check(FocusPolicy.Decide(true,true,false)==FocusAction.Wait,"focus loss waits rather than stops");
Check(FocusPolicy.Decide(true,false,false)==FocusAction.Wait,"minimized window waits");
Check(FocusPolicy.Decide(true,true,true)==FocusAction.Proceed,"focus regained resumes checking");
Check(FocusPolicy.Decide(false,false,false)==FocusAction.Stop,"closed/replaced window stops");
Check(HotkeySpec.TryParse("Ctrl + Shift + F9",out var hotkey) && hotkey is {Text:"CTRL-SHIFT-F9",Modifiers:6,VirtualKey:0x78},"normalize global hotkey");
Check(hotkey!.ConflictsWithTrigger("ALT-F9") && !hotkey.ConflictsWithTrigger("F10"),"conflicting trigger base key is blocked");
Check(HotkeySpec.TryParse("F8",out var simpleHotkey) && simpleHotkey is {Modifiers:0,VirtualKey:0x77},"single key hotkey");
foreach(string alias in new[]{"~","`","Ё","ё","GRAVE","TILDE"}) {
    Check(HotkeySpec.TryParse(alias,out var grave) && grave is {Text:"~",Modifiers:0,VirtualKey:0xC0},"grave hotkey alias "+alias);
    Check(grave!.ConflictsWithTrigger("SHIFT-GRAVE"),"grave trigger collision "+alias);
}
Check(HotkeySpec.TryParse("CTRL-MINUS",out var minusHotkey) && minusHotkey is {Modifiers:2,VirtualKey:0xBD} && minusHotkey.ConflictsWithTrigger("SHIFT-MINUS"),"OEM key hotkey and conflict");
Check(HotkeySpec.TryParse("SEMICOLON",out var semicolonHotkey) && semicolonHotkey is {VirtualKey:0xBA},"OEM named hotkey");
Check(HotkeySpec.TryParse("CTRL+~",out var ctrlGrave) && ctrlGrave is {Text:"CTRL-~",Modifiers:2,VirtualKey:0xC0},"grave with ctrl");
Check(HotkeySpec.TryParse("SHIFT-~",out var shiftGrave) && shiftGrave is {Text:"SHIFT-~",Modifiers:4,VirtualKey:0xC0},"shift grave explicitly");
Check(HotkeySpec.TryParse("CTRL-~",out var reloadedGrave) && reloadedGrave==ctrlGrave,"grave saved hotkey round-trip");
Check(!HotkeySpec.TryParse("CTRL-F12",out _) && !HotkeySpec.TryParse("F12",out _),"emergency key reserved");
Check(!HotkeySpec.TryParse("BUTTON4",out _) && !HotkeySpec.TryParse("CTRL-CTRL-F9",out _) && !HotkeySpec.TryParse("",out _),"reject invalid global hotkeys");
// Clicker cadence: a single global interval, no GCD or per-spell anti-repeat.
var fast=new ClickSchedule(5);
Check(fast.Due(100),"5ms first click immediate"); fast.MarkSent(100);
Check(!fast.Due(104) && fast.Due(105),"5ms interval boundary"); fast.MarkSent(105);
Check(fast.Due(200),"5ms late click permitted"); fast.MarkSent(200);
Check(!fast.Due(200) && !fast.Due(204),"5ms skips catch-up");
try { _=new ClickSchedule(4); throw new Exception("expected invalid interval"); } catch(ArgumentOutOfRangeException) {passed++;}
var cadence=new ClickSchedule(15);
Check(cadence.Due(100),"first click immediate"); cadence.MarkSent(100);
Check(!cadence.Due(114) && cadence.Due(115),"15ms exact boundary"); cadence.MarkSent(115);
Check(cadence.Due(1000),"late tick may click once"); cadence.MarkSent(1000);
Check(!cadence.Due(1000) && !cadence.Due(1014),"late tick has no catch-up burst");
Check(!cadence.Due(999),"monotonic clock must not move backwards");
var sampleRows=profile.Triggers.Select(t=>new RowFile(t.SpellId,t.Color.ToString(),t.Key,true,9999,60000,true,0)).ToList();
var file1=new ProfileFile(4,text,12,12,35,12,10,15,1500,sampleRows,1,0,true);
var stored1=ProfileCodec.Read(ProfileCodec.Serialize(file1));
var fastStored=ProfileCodec.Read(ProfileCodec.Serialize(file1 with {Interval=5}));
Check(fastStored.File.Interval==5 && fastStored.Profile.Triggers.Count==21,"5ms profile save/load");
var legacy=ProfileCodec.Read(ProfileCodec.Serialize(file1 with {Version=3,Interval=50,Gcd=1500,Jitter=200}));
Check(legacy.File.Interval==50 && legacy.Profile.Triggers.Count==21,"legacy profile settings import; legacy timing ignored by clicker");
Check(stored1.Profile.Triggers.All(t=>t.Enabled) && stored1.File.Interval==15,"stored profile rows/interval");
var profileNode=JsonNode.Parse(text[12..])!.AsObject();
profileNode["identity"]!["name"]="Other"; profileNode["identity"]!["specID"]=262; profileNode["identity"]!["color"]="#123456";
var text2="APIX_EXPORT:"+profileNode.ToJsonString();
var file2=file1 with {Export=text2};
var stored2=ProfileCodec.Read(ProfileCodec.Serialize(file2));
var picture2=Picture(180,100,(30,12,20,target.Color),(53,12,20,stored2.Profile.Identity!.Color));
var picked=ProfileLocator.Find(picture2,[stored1,stored2],10,3);
Check(picked.State==LocateState.Found && picked.Profile?.Profile.Identity?.Name=="Other", "select matching identity profile");
var noMatch=Picture(180,100,(30,12,20,target.Color));
Check(ProfileLocator.Find(noMatch,[stored1,stored2],10,3).State==LocateState.NotFound,"unknown identity not selected");
profileNode["identity"]!["color"]="#6BFAC0";
var collisionFile=file1 with {Export="APIX_EXPORT:"+profileNode.ToJsonString()};
var collision=ProfileCodec.Read(ProfileCodec.Serialize(collisionFile));
Check(ProfileLocator.Find(photo,[stored1,collision],10,3).State==LocateState.Ambiguous,"overlapping identity colours rejected");
Check(ProfileLocator.Find(picture2,[stored1,collision,stored2],10,3).Profile?.Profile.Identity?.StableKey==stored2.Profile.Identity!.StableKey,"unrelated overlapping profiles do not block unique active identity");
Check(ProfileLocator.FindSelected(photo,[stored1,collision],stored1.Profile.Identity!.StableKey,10,3).Profile?.Profile.Identity?.StableKey==stored1.Profile.Identity!.StableKey,"manual selection uses chosen profile despite identity overlap");
Check(ProfileLocator.FindSelected(photo,[stored1,collision],collision.Profile.Identity!.StableKey,10,3).Profile?.Profile.Identity?.StableKey==collision.Profile.Identity!.StableKey,"manual selection can choose the other overlapping profile");
Check(ProfileLocator.FindSelected(noMatch,[stored1,collision],stored1.Profile.Identity!.StableKey,10,3).State==LocateState.NotFound,"manual selection still requires expected identity signal");
Check(ProfileLocator.FindSelected(photo,[stored1,collision],"missing",10,3).State==LocateState.Invalid,"manual selection does not fall back to a different profile");

var tmp=Path.Combine(Path.GetTempPath(),"apix-tests-"+Guid.NewGuid().ToString("N"));
try {
    var lib=new ProfileLibrary(tmp); lib.Save(file1); lib.Save(file2);
    var loaded=lib.LoadAll(); Check(loaded.Profiles.Count==2 && loaded.Errors.Count==0,"save and reload two profiles");
    lib.Save(file1 with {Interval=17});
    loaded=lib.LoadAll(); Check(loaded.Profiles.Count==2 && loaded.Profiles.Any(p=>p.Profile.Identity?.Name=="Test" && p.File.Interval==17),"replace only matching profile");
    File.WriteAllText(Path.Combine(tmp,"bad.json"),"not json");
    loaded=lib.LoadAll(); Check(loaded.Profiles.Count==2 && loaded.Errors.Count==1,"invalid profile surfaced");
} finally { if(Directory.Exists(tmp)) Directory.Delete(tmp,true); }
try { ProfileCodec.Read(ProfileCodec.Serialize(file1 with {Rows=sampleRows.Take(1).ToList()})); throw new Exception("Expected missing rows rejection"); } catch(ImportException) {passed++;}
// Restart: previously imported profiles can start a paused identity search, never an arbitrary profile.
Check(ProfileStartup.Decide(false,0,false)==ProfileStartChoice.NoProfiles,"empty library requires first import");
Check(ProfileStartup.Decide(false,1,false)==ProfileStartChoice.SearchSaved,"one saved profile starts search without import");
Check(ProfileStartup.Decide(false,2,false)==ProfileStartChoice.SearchSaved,"multiple saved profiles start search, no guess");
Check(ProfileStartup.Decide(true,2,false)==ProfileStartChoice.UseCurrent,"current profile retained");
Check(ProfileStartup.Decide(false,2,true)==ProfileStartChoice.LibraryError && ProfileStartup.Decide(true,2,true)==ProfileStartChoice.LibraryError,"corrupt library blocks start");
Check(ProfileLocator.Find(picture2,[stored1,stored2],10,3).Profile?.Profile.Identity?.Name=="Other","restart search selects active identity not first saved profile");
Check(ProfileLocator.Find(noMatch,[stored1,stored2],10,3).Profile is null,"restart search cannot select unknown identity");
// Screen template matching: copied target, shifted row, ambiguity and visually similar label.
var pixels=new byte[320*200*4];
void SetPixel(int x,int y,byte r,byte g,byte b) {int k=(y*320+x)*4; pixels[k]=b;pixels[k+1]=g;pixels[k+2]=r;pixels[k+3]=255;}
void DrawLabel(int x,int y,bool variant=false) {
    for(int yy=0;yy<12;yy++) for(int xx=0;xx<90;xx++)
        if(((xx*7+yy*11)%19)<6 && !(variant && xx>70 && xx<82)) SetPixel(x+xx,y+yy,245,190,8);
}
DrawLabel(48,40); var testFrame=new PixelFrame(320,200,pixels.ToArray());
var patch=ScreenPatch.Capture(testFrame,45,38,100,16);
Check(patch.ColorfulCount()>15 && ScreenTemplate.At(testFrame,patch,45,38),"learn and verify template");
Check(!ScreenTemplate.At(testFrame,patch,44,75),"template not found elsewhere");
DrawLabel(48,100,true); testFrame=new PixelFrame(320,200,pixels.ToArray());
var foundRealm=ScreenTemplate.FindInColumn(testFrame,patch,45,0,199);
Check(foundRealm.Count==1 && foundRealm[0].Y==38,"similar but different realm not selected");
DrawLabel(48,140); testFrame=new PixelFrame(320,200,pixels.ToArray());
Check(ScreenTemplate.FindInColumn(testFrame,patch,45,0,199).Count==2,"duplicate labels are ambiguous");
try { _=ScreenPatch.Capture(testFrame,-1,0,100,20); throw new Exception("expected out of bounds"); } catch(InvalidOperationException) {passed++;}
// Rescaled templates: the output is matched before any transformed coordinate can be used.
PixelFrame ScaledScene(double factor,int w,int h,ScaleFilter filter=ScaleFilter.Nearest) {
    var data=new byte[w*h*4]; var p=ScreenScaling.Scale(patch,factor,filter);
    int left=(int)Math.Round(w/2.0+(45-320/2.0)*factor);
    int top=(int)Math.Round(h/2.0+(38-200/2.0)*factor);
    for(int y=0;y<p.Height;y++) for(int x=0;x<p.Width;x++) {
        int source=(y*p.Width+x)*3, dest=((top+y)*w+left+x)*4;
        data[dest]=p.Pixels[source+2];data[dest+1]=p.Pixels[source+1];data[dest+2]=p.Pixels[source];data[dest+3]=255;
    }
    return new PixelFrame(w,h,data);
}
foreach(var (factor,w,h) in new[]{(1.5,480,300),(0.75,240,150),(1.5,600,300)}) {
    var scene=ScaledScene(factor,w,h);
    var hit=ScreenScaling.Resolve(scene,320,200,new ScreenPoint(45,38),patch);
    Check(hit is not null && Math.Abs(hit.Scale-factor)<0.001,"rescaled distinctive anchor resolves");
    Check(hit!.Matches(scene),"resolved anchor can be revalidated");
    var mapped=hit.Map(new ScreenPoint(105,78),new ScreenPoint(45,38));
    Check(mapped.X==hit.Position.X+(int)Math.Round(60*factor) && mapped.Y==hit.Position.Y+(int)Math.Round(40*factor),"click coordinates follow matched anchor");
    Check(!hit.Matches(Picture(w,h)),"changed screen blocks input");
}
// Resize an entire scene, so template rasterisation also has a subpixel phase.
PixelFrame GlobalResize(PixelFrame source,int width,int height) {
    var data=new byte[width*height*4];
    for(int y=0;y<height;y++) for(int x=0;x<width;x++) {
        int sx=Math.Min(source.Width-1,(int)((x+0.5)*source.Width/width));
        int sy=Math.Min(source.Height-1,(int)((y+0.5)*source.Height/height));
        var c=source.Pixel(sx,sy);int k=(y*width+x)*4;
        data[k]=c.B;data[k+1]=c.G;data[k+2]=c.R;data[k+3]=255;
    }
    return new PixelFrame(width,height,data);
}
var globalScaled=GlobalResize(testFrame,400,250);
var globalHit=ScreenScaling.Resolve(globalScaled,320,200,new ScreenPoint(45,38),patch);
Check(globalHit is not null && globalHit.Matches(globalScaled),"anchor found in resized full scene, including raster phase");
var smoothScene=ScaledScene(1.5,480,300,ScaleFilter.Bilinear);
var smoothHit=ScreenScaling.Resolve(smoothScene,320,200,new ScreenPoint(45,38),patch);
Check(smoothHit is not null && smoothHit.Matches(smoothScene) && smoothHit.Filter==ScaleFilter.Bilinear,"bilinear scaled anchor resolves");
Check(ScreenScaling.Resolve(Picture(480,300),320,200,new ScreenPoint(45,38),patch) is null,"missing anchor is rejected");
var loginCal=new LoginCalibration(320,200,new(100,80),new(100,95),new(100,110),new(45,38),patch);
var realmCal=new RealmCalibration(320,200,new(45,38),patch,new(45,100),patch,new(120,150));
var originalAccount=new LoginProfile(Guid.NewGuid(),"A","realm","test.exe","secret-a",loginCal,realmCal);
var otherAccount=new LoginProfile(Guid.NewGuid(),"B","realm","test.exe","secret-b",null,null);
var inherited=LoginCalibrationReuse.Apply(otherAccount,[originalAccount,otherAccount]);
Check(inherited.Login==loginCal && inherited.Realm==realmCal && inherited.ProtectedCredentials=="secret-b","training reuse without sharing credentials");
Check(LoginCalibrationReuse.Apply(otherAccount with {RealmName="other"},[originalAccount]).Realm is null,"other world is not guessed");
var conflicting=originalAccount with {Id=Guid.NewGuid(),Login=loginCal with {Submit=new ScreenPoint(1,2)}};
Check(LoginCalibrationReuse.Apply(otherAccount,[originalAccount,conflicting]).Login is null,"conflicting login training is not guessed");
var accountsDir=Path.Combine(Path.GetTempPath(),"apix-accounts-tests-"+Guid.NewGuid().ToString("N"));
try {
    var store=new LoginProfileStore(accountsDir);
    var account=new LoginProfile(Guid.NewGuid(),"profile","test realm","fake.exe","encrypted-only",null,null);
    store.Save(account); var loadedAccounts=store.Load();
    Check(loadedAccounts.Errors.Count==0 && loadedAccounts.Profiles.Single().Id==account.Id,"login profile persisted");
    Check(!File.ReadAllText(Directory.GetFiles(accountsDir,"*.json").Single()).Contains("plain-password-test"),"no plaintext credential stored in profile metadata");
    store.Save(account with {RealmName="changed"});
    Check(store.Load().Profiles.Single().RealmName=="changed","login profile update");
    store.Delete(account.Id); Check(store.Load().Profiles.Count==0,"login profile delete");
} finally { if(Directory.Exists(accountsDir)) Directory.Delete(accountsDir,true); }
// Installer operates only inside AddOns/Apix; test safe update and rollback.
var game=Path.Combine(Path.GetTempPath(),"apix-installer-tests-"+Guid.NewGuid().ToString("N"));
try {
    Directory.CreateDirectory(game);
    Check(!AddonInstaller.IsGameRoot(game),"reject missing wow executable");
    File.WriteAllText(Path.Combine(game,"Wow-64.exe"),"test executable");
    Check(AddonInstaller.IsGameRoot(game),"recognize game root");
    Directory.CreateDirectory(Path.Combine(game,"Data"));
    Directory.CreateDirectory(Path.Combine(game,"Interface","AddOns","Apix"));
    Directory.CreateDirectory(Path.Combine(game,"WTF"));
    Check(AddonInstaller.NormalizeGameRoot(Path.Combine(game,"Interface"))==game,"normalize Interface to game root");
    Check(AddonInstaller.NormalizeGameRoot(Path.Combine(game,"Interface","AddOns"))==game,"normalize AddOns to game root");
    Check(AddonInstaller.NormalizeGameRoot(Path.Combine(game,"Interface","AddOns","Apix"))==game,"normalize Apix to game root");
    File.Delete(Path.Combine(game,"Wow-64.exe"));
    Check(AddonInstaller.IsGameRoot(game),"renamed executable accepted with WoW folders");
    var bundle=AddonInstaller.Files.ToDictionary(n=>n,n=>System.Text.Encoding.UTF8.GetBytes("new "+n));
    bundle["Apix.toc"]=System.Text.Encoding.UTF8.GetBytes("## Interface: 70300\n"+string.Join("\n",AddonInstaller.Files.Take(AddonInstaller.Files.Count-1))+"\n");
    var addons=Path.Combine(game,"Interface","AddOns");
    var addonTarget=Path.Combine(addons,"Apix");
    Directory.CreateDirectory(addonTarget); Directory.CreateDirectory(Path.Combine(addons,"OtherAddon"));
    Directory.CreateDirectory(Path.Combine(game,"WTF"));
    File.WriteAllText(Path.Combine(game,"WTF","saved.txt"),"saved settings");
    File.WriteAllText(Path.Combine(addons,"OtherAddon","keep.txt"),"other addon");
    File.WriteAllText(Path.Combine(addonTarget,"custom.txt"),"custom");
    File.WriteAllText(Path.Combine(addonTarget,"Config.lua"),"old config");
    var bad=bundle.Where(x=>x.Key!="Core.lua").ToDictionary(x=>x.Key,x=>x.Value);
    try { AddonInstaller.Install(game,bad); throw new Exception("expected incomplete payload error"); } catch(InvalidOperationException) {passed++;}
    Check(File.ReadAllText(Path.Combine(addonTarget,"Config.lua"))=="old config","no changes with incomplete bundle");
    string destination=AddonInstaller.Install(game,bundle);
    Check(destination==addonTarget && AddonInstaller.Files.All(n=>File.ReadAllBytes(Path.Combine(addonTarget,n)).SequenceEqual(bundle[n])),"install all files");
    Check(AddonInstaller.Install(Path.Combine(game,"Interface","AddOns"),bundle)==addonTarget,"install when AddOns directory selected");
    Check(File.ReadAllText(Path.Combine(game,"WTF","saved.txt"))=="saved settings" && File.ReadAllText(Path.Combine(addons,"OtherAddon","keep.txt"))=="other addon" && File.ReadAllText(Path.Combine(addonTarget,"custom.txt"))=="custom","preserve settings other addons and extra files");
    var changed=bundle.ToDictionary(x=>x.Key,x=>x.Value.ToArray());
    changed["Utils.lua"]=System.Text.Encoding.UTF8.GetBytes("update utils");
    changed["Config.lua"]=System.Text.Encoding.UTF8.GetBytes("update config");
    try { AddonInstaller.Install(game,changed,n=>{ if(n=="Identity.lua") throw new IOException("injected failure"); }); throw new Exception("expected failure"); } catch(IOException ex) {Check(ex.Message.Contains("восстановлены"),"rollback reported");}
    Check(AddonInstaller.Files.All(n=>File.ReadAllBytes(Path.Combine(addonTarget,n)).SequenceEqual(bundle[n])),"rollback all changed files");
    Check(!Directory.GetDirectories(addons,".apix-install-*").Any(),"staging removed after rollback");
    var corrupt=bundle.ToDictionary(x=>x.Key,x=>x.Value.ToArray());
    corrupt["Apix.toc"]=System.Text.Encoding.UTF8.GetBytes("## Interface: 70300\n../evil.lua\n");
    try { AddonInstaller.Install(game,corrupt); throw new Exception("expected invalid toc"); } catch(InvalidOperationException) {passed++;}
    Check(File.ReadAllBytes(Path.Combine(addonTarget,"Apix.toc")).SequenceEqual(bundle["Apix.toc"]),"bad toc causes no changes");
    Directory.Delete(addonTarget,true); Directory.CreateDirectory(addonTarget);
    try { AddonInstaller.Install(game,changed,n=>{ if(n=="Identity.lua") throw new IOException("injected failure"); }); throw new Exception("expected failure"); } catch(IOException) {passed++;}
    Check(!AddonInstaller.Files.Any(n=>File.Exists(Path.Combine(addonTarget,n))),"rollback removes newly created files");
} finally { if(Directory.Exists(game)) Directory.Delete(game,true); }
Console.WriteLine($"PASS: {passed} assertions (import, colors, area, input plans, focus policy, hotkeys, click cadence, profile library/selection, addon installation/rollback). No Windows APIs tested.");

internal static class CompatibilityProbe
{
    private sealed record Setting(int Id,string Key);
    private sealed record Old(int Version,string Export,int Tolerance,List<Setting> Rows);
    private sealed record New(int Version,string Export,int Tolerance,List<Setting> Rows,int Area=1,int Jitter=0);
    public static bool ReadLegacyProfile()
    {
        string json=System.Text.Json.JsonSerializer.Serialize(new Old(1,"test",10,[new(17364,"3")]));
        var p=System.Text.Json.JsonSerializer.Deserialize<New>(json);
        return p is {Version:1,Area:1,Jitter:0,Tolerance:10} && p.Rows.Count==1 && p.Rows[0].Id==17364;
    }
}
