"""Static XAML/code contract checks. This does not run WPF or Windows APIs."""
from pathlib import Path
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parents[1]
window=root/'Apix.App'/'MainWindow.xaml'
code=(root/'Apix.App'/'MainWindow.xaml.cs').read_text(encoding='utf-8')
xaml=ET.parse(window).getroot()
x='{http://schemas.microsoft.com/winfx/2006/xaml}'
ns='{http://schemas.microsoft.com/winfx/2006/xaml/presentation}'
by_name={e.attrib[x+'Name']:e for e in xaml.iter() if x+'Name' in e.attrib}
assert xaml.attrib['Width']=='1040' and xaml.attrib['Height']=='740'
for name in ('OverviewPage','AccountsPage','ProfilesPage','SettingsPage','ActionsPage','JournalPage','NavOverview','NavAccounts','NavProfiles','NavSettings','NavActions','NavJournal','PageTitle','PageSubtitle','ProfileList','ProfileCountOverview','ActionCountOverview','RecentLogText','AccountPassword','AccountPicker','AccountSaveStatus'):
    assert name in by_name,name
assert by_name['OverviewPage'].attrib.get('Visibility','Visible')=='Visible'
for name in ('AccountsPage','ProfilesPage','SettingsPage','ActionsPage','JournalPage'):
    assert by_name[name].attrib.get('Visibility')=='Collapsed',name
assert 'pages[i].Visibility=i==selected?Visibility.Visible:Visibility.Collapsed' in code
assert 'ProfileList.ItemsSource=_profileCards' in code and 'foreach(var entry in _profiles)' in code
assert 'RecentLogText.Text=string.Join' in code
assert 'pack://application:,,,/Apix.App;component/Assets/hero.jpg' in window.read_text(encoding='utf-8')
import re
for button in xaml.iter(ns+'Button'):
    handler=button.attrib.get('Click')
    if handler: assert re.search(r'\b'+re.escape(handler)+r'\s*\(',code+'\n'+(root/'Apix.App'/'LoginUI.cs').read_text(encoding='utf-8')),handler
log=by_name['LogText']
assert log.tag==ns+'TextBox' and log.attrib['IsReadOnly']=='True'
assert log.attrib['TextWrapping']=='Wrap' and log.attrib['VerticalScrollBarVisibility']=='Auto'
buttons=[e for e in xaml.iter(ns+'Button') if e.attrib.get('Click')=='CopyLog_Click']
assert len(buttons)==1 and 'Clipboard.SetText(LogText.Text)' in code
for name in ('StartButton','TestButton','ToggleHotkeyBox','StateLabel','ProfileLabel','WindowStatusLabel','TriggerGrid','ModeBadge'):
    assert name in by_name,name
assert len([e for e in xaml.iter(ns+'Button') if e.attrib.get('Click')=='InstallAddon_Click'])==1
assert len([e for e in xaml.iter(ns+'Button') if e.attrib.get('Click')=='ChooseAddonFolder_Click'])==1
assert 'InstallStatusLabel' in by_name
assert 'AddonInstaller.Install(root,ReadBundledAddon())' in code
assert 'WindowBox' not in by_name and 'OptionsPanel' not in by_name
assert 'ProfileStartup.Decide(_profile is not null,_profiles.Count,_profileErrors.Count>0)' in code
assert 'if(_profile is null) ReloadProfiles()' in code
assert 'Profile? p=null;' in code and 'if(startup==ProfileStartChoice.UseCurrent)' in code
assert '_autoLocate=true; _tolerance=_profileTolerance; _areaSize=_profileArea;' in code
assert 'private async void BeginCalibration(GameWindow game,Profile? profile' in code
assert 'if(_runningProfile is null) { Disarm(' in code
assert 'ApplyStoredProfile(found,false); _runningProfile=found.Profile;' in code
assert 'if(_tolerance!=tolerance || _areaSize!=area)' in code
assert 'FixedIntervalMs=5' in code
assert 'Apix.App;component/Assets/apix.ico' in xaml.attrib['Icon']
for asset in ('apix.ico','apix.png','hero.jpg'):
    assert (root/'Apix.App'/'Assets'/asset).is_file()
print('PASS: navigation/page wiring, real profile cards, copyable journal, installer, assets and 5 ms (static only; Windows/WPF not tested).')

login_code=(root/'Apix.App'/'LoginUI.cs').read_text(encoding='utf-8')
secret_code=(root/'Apix.App'/'WindowsSecrets.cs').read_text(encoding='utf-8')
assert 'WindowsSecrets.Protect(user,password)' in login_code
assert 'WindowsSecrets.Unprotect(profile.ProtectedCredentials)' in login_code
assert 'CryptProtectData' in secret_code and 'CryptUnprotectData' in secret_code
assert 'Clipboard.' not in login_code and 'ProcessStartInfo(profile.Executable)' in login_code
assert 'ProcessStartInfo(profile.Executable)' in login_code and 'UseShellExecute=false' in login_code
assert 'matches.Count>1' in login_code and 'Native.LoginReady(game)' in login_code
assert 'login.AnchorTopLeft' in login_code and 'realm.TitleTopLeft' in login_code
assert '_loginCts?.Cancel(); Disarm' in code
assert 'profile with {Realm=dialog.RealmResult}' in login_code
print('PASS: account UI, local DPAPI code, focus and ambiguity guards (static only; Windows DPAPI/SendInput not tested).')

assert 'if(existing.Count>1)' in login_code
assert 'if(attached is not null)' in login_code
assert 'Path.GetFullPath(profile.Executable)' in login_code
assert 'w.Handle==attached.Handle && w.ProcessId==attached.ProcessId' in login_code
save=login_code[login_code.index('private void SaveAccount_Click'):login_code.index('private void DeleteAccount_Click')]
assert 'old?.Login' in save and 'old?.Realm' in save
assert 'old?.Login is null' not in save and 'AccountSaveStatus.Text="Профиль не сохранён:' in save
print('PASS: existing WoW path/identity guard and saving before training (static only).')

assert 'ScreenScaling.Resolve(frame,width,height,anchor,patch)' in login_code
assert 'VerifyFrame(game,loginAnchor)' in login_code and 'VerifyFrame(game,realmAnchor)' in login_code
assert 'loginAnchor.Map(login.Password,login.AnchorTopLeft)' in login_code
assert 'LoginCalibrationReuse.Apply' in login_code
assert 'frame.Width!=width || frame.Height!=height' not in login_code
print('PASS: scaled anchor integration and reusable training (static only).')

assert 'ChooseProfile_Click' in code and 'AutomaticProfile_Click' in code
assert 'ProfileLocator.FindSelected(image,profiles,selectedKey,tolerance,area)' in code
assert 'if(_manualProfileKey is not null || _armed || _passiveScanBusy' in code
assert 'Цвета identity разных профилей пересекаются' not in code
assert any(e.attrib.get('Click')=='ChooseProfile_Click' for e in xaml.iter(ns+'Button'))
print('PASS: explicit profile selection and auto mode wiring (static only).')
